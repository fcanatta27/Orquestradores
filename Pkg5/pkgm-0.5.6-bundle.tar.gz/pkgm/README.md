# pkgm

`pkgm` é um gerenciador de pacotes **minimalista** em estilo *ports* (build-from-source) com empacotamento via `tar` e um banco de instalação baseado em *manifests*.

O projeto é voltado para construção de sistemas (bootstrapping) e manutenção de um conjunto de ports em repositórios (`core`, `extra`, `wayland`).

## Estrutura do projeto

```
pkgm/
  bin/pkgm                # CLI principal
  etc/pkgm.conf.example   # exemplo de configuração
  ports/
    core/<pkg>/recipe     # ports de base do sistema
    extra/<pkg>/recipe    # ports adicionais
    wayland/<pkg>/recipe  # stack Wayland (quando aplicável)
  scripts/
    mktoolchain.sh        # toolchain temporária (tools/)
    stage1.sh             # base inicial (pré-chroot)
    stage2.sh             # base para operação confortável no chroot
    chrootctl.sh          # entrada/saída segura do chroot (bind mounts)
  tools/
    revdep.sh             # checagem de dependências reversas (integração)
```

## Configuração

Copie o arquivo de exemplo:

```sh
install -Dm644 etc/pkgm.conf.example /etc/pkgm.conf
# ou:
install -Dm644 etc/pkgm.conf.example ~/.config/pkgm.conf
```

Principais variáveis:
- `PORTS_ROOT`: raiz onde ficam os repositórios de ports.
- `PORTS_REPOS`: lista/ordem dos repositórios habilitados (ex.: `core extra wayland`).
- `WORKDIR`, `DISTDIR`, `BUILDDIR`: build/cache.
- `CHECKSUM_POLICY`: `strict` ou `allow-skip`.

## CLI (subcomandos)

- `pkgm build <pkg>`: resolve deps, baixa fontes, compila e gera pacote.
- `pkgm install <pkg>`: instala a partir do pacote gerado (constrói antes se necessário).
  - `pkgm install <pkg> --explain`: imprime o plano (deps/ordem) sem executar.
- `pkgm remove <pkg>`: remove usando manifest do banco de instalação.
- `pkgm upgrade <pkg>`: recompila e reinstala.
- `pkgm info <pkg>`: metadados + estado.
- `pkgm list`: lista pacotes instalados (best-effort).
- `pkgm fix --broken`: tenta corrigir instalações quebradas (reinstala faltantes / limpa estado).
- `pkgm doctor`: checagens de sanidade do ambiente (paths, perms, deps, ferramentas).
- `pkgm lint-port <pkg>`: valida receita (campos obrigatórios, funções, práticas).

## Repositório `core` (ports reais)

Foram adicionados ports reais em `ports/core` para bootstrap/base:

- `binutils` 2.45.1
- `gcc` 15.2.0
- `linux` 6.18.2 (instala **headers**)
- `glibc` 2.42
- `coreutils` 9.9
- `bash` 5.3.0 (base `bash-5.3` + patches opcionais)

Observação: `bash` pode aplicar patches oficiais automaticamente (sem checksum) via variável `BASH_PATCHLEVEL`.

## Scripts de bootstrap

### 1) Toolchain temporária
`mktoolchain.sh` constrói uma toolchain temporária completa e funcional em `/mnt/rootfs/tools` (x86_64, glibc).

### 2) Stage1 (pré-chroot)
`stage1.sh` instala o conjunto mínimo para *entrar no chroot* com segurança (montagens, shells, utilitários essenciais).

### 3) Stage2 (dentro do chroot)
`stage2.sh` instala utilitários e bibliotecas necessários para continuar a construção do sistema base de forma confortável e previsível.

### 4) chrootctl
`chrootctl.sh` gerencia:
- bind mounts necessários (`/dev`, `/proc`, `/sys`, `/run`, etc.)
- entrada no chroot com ambiente controlado
- modo “construir e sair” (enter → build/install → exit)

Consulte comentários no topo de cada script para variáveis ajustáveis.

## Documentação adicional
- Guia oficial de ports: `docs/PORTS_GUIDE.md`

## Licença
Consulte os cabeçalhos dos arquivos.

Nota: o port `gcc` no core foi ajustado para não baixar dependências automaticamente; instale `gmp`, `mpfr` e `mpc` antes.
