# pkgm

`pkgm` é um gerenciador **mínimo** de pacotes no estilo *ports* (build a partir de receitas), com suporte a empacotamento/instalação via `tar.gz` e um banco de instalação baseado em *manifests*.

O foco do projeto é previsibilidade, simplicidade operacional e fácil automação em *shell scripts*.

## Funcionalidades suportadas

### Operações de pacotes
- `pkgm build <pkg>`: compila um port e gera um pacote (`PKGFILE`, normalmente `*.tar.gz`).
- `pkgm install <pkg>`: instala a versão construída (ou constrói antes, dependendo do port).
  - `pkgm install <pkg> --explain`: imprime o plano (deps/ordem/artefatos) antes de executar.
- `pkgm remove <pkg>`: remove um pacote instalado (usando o manifest do banco de instalação).
- `pkgm upgrade <pkg>`: recompila e reinstala o pacote (fluxo de upgrade simples).
- `pkgm info <pkg>`: mostra metadados do port e estado de instalação (quando aplicável).
- `pkgm list`: lista pacotes instalados (best-effort a partir do banco de instalação).
- `pkgm search <pattern>`: pesquisa por ports disponíveis (nome/descrição).

### Diagnóstico e correção
- `pkgm doctor`: varre estados anômalos (`broken/installing/upgrading/removing`) e aponta problemas comuns.
- `pkgm fix --broken`: tenta recuperar pacotes marcados como `broken` (rebuild + reinstall).
- `pkgm revdep [args...]`: wrapper oficial para `bin/revdep.sh` (detecção de dependências quebradas).

### Qualidade de ports
- `pkgm lint-port <pkg>`: validação best-effort de `recipe` (variáveis mínimas, padrões perigosos e `shellcheck` se disponível).

## Banco de instalação e estados

A base de instalação fica em `INST_DB_DIR` (configurável). O layout (simplificado) é:

```
INST_DB_DIR/<pkg>/<versao>/
  manifest
  state
INST_DB_DIR/<pkg>/
  current
  state
```

- `manifest` lista arquivos instalados pelo pacote (base para `remove` e diagnósticos).
- `state` registra estado operacional do pacote (ex.: `installed`, `installing`, `broken`) e motivos/tempo (quando aplicável).
- `current` aponta para a versão “ativa” do pacote.

## Repositórios de ports

O `pkgm` suporta múltiplos repositórios dentro de um mesmo `PORTS_ROOT`, por exemplo:

```
/usr/src/pkgm/ports/
  core/<pkg>/recipe
  extra/<pkg>/recipe
  wayland/<pkg>/recipe
```

A ordem de busca é controlada por `PORTS_REPOS`.

Compatibilidade:
- Se você ainda usa o layout antigo com um diretório único (`PORTS_DIR`), o `pkgm` e o `revdep.sh` continuam funcionando.

## Hooks padronizados de recipe

Um `recipe` pode definir funções (opcionais). Quando não definidas, o `pkgm` usa defaults do port.

- Configure:
  - `pre_configure()` / `configure()` / `post_configure()`
- Build:
  - `pre_build()` / `build()` / `post_build()`
- Install (staging/DESTDIR):
  - `pre_install()` / `install_staging()` / `post_install()`
- Remove:
  - `pre_remove()` / `post_remove()`

Compatibilidade:
- Ports legados continuam aceitos; os hooks novos apenas padronizam um fluxo mais completo.

## Integração oficial com revdep

- Script: `bin/revdep.sh`
- Uso via wrapper:
  - `pkgm revdep`
  - `pkgm revdep --suggest`
  - `pkgm revdep --backend pkgm`

O `revdep` detecta binários/libs com dependências dinâmicas quebradas e tenta sugerir correções com comandos e o pacote provável responsável.

## Toolchain temporária (bootstrap)

O projeto inclui `bin/mktoolchain.sh`, que cria um **toolchain temporário** (x86_64 + glibc) em:

- `ROOTFS=/mnt/rootfs`
- `TOOLS_DIR=/mnt/rootfs/tools`

Exemplo:

```sh
sudo ./bin/mktoolchain.sh
export PATH="/mnt/rootfs/tools/bin:$PATH"
x86_64-pkgm-linux-gnu-gcc --version
```

O script segue um fluxo em “passes” (binutils/gcc, headers, glibc, gcc final) e realiza um *smoke test* compilando um programa simples.

Pré-requisitos típicos no host (além de um compilador funcional): `bison`, `flex`, `gawk`, `perl`, `python3` (ou `python`), `make`, `tar`, `patch`, `xz/gzip/bzip2`, além de ferramentas básicas (`sed`, `awk`, `grep`, `find`).

Se o host não for `x86_64`, o script aborta por padrão. Para forçar a execução (não recomendado), use `FORCE_ARCH=1`.

## Stage1 (utilitários mínimos em /tools)

Depois do toolchain temporário, o passo típico para um sistema *bootstrap* é construir um conjunto mínimo de programas em **`/tools`** para que o chroot fique utilizável e previsível.

O `pkgm` inclui:

- `bin/stage1.sh`: constrói e instala os utilitários mínimos em `TOOLS_DIR` (que vira `/tools` dentro do chroot).
- `bin/chrootctl.sh`: entra/sai do chroot de forma segura (mounts + cleanup) e suporta executar um comando e sair.

### `bin/stage1.sh`

Constrói (por padrão) os pacotes abaixo (em ordem):

- `bash`, `coreutils`, `diffutils`, `findutils`, `gawk`, `grep`, `gzip`, `make`, `patch`, `sed`, `tar`, `xz`, `bzip2`

Esses pacotes são instalados **diretamente em** `${TOOLS_DIR}` (por default `.../rootfs/tools`). Dentro do chroot isso aparece como `/tools`.

Exemplo:

```sh
sudo ./bin/mktoolchain.sh
sudo ./bin/stage1.sh
```

Variáveis principais (ajuste no topo do script ou exporte antes):

- `ROOTFS` (default: `/mnt/rootfs`)
- `TOOLS_DIR` (default: `$ROOTFS/tools`)
- `SRC_DIR` (cache de fontes)
- `BUILD_DIR` (diretório temporário de build)
- `JOBS` (default: `nproc`)
- `LFS_TGT` (default: `x86_64-pkgm-linux-gnu`)
- `STAGE1_PKGS` (lista de pacotes do stage1)

Ao final, o script também copia para `/tools/bin`:

- `pkgm` (para uso dentro do chroot)
- `revdep` (wrapper para `revdep.sh`)
- `mktoolchain`, `stage1`, `chrootctl`

### `bin/chrootctl.sh`

Fornece três modos:

- `enter`: entra no chroot interativo
- `run -- <cmd>`: entra, executa um comando e sai (desmontando tudo no final)
- `umount`: desmonta manualmente os mounts caso algo tenha ficado preso

Exemplos:

```sh
sudo ./bin/chrootctl.sh enter

sudo ./bin/chrootctl.sh run -- "pkgm --help"

sudo ./bin/chrootctl.sh build hello

sudo ./bin/chrootctl.sh umount
```

Mounts realizados (best-effort):

- `/dev` (bind)
- `/dev/pts` (devpts)
- `/proc` (proc)
- `/sys` (sysfs)
- `/run` (bind)

Se os diretórios existirem no host, `chrootctl.sh` também realiza:

- `$SRC_DIR` -> `/sources` (bind)
- `$BUILD_DIR` -> `/build` (bind)

Você também pode definir binds adicionais via `CHROOT_BINDS` no formato `origem:destino`:

- Exemplo: `CHROOT_BINDS="/usr/src/pkgm/ports:/ports"`

Para reduzir vazamento de ambiente do host, o chroot é iniciado com `env -i` e um conjunto mínimo de variáveis (`HOME`, `TERM`, `PATH`, `LC_ALL`).

Variáveis configuráveis (no ambiente):

- `ROOTFS` (default: `/mnt/rootfs`)
- `TOOLS_DIR` (default: `$ROOTFS/tools`)
- `SRC_DIR` (default: `/var/cache/pkgm/sources`)
- `BUILD_DIR` (default: `/var/tmp/pkgm-chroot-build`)
- `CHROOT_BINDS` (default: vazio)
- `DEVPTS_GID` (default: `5`)

## Stage2 (ferramentas de build em /usr)

Após entrar no chroot com o Stage1, muitos ports "de base" vão começar a exigir ferramentas adicionais de build
(por exemplo `m4`, `bison`, `flex`, `perl`, `autoconf/automake/libtool`, etc.).

O `pkgm` inclui `bin/stage2.sh`, que instala um conjunto conservador dessas ferramentas em `/usr` **dentro do chroot**,
aproveitando a toolchain em `/tools`.

Exemplo:

```sh
sudo ./bin/stage2.sh

# ou personalize o conjunto:
sudo STAGE2_PKGS='m4 ncurses pkgconf zlib perl bison flex' ./bin/stage2.sh
```

O `stage2.sh` faz download no host (`SRC_DIR`) e usa `chrootctl.sh` para compilar/instalar dentro do chroot.

## Configuração

O `pkgm` lê, nesta ordem:
1. `/etc/pkgm.conf`
2. `~/.config/pkgm.conf`

Arquivo exemplo: `etc/pkgm.conf.example`.

Principais variáveis:
- `ROOT`: raiz do sistema alvo (default: `/`)
- `INST_DB_DIR`: base do banco de instalação (default: `$ROOT/var/lib/pkgm/installed`)
- `PORTS_ROOT`: raiz de repositórios de ports (default: `/usr/src/pkgm/ports`)
- `PORTS_REPOS`: lista de repos (default: `core extra wayland`)
- `PORTS_DIR`: compatibilidade com layout antigo (opcional)
- `DISTFILES_DIR`: cache de tarballs e exports de `git+`
- `PKGOUT_DIR`: onde os pacotes resultantes são gerados

## Documentação adicional

- Guia oficial de ports: `docs/PORTS_GUIDE.md`

## Licença
Consulte o cabeçalho dos arquivos e o repositório do projeto, conforme aplicável.
