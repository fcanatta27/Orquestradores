# Guia de Ports (pkgm)

## Layout recomendado

Estrutura (multi-repo):

```text
ports/
  core/<pkg>/recipe
  extra/<pkg>/recipe
  wayland/<pkg>/recipe
```

Config (ex.: `/etc/pkgm.conf`):

```sh
PORTS_ROOT="/usr/src/pkgm/ports"
PORTS_REPOS="core extra wayland"
```

Compatibilidade (layout antigo “flat”):

```text
ports/<pkg>/recipe
```

Para usar o layout antigo:

```sh
PORTS_DIR="/usr/src/pkgm/ports"
```

## Variáveis obrigatórias

Na receita (`recipe`):

- `NAME`
- `VERSION`
- `SOURCE_URL`

Recomendado: `SOURCE_SHA256` (ou `SKIP`).

## Hooks padronizados

Se a receita declarar qualquer hook `pre_*`/`post_*`, o `pkgm` assume estilo novo:

- `pre_configure()` / `configure()` / `post_configure()`
- `pre_build()` / `build()` / `post_build()`
- `pre_install()` / `install_staging()` / `post_install()` (staging/DESTDIR)
- `pre_remove()` / `post_remove()`

Hooks de instalação real (opcionais): `pre_install_root()` / `post_install_root()`.

## Ferramentas

- `pkgm lint-port <pkg>`: checagens best-effort (variáveis, padrões perigosos; usa `shellcheck` se disponível).
- `pkgm doctor`: diagnóstico de estados `broken/partial`, locks abandonados e amostra de arquivos ausentes.
- `pkgm fix --broken`: tenta reconstruir e reinstalar pacotes marcados como `broken`.
- `pkgm revdep --suggest`: wrapper oficial para `revdep.sh`.


## Repositórios (core/extra/wayland)

O `pkgm` pode organizar ports em múltiplos repositórios sob `PORTS_ROOT`.
Estrutura recomendada:

```
ports/
  core/<pkg>/recipe
  extra/<pkg>/recipe
  wayland/<pkg>/recipe
```

A ordem de busca é definida por `PORTS_REPOS`.
