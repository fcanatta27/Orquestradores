Veja o tutorial completo em docs/README.md.
