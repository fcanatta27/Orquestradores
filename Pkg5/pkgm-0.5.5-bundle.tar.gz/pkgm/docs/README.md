# pkgm

`pkgm` é um gerenciador **mínimo** de pacotes no estilo *ports* + pacote binário (`.tar.gz`).  
Leitura recomendada: `docs/PORTS_GUIDE.md` (layout de repositórios, hooks padronizados, lint/doctor).

Objetivo: ser **auditável**, **previsível** e **sem bloat**.

## Conceitos

- **Port (receita)**: diretório `ports/<pkg>/recipe` com metadados e hooks de build.
- **Source cache**: tarballs e exports de `git+` ficam em `DISTFILES_DIR`.
- **Workdir**: build acontece em `BUILD_DIR/<nome>-<versão>/`.
- **Staging (DESTDIR)**: instalação sempre ocorre em `DESTDIR` (`$WORKDIR/.destdir`).
- **Pacote binário**: gerado em `PKG_CACHE_DIR/<nome>-<versão>.tar.gz`.
- **DB local**: `DB_DIR/<nome>/<versão>/` guarda `manifest` e `meta`.

## Instalação rápida

1. Coloque o `pkgm` em seu PATH (ex.: `/usr/local/bin/pkgm`).
2. Copie e ajuste a configuração:
   - `pkgm/etc/pkgm.conf.example` -> `/etc/pkgm.conf`
3. Garanta que `PORTS_ROOT` aponta para `pkgm/ports` (ou onde você mantém suas receitas).

## Uso

Formato:

- `pkgm [-n|--dry-run] <comando> ...`

Comandos principais:

- `pkgm env <pkg>`: imprime variáveis resolvidas (paths, versões, etc.).
- `pkgm fetch <pkg>`: baixa (ou obtém de cache) o source.
- `pkgm build <pkg>`: resolve deps, compila, instala em staging (DESTDIR), empacota e registra (sem instalar em ROOT).
- `pkgm package <pkg>`: empacota (a partir do staging) e registra no DB de construídos (usado por build).
- `pkgm install <pkg>`: instala o pacote em `ROOT` (por padrão `/`) e registra como instalado.
- `pkgm upgrade <pkg|all>`: upgrade inteligente (instala novo, remove obsoletos, roda `post_install`).
- `pkgm remove <pkg>`: remove arquivos conforme manifest.
- `pkgm clean <pkg|all>`: remove workdir de um pacote ou limpa todo `BUILD_DIR`.
- `pkgm list-installed`: lista pacotes presentes no DB.
- `pkgm list-files <pkg>`: lista arquivos do manifest.
- `pkgm verify <pkg>`: verifica se caminhos do manifest existem em `ROOT`.

### Dry-run

`-n`/`--dry-run` imprime as ações que seriam executadas **sem** alterar o sistema:

```sh
pkgm --dry-run build hello
pkgm -n install hello
```

### Privilégios (user build, root só no install/remove)

- `fetch`, `build`, `package`, `clean`, `list-*`, `verify`: rodam como **usuário normal** (cache em `~/.cache/pkgm` por padrão).
- `install`, `remove`, `upgrade`: exigem **root** apenas quando `ROOT=/` (ou quando `ROOT` não é gravável).  
  Exemplo:
  ```sh
  pkgm build sysvinit        # usuário normal
  sudo pkgm install sysvinit # só aqui precisa root
  ```

### Locks por pacote (concorrência)

Para evitar que o **mesmo** pacote seja processado simultaneamente por dois `pkgm`, existe um lock por pacote em `LOCK_DIR`.

- `pkgm install foo` em duas janelas: a segunda espera (ou falha se `LOCK_WAIT=0`).
- `pkgm install foo` e `pkgm install bar` podem rodar em paralelo.

## Formato de receita (ports/<pkg>/recipe)

Exemplo mínimo:

```sh
NAME="hello"
VERSION="1.0"
SOURCE_URL="https://exemplo/hello-1.0.tar.gz"
SOURCE_SHA256="SKIP"   # ou o sha256 real (recomendado)

DEPENDS=""
MAKE_DEPENDS=""

prepare() { :; }
configure() { ./configure --prefix=/usr; }
build() { make; }
install_staging() { make DESTDIR="$DESTDIR" install; }
```

### SOURCE_SHA256 (obrigatório)

- Deve ser o SHA-256 do tarball/export **ou** `SKIP`.
- `SKIP` é útil para protótipos, mas não é recomendado em produção.

### SOURCE_URL (formatos suportados)

1) URL direta:

```sh
SOURCE_URL="https://exemplo/foo.tar.gz"
```

2) Renomear no cache (`nome::url`), útil para URLs “não canônicas”:

```sh
SOURCE_URL="sysvinit-${VERSION}.tar.gz::https://github.com/slicer69/sysvinit/archive/refs/tags/${VERSION}.tar.gz"
```

3) Git export (`git+`), exige commit/tag/branch:

```sh
SOURCE_URL="git+https://github.com/user/repo.git"
SOURCE_COMMIT="a1b2c3d4..."
```

## Dependências

- `MAKE_DEPENDS`: necessárias apenas para compilar.
- `DEPENDS`: necessárias em runtime e também podem ser necessárias para build.

Resolução:
- `pkgm build <pkg>` resolve `MAKE_DEPENDS + DEPENDS`.
- `pkgm install <pkg>` resolve `DEPENDS`.
- Ciclos são detectados e resultam em erro.

## Segurança e boas práticas

- Receita é shell: trate como código com poder total.
- Prefira sempre `SOURCE_SHA256` real (evite `SKIP`).
- Instale em staging usando `DESTDIR` (o `pkgm` valida se `DESTDIR` ficou vazio).
- Use `ROOT` diferente de `/` em ambientes de teste (chroot/sysroot).

## Cores

As mensagens são coloridas quando stdout é TTY. Para desabilitar:

```sh
NO_COLOR=1 pkgm build hello
```

## Licença

MIT (veja `LICENSE`).
