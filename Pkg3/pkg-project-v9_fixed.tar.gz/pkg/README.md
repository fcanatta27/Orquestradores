# pkg — gerenciador simples de pacotes (source-based) para um sistema “do zero” (stage0/stage1)

O **pkg** é um gerenciador de pacotes por **compilação a partir do repositório de fontes**, desenhado para um sistema Linux montado “from scratch” (stage0/stage1), com foco em:

- **build** em **DESTDIR** (sempre), sem tocar diretamente no `/` durante o empacotamento;
- **install/remove** com banco de dados de arquivos instalados;
- **dependências simples** (DEPENDS e MAKEDEPENDS) com detecção de ciclo;
- **upgrade** do sistema (rebuild/reinstall do que mudou no repo);
- **UI/UX** mais “legível” com cores, fila e progresso.

> Este projeto é intencionalmente direto (para uso pessoal). Ele não tenta ser uma distro completa com resolução SAT e múltiplos provedores.

---

## 1) Layout do repositório

### Layout esperado

```
repo/
  core/
    <programa>/
      package
      build/        (opcional: patches, scripts auxiliares, arquivos locais)
  extra/
    ...
  wayland/
    ...
```

- `package` é a **receita** (arquivo Bash) que define variáveis e funções.
- `build/` é opcional e serve para arquivos auxiliares (patches, scripts, etc).

### Diretórios internos do pkg

Defaults:

- **Banco (DB)**: `/var/lib/pkg/db/<pkg>/`
  - `meta` (key=value: nome, versão, release, data)
  - `files` (lista de arquivos/dirs instalados sob `/`)
- **Cache**: `/var/cache/pkg/`
  - `src/<pkg>/` (fontes baixadas/copias — **cache persistente**)
  - `work/<pkg>/build/` (diretório de build)
  - `work/<pkg>/destdir/` (**DESTDIR** sempre)
  - `logs/<pkg>-YYYYmmdd-HHMMSS.log` (logs de build)

---

## 2) Instalação

### 2.1 Script `pkg`

Instale o script em um diretório no PATH:

```sh
install -m 0755 pkg/bin/pkg /usr/bin/pkg
```



### 2.1.1 Script `revdep`

Instale o script `revdep` (verificador de dependências reversas) em um diretório no PATH:

```sh
install -m 0755 pkg/bin/revdep /usr/bin/revdep
```

### 2.1.2 Script `chroot-pkg`

Instale o helper de chroot (recomendado em `/usr/sbin`):

```sh
install -m 0755 pkg/sbin/chroot-pkg /usr/sbin/chroot-pkg
```

### 2.2 Configuração opcional `/etc/pkg.conf`

### 2.3 Arquivo de configuração (incluído no projeto)

O projeto inclui um arquivo de exemplo em:

- `pkg/etc/pkg.conf`

Para ativar:

```sh
install -m 0644 pkg/etc/pkg.conf /etc/pkg.conf
```

Em seguida, edite `/etc/pkg.conf` conforme seu sistema.



Exemplo:

```sh
# /etc/pkg.conf
REPO_ROOT="/home/fernando/repo"

DB_ROOT="/var/lib/pkg"
CACHE_ROOT="/var/cache/pkg"

JOBS=8
MAKEFLAGS="-j8"

# Downloader:
# DL_CMD="curl -L --fail --retry 3 -o"
# DL_CMD="wget -O"

COLOR=1
ASSUME_YES=0
FORCE=0
```

---

## 3) Comandos

### Ajuda e infos

- `pkg help`
- `pkg version`
- `pkg tree`

### Repositório

- `pkg search <termo>`
- `pkg fetch [--with-deps] <pkg...>` (baixa fontes e valida checksums sem compilar)

### Build

- `pkg build <pkg>`
- `pkg pack <pkg>` (gera um binpkg reutilizável; não instala)

Faz build + stage em:

- `.../work/<pkg>/build`
- `.../work/<pkg>/destdir`

### Instalação (com deps e makedeps)

- `pkg install <pkg...>`

Gera plano em ordem (deps primeiro) incluindo:

- `DEPENDS` (runtime)
- `MAKEDEPENDS` (build-time)

> Observação: MAKEDEPENDS são instalados se faltarem, mas não são removidos automaticamente depois.

### Remoção

- `pkg remove <pkg...>`

Remove apenas o que foi registrado no `files` do pacote.

### Reinstalação

- `pkg reinstall <pkg...>`

### Inventário

- `pkg list`
- `pkg info <pkg>`
- `pkg files <pkg>`
- `pkg owner <path>` / `pkg provide <path>`: mostra qual pacote instalado possui um arquivo do sistema

### Dependências

- `pkg depends <pkg>`  
  Lista o *closure* (ordem crua).

- `pkg deps <pkg>`  
  Lista as dependências com marcação de instalado:

Exemplo de saída (aproximado):

```
-- dependencies ([ ✔️ ] = installed)

[✔️] zlib
[✔️] xfree86
[     ] libjpeg
[     ] libpng
[     ] freetype

-- makedepends ([ ✔️ ] = installed)

[✔️] pkgconf
[     ] autoconf

--》 missing packages libjpeg from foo libpng from foo autoconf from foo
```

### Atualizações

- `pkg check-updates`
- `pkg upgrade`

---

## 4) Opções globais

- `--repo <path>`: muda a raiz do repo
- `--assume-yes`: não pergunta confirmação
- `--force`: ignora algumas travas de segurança (ex.: DESTDIR vazio)
- `--dry-run`: **não executa**; apenas mostra plano/ações
- `--no-color`: desliga cores

---

## 5) Receita `repo/<cat>/<pkg>/package`

Arquivo bash. Deve definir variáveis e funções.

### Variáveis obrigatórias

- `PKGNAME="nome"`
- `PKGVER="1.2.3"`

### Variáveis opcionais

- `PKGREL="1"` (default: 1)
- `PKGDESC`, `PKGURL`, `LICENSE`, `ARCH`

### Dependências

Strings com itens separados por espaço:

- `DEPENDS="zlib openssl"`
- `MAKEDEPENDS="pkgconf autoconf automake"`

### Fontes

Você pode usar entradas simples ou com alias de nome de arquivo:

- simples: `SOURCE="https://example.com/prog-1.0.tar.gz local.patch"`
- com alias: `SOURCE="prog.tar.gz::https://example.com/prog-1.0.tar.gz"`

O formato `dest::url` baixa/copía o conteúdo de `url` mas salva como `dest` dentro do cache de fontes do pacote.

### Checksums (opcionais)

Você pode usar **SHA256** ou **MD5**:

- `SHA256SUMS="abc... SKIP ..."`
  - ou `SHA256="..."` (alias)
- `MD5SUMS="abc... SKIP ..."`
  - ou `MD5="..."` (alias)

Regras:

- Se `SHA256*` existir, ele tem preferência sobre MD5.
- `SKIP` pula verificação do item correspondente.
- Se não houver checksums definidos, nenhuma verificação é feita.

### Funções obrigatórias

- `build()`: compila/prepara no `$PKG_BUILDDIR`
- `package()`: instala no `$DESTDIR` (sempre)

### Hook opcional

- `post_install()`: executado **após** instalar no `/` (requer root).

> Use com cuidado: esse hook mexe no sistema já instalado. Ideal para `ldconfig`, caches, ícones, schemas, etc.

### Variáveis de ambiente disponíveis

- `MAKEFLAGS`, `DESTDIR`
- `PKG_WORKDIR`, `PKG_SRCDIR`, `PKG_BUILDDIR`, `PKG_PKGDIR`
- `CCACHE_DIR`

---

## 6) Exemplo (hello)

`repo/core/hello/package`:

```bash
PKGNAME="hello"
PKGVER="2.12.1"
PKGREL="1"
PKGDESC="GNU hello"
PKGURL="https://www.gnu.org/software/hello/"
LICENSE="GPL-3.0-or-later"

DEPENDS=""
MAKEDEPENDS=""

SOURCE="https://ftp.gnu.org/gnu/hello/hello-2.12.1.tar.gz"
SHA256SUMS="8d99142afd92564df1c6b2d1d7b2a9b21f087d9bcbf4b028b4d3f1227dd92a31"

build() {
  cd hello-${PKGVER}
  ./configure --prefix=/usr
  make ${MAKEFLAGS}
}

package() {
  cd hello-${PKGVER}
  make DESTDIR="${DESTDIR}" install
}

post_install() {
  # opcional
  :
}
```

Instalar:

```sh
pkg install hello
```

---

## 7) Como funciona (pipeline)

1. **Planejamento**
   - carrega receitas
   - expande `DEPENDS` e `MAKEDEPENDS`
   - detecta ciclos (se houver, aborta)
2. **Fetch**
   - baixa fontes para `src/<pkg>` (cache persistente)
   - valida sha256/md5 se definido
3. **Build**
   - cria `work/<pkg>/build`
   - executa `build()`
4. **Stage**
   - limpa `DESTDIR`
   - executa `package()` instalando no `DESTDIR`
5. **Install**
   - copia `DESTDIR` para `/` via tar stream
   - registra DB
   - executa `post_install()` se existir

---

## 8) Segurança, bugs e limitações (análise)

### Correções e proteções implementadas

- **Detecção de ciclo** na resolução de deps.
- **Sanitização** do nome do pacote (evita path traversal).
- **Lock global** (`/run/pkg.lock`) para evitar duas execuções concorrentes.
- **Recusa DESTDIR vazio** para evitar instalações acidentais (override com `--force`).
- **Cache persistente de fontes**: o build limpa `work/`, mas mantém `src/`.
- **Checksums flexíveis**: sha256 ou md5, com suporte a `SKIP`.
- **Dry-run**: mostra plano sem executar.

### Limitações por design

- Não há resolvedor SAT.
- `PROVIDES/CONFLICTS/REPLACES` não estão implementados.
- Não faz remoção automática de dependências órfãs.

---

## 9) Requisitos mínimos do sistema

Ferramentas recomendadas:

- `bash`, `coreutils`, `findutils`, `tar`, `grep`, `sed`, `awk`
- `util-linux` (para `flock`)
- downloader: `curl` ou `wget`
- checksums: `sha256sum` (coreutils) e/ou `md5sum`

---

## 10) Licença

Escolha uma licença conforme sua necessidade.


---

## 11) revdep.sh (detecção de linkagem quebrada)

O `revdep.sh` (incluído no projeto) procura binários/ELFs que estejam com dependências dinâmicas faltando (saída do `ldd` com `not found`).

### Instalação

```sh
install -m 0755 revdep.sh /usr/bin/revdep.sh
install -m 0644 etc/revdep.conf /etc/revdep.conf
install -d /etc/revdep.d
install -m 0644 etc/revdep.d/local.conf /etc/revdep.d/local.conf
```

### Uso

- Verificar o sistema inteiro:

```sh
revdep.sh
```

- Verificar apenas um pacote instalado:

```sh
revdep.sh -p <pkg>
```

- Mostrar todos os arquivos afetados:

```sh
revdep.sh -a
```

- Rebuild/reinstall automaticamente os pacotes donos dos arquivos quebrados (root):

```sh
revdep.sh -r
```

- Dry-run de rebuild:

```sh
revdep.sh -r --dry-run
```

### Sugestões automáticas

Para cada biblioteca ausente, o script sugere comandos típicos:

- `pkg search <token>` (heurística para achar pacotes prováveis)
- `ldconfig` se a biblioteca existir no disco mas não estiver no cache do loader

> Nota: a identificação do “dono” do arquivo é feita consultando a base do `pkg` (`/var/lib/pkg/db/<pkg>/files`).


---

## 12) Empacotamento binário (binpkg) e strip

O `pkg` pode gerar um **pacote binário** a partir do `DESTDIR` para acelerar reinstalações.

### Comandos

- Gerar binpkg:

```sh
pkg pack <pkg>
```

- Listar cache de binpkgs:

```sh
pkg binpkg list
```

- Limpar cache:

```sh
pkg binpkg clean
```

### Uso automático

Por padrão, `pkg install` tenta usar um binpkg existente (se `BINPKG_USE=1`). Caso não exista, ele compila normalmente.

Variáveis relevantes (em `/etc/pkg.conf`):

- `BINPKG_ROOT` (default: `/var/cache/pkg/binpkgs`)
- `BINPKG_USE=1` (usa binpkg se existir)
- `BINPKG_COMPRESS=zstd|gz`

### Strip

Após `package()` o `pkg` pode executar `strip` nos objetos ELF dentro do `DESTDIR` (controlado por `STRIP_BINARIES`).

- `STRIP_BINARIES=1` (default)
- `STRIP_FLAGS="--strip-unneeded"`

Você também pode desativar por comando:

```sh
pkg --no-strip install <pkg>
```


### Sources via Git

Você pode usar `git+` em `SOURCE` para clonar um repositório para o cache do pacote.

Formato:

- `SOURCE="nome::git+https://example.com/repo.git#commit=<sha>&branch=<branch>"`

Exemplo:

```bash
SOURCE="src::git+https://github.com/mesonbuild/meson.git#commit=abcdef1234567890"
```

O conteúdo ficará em:

- `$PKG_SRCDIR/src/` (um diretório git clonado e checkout no commit)

Observação: checksums não se aplicam a fontes `git+` (o pinning é feito via `commit=`).


---

## 13) Detecção de mudanças de receita (recipe hash)

O `pkg` registra no DB o `recipe_hash` (sha256 do arquivo `package`). Assim, `pkg check-updates` e `pkg upgrade` também sinalizam rebuild quando a receita muda (patches/flags) mesmo sem mudar a versão.


---

## 14) Trabalhando em chroot (montagem segura, entrada e execução de comandos)

Para manter seu sistema “from scratch” isolado e reprodutível, o projeto inclui o script:

- `chroot-pkg.sh`

Ele monta **/proc, /sys, /dev, /dev/pts e /run**, faz **bind** do seu **repo**, do **cache do pkg**, do **db do pkg**, e (opcionalmente) de:

- `/etc/resolv.conf` (rede/DNS dentro do chroot)
- `/etc/pkg.conf` (configuração do pkg dentro do chroot)

### 14.1 Instalação do chroot helper

No host (fora do chroot):

```sh
install -m 0755 chroot-pkg.sh /usr/bin/chroot-pkg
```

### 14.2 Primeira configuração recomendada

1) Defina onde está o chroot e onde está seu repo local:

- chroot: `/mnt/sysroot` (exemplo)
- repo: `/home/<user>/repo`

2) Ajuste `/etc/pkg.conf` no host para apontar para o repo (esse arquivo pode ser bindado para o chroot):

```sh
REPO_ROOT="/home/<user>/repo"
```

> Se você preferir, pode manter um `/etc/pkg.conf` diferente dentro do chroot e usar `--no-pkgconf`.

### 14.3 Montar e desmontar

```sh
sudo chroot-pkg -C /mnt/sysroot -R /home/<user>/repo mount
sudo chroot-pkg -C /mnt/sysroot status
sudo chroot-pkg -C /mnt/sysroot umount
```

A montagem é **idempotente** (não “duplica” mounts) e a desmontagem é feita em **ordem reversa**, com fallback seguro.

### 14.4 Entrar no chroot (shell interativo)

```sh
sudo chroot-pkg -C /mnt/sysroot -R /home/<user>/repo enter
```

Para usar outro shell:

```sh
sudo chroot-pkg -C /mnt/sysroot enter /bin/sh
```

Por padrão, ao sair do shell ele desmonta. Para manter montado:

```sh
sudo chroot-pkg -C /mnt/sysroot --keep-mounts enter
```

### 14.5 Executar comandos dentro do chroot sem “ficar dentro”

Executar diretamente:

```sh
sudo chroot-pkg -C /mnt/sysroot exec pkg check-updates
sudo chroot-pkg -C /mnt/sysroot exec pkg upgrade
```

Atalho para `pkg`:

```sh
sudo chroot-pkg -C /mnt/sysroot pkg upgrade
```

### 14.6 Bind mounts relevantes para o pkg

O script faz bind (host -> chroot):

- Repo: `<host REPO_DIR>` -> `<chroot>/repo` (default)
- Cache: `/var/cache/pkg` -> `<chroot>/var/cache/pkg`
- DB: `/var/lib/pkg` -> `<chroot>/var/lib/pkg`
- resolv.conf: `/etc/resolv.conf` -> `<chroot>/etc/resolv.conf` (opcional)
- pkg.conf: `/etc/pkg.conf` -> `<chroot>/etc/pkg.conf` (opcional)

Você pode ajustar caminhos com flags:

```sh
sudo chroot-pkg -C /mnt/sysroot --repo-mount /mnt/repo -R /home/<user>/repo mount
sudo chroot-pkg -C /mnt/sysroot --cache /srv/pkg-cache --db /srv/pkg-db mount
```

---

## 15) Tutorial completo: repo via Git (GitLab), configuração e atualização do sistema

### 15.1 Estrutura do repositório (no GitLab e local)

No GitLab, mantenha:

```
repo/
  core/<pkg>/package
  extra/<pkg>/package
  wayland/<pkg>/package
```

Localmente, clone para um caminho estável (ex.: `/home/<user>/repo`):

```sh
cd /home/<user>
git clone git@gitlab.com:<usuario>/<seu-repo>.git repo
```

### 15.2 Configurar o pkg para usar o repo

Edite `/etc/pkg.conf`:

```sh
REPO_ROOT="/home/<user>/repo"
```

Teste:

```sh
pkg search hello
```

### 15.3 Sincronizar com o GitLab (atualizar receitas)

No host (fora do chroot), atualize o repo:

```sh
cd /home/<user>/repo
git pull --rebase
```

> Recomenda-se usar branches (main/testing) para reduzir risco.

### 15.4 Atualizar (upgrade) com o pkg

1) Ver o que mudou:

```sh
pkg check-updates
```

2) Aplicar upgrade:

```sh
pkg upgrade
```

O `pkg` atualiza quando:
- a versão (`PKGVER/PKGREL`) mudou, ou
- o `recipe_hash` mudou (receita alterada, mesmo sem mudar versão).

### 15.5 Atualizar dentro do chroot (fluxo recomendado)

```sh
cd /home/<user>/repo
git pull --rebase

sudo chroot-pkg -C /mnt/sysroot -R /home/<user>/repo pkg check-updates
sudo chroot-pkg -C /mnt/sysroot -R /home/<user>/repo pkg upgrade
sudo chroot-pkg -C /mnt/sysroot -R /home/<user>/repo exec revdep.sh
```

Se o `revdep.sh` apontar binários quebrados, normalmente resolve com:

```sh
sudo chroot-pkg -C /mnt/sysroot pkg reinstall <pacote>
```

### 15.6 Recuperação rápida (rollback) com Git

Se um conjunto de receitas quebrar o sistema:

```sh
cd /home/<user>/repo
git log --oneline
git checkout <commit_bom>

sudo chroot-pkg -C /mnt/sysroot pkg upgrade
```

### 15.7 Modo “fetch” (baixar fontes sem compilar)

Para baixar/verificar fontes antes do build:

```sh
pkg fetch --with-deps <pkg>
```


---

## 16) Workflow “daily driver” (5 comandos) para manter o sistema limpo e previsível

Este fluxo assume que seu **repositório de receitas** é versionado em Git (ex.: GitLab) e que você atualiza o sistema dentro do chroot.

### 16.1 No host: sincronizar receitas (Git) e revisar mudanças
1) Sincronize o repo:

```sh
cd /home/<user>/repo
git pull --rebase
```

2) (Opcional, recomendado) veja o que mudou:

```sh
git log --oneline -n 10
```

### 16.2 No chroot: 5 comandos “padrão” (previsíveis)

1) Montar chroot (se ainda não estiver montado):

```sh
sudo chroot-pkg -C /mnt/sysroot -R /home/<user>/repo mount
```

2) Ver o que precisa de upgrade (versão ou recipe_hash):

```sh
sudo chroot-pkg -C /mnt/sysroot pkg check-updates
```

3) Aplicar upgrade:

```sh
sudo chroot-pkg -C /mnt/sysroot pkg upgrade
```

4) Verificar linkagem quebrada (pós-upgrade):

```sh
sudo chroot-pkg -C /mnt/sysroot exec revdep.sh
```

5) Desmontar chroot:

```sh
sudo chroot-pkg -C /mnt/sysroot umount
```

> Se você preferir manter montado durante uma sessão longa, use `--keep-mounts` no `enter` e pule o passo 5 até terminar.

---

## 17) Operações de manutenção e administração (combinações úteis)

### 17.1 Pré-flight: baixar fontes antes de compilar
Útil para validar rede/checksums antes do build:

```sh
pkg fetch --with-deps <pkg>
```

Dentro do chroot, sem entrar:

```sh
sudo chroot-pkg -C /mnt/sysroot pkg fetch --with-deps <pkg>
```

### 17.2 Criar binpkgs para acelerar reinstalações
Gerar binpkg (sem instalar):

```sh
pkg pack <pkg>
```

Listar/limpar cache:

```sh
pkg binpkg list
pkg binpkg clean
```

### 17.3 Rebuild direcionado (quando algo quebrou)
- Rebuild de um pacote:

```sh
pkg reinstall <pkg>
```

- Ver quem “possui” um arquivo:

```sh
pkg owner /usr/bin/<bin>
pkg provide /usr/lib/libXYZ.so.1
```

### 17.4 Limpeza seletiva (sem perder previsibilidade)
- Limpar apenas binpkgs:

```sh
pkg binpkg clean
```

- Limpar fontes de um pacote (forçar refetch na próxima):

```sh
rm -rf /var/cache/pkg/src/<pkg>
```

- Ver estatísticas do ccache:

```sh
ccache --show-stats
```

- Zerar estatísticas (não apaga cache):

```sh
ccache --zero-stats
```

- Limpar ccache (use só se necessário):

```sh
ccache --clear
```

---

## 18) Depuração e correções (método simples e confiável)

### 18.1 Quando um build falha
1) Rode apenas o build (sem instalar):

```sh
pkg build <pkg>
```

2) Consulte o log em:

- `/var/cache/pkg/logs/`

3) Estratégias típicas e correções:
- Falta de ferramenta de build: adicionar em `MAKEDEPENDS`
- Falta de lib de runtime: adicionar em `DEPENDS`
- Fonte corrompida: o `pkg fetch` + verificação refaz download automaticamente; se necessário:

```sh
rm -rf /var/cache/pkg/src/<pkg>
pkg fetch <pkg>
```

### 18.2 Quando instalou mas o binário não roda
1) Execute revdep (global ou por pacote):

```sh
revdep.sh
revdep.sh -p <pkg>
```

2) Se faltar `libXYZ.so`:
- use as sugestões do revdep (`pkg search ...`)
- instale o provedor (quando indicado)
- rode `ldconfig` (se aplicável)

3) Se o revdep apontar o “owner” do binário quebrado:

```sh
pkg reinstall <owner>
```

### 18.3 Quando quebrou após upgrade
Fluxo mínimo:

```sh
pkg check-updates
pkg upgrade
revdep.sh
```

Se persistir, faça rollback das receitas com Git e reaplique upgrade:

```sh
cd /home/<user>/repo
git checkout <commit_bom>
pkg upgrade
```

### 18.4 Quando suspeitar de DB inconsistente
- `pkg owner` retornando vazio para arquivos que deveriam ser gerenciados indica:
  - arquivo criado manualmente, ou
  - instalação fora do pkg, ou
  - registro antigo removido.

Correção simples (sem complexidade):
- reinstale o pacote que você acredita ser o dono:

```sh
pkg reinstall <pkg>
```

---

## 19) Recomendações práticas para manter simplicidade

- Use `git pull --rebase` + `pkg check-updates` antes de qualquer upgrade.
- Prefira **commits fixos** em `git+` sources para reprodutibilidade.
- Use `pkg fetch --with-deps` antes de grandes rebuilds (evita perder tempo por falha de rede).
- Use `pkg pack` para pacotes “pesados” e mantenha binpkgs para reinstalações rápidas.
- Após upgrades grandes, rode `revdep.sh` e resolva “owners” quebrados com `pkg reinstall`.


---

## Toolchain temporário (bootstrap)

O projeto inclui `toolchain/build-temp-toolchain.sh` para construir um toolchain temporário (x86_64+glibc) em `/mnt/rootfs/tools`.
Veja `toolchain/README.md` para detalhes.
