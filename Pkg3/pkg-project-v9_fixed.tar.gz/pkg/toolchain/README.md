# Toolchain temporário (x86_64 + glibc) em /mnt/rootfs/tools

Este diretório contém o script **build-temp-toolchain.sh** para construir um toolchain temporário (binutils+gcc+linux headers+glibc) em:

- `/mnt/rootfs/tools`

Ele é inspirado no fluxo clássico de *temporary toolchain* (estilo LFS), com foco em simplicidade e logs.

## Versões (default do script)

- binutils 2.45.1
- GCC 15.2.0
- Linux headers 6.18.2
- glibc 2.42
- GMP 6.3.0
- MPFR 4.2.2
- MPC 1.3.1
- isl 0.27

## Requisitos do host

Você precisa ter um host Linux funcional com ferramentas de build básicas:
`bash, make, gcc/g++, binutils, tar, xz/gzip/bzip2, patch, sed, awk, perl, python3`.

## Uso rápido

```sh
cd toolchain
sudo ./build-temp-toolchain.sh
```

## Executar por etapa

```sh
sudo STEP=binutils1 ./build-temp-toolchain.sh
sudo STEP=gcc1 ./build-temp-toolchain.sh
sudo STEP=linuxhdr ./build-temp-toolchain.sh
sudo STEP=glibc ./build-temp-toolchain.sh
sudo STEP=gcc2 ./build-temp-toolchain.sh
```

## Ajustes por variáveis de ambiente

```sh
sudo ROOTFS=/mnt/rootfs TOOLS=/mnt/rootfs/tools TARGET=x86_64-lfs-linux-gnu JOBS=8 ./build-temp-toolchain.sh
```

## Logs

Logs ficam em:

- `/mnt/rootfs/build/logs/*.log`

## Observações importantes

1) Este script **não** é um bootstrap “stage0” puro. Ele exige um host com compilador já funcional.
2) A instalação é em `/mnt/rootfs/tools` e cria (opcionalmente) um symlink `/tools` (se rodar como root).
3) Para máxima reprodutibilidade, considere fixar versões via env ou manter um snapshot do script.
