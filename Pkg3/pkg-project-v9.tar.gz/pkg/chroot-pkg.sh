#!/usr/bin/env bash
# chroot-pkg.sh - helper de chroot para sistemas "from scratch" com pkg
#
# Objetivos:
# - Montagem/desmontagem seguras (idempotentes)
# - Entrar no chroot (shell interativo)
# - Rodar comandos no chroot sem ficar dentro (exec)
# - Binds para repo do pkg, cache, db, e resolv.conf
#
# Requisitos: bash, mount/umount (util-linux), chroot (coreutils), findmnt (util-linux recomendado)
#
set -Eeuo pipefail

die(){ echo "ERROR: $*" >&2; exit 1; }
msg(){ echo "[chroot-pkg] $*"; }

need_cmd(){ command -v "$1" >/dev/null 2>&1 || die "missing command: $1"; }

need_cmd mount
need_cmd umount
need_cmd chroot

# Defaults (podem ser sobrescritos por env ou flags)
: "${CHROOT_DIR:=/mnt/chroot}"
: "${REPO_DIR:=/repo}"                  # caminho NO HOST
: "${REPO_MOUNT:=/repo}"                # caminho DENTRO DO CHROOT
: "${PKG_CACHE_HOST:=/var/cache/pkg}"   # host cache
: "${PKG_DB_HOST:=/var/lib/pkg}"        # host db
: "${PKG_CACHE_MOUNT:=/var/cache/pkg}"  # chroot cache
: "${PKG_DB_MOUNT:=/var/lib/pkg}"       # chroot db
: "${BIND_ETC_PKGCONF:=1}"              # bind /etc/pkg.conf do host? (1/0)
: "${HOST_PKGCONF:=/etc/pkg.conf}"
: "${CHROOT_PKGCONF:=/etc/pkg.conf}"
: "${BIND_RESOLV:=1}"
: "${HOST_RESOLV:=/etc/resolv.conf}"
: "${CHROOT_RESOLV:=/etc/resolv.conf}"
: "${KEEP_MOUNTS:=0}"                   # não desmonta ao sair do enter se 1

usage(){
  cat <<EOF
Usage:
  $(basename "$0") [options] <command> [args...]

Commands:
  mount                 Mount all required filesystems and binds
  umount                Unmount all mounts created by this script (safe, reverse order)
  status                Show mount status under CHROOT_DIR
  enter [shell]         Enter chroot (default: /bin/bash)
  exec <cmd...>         Run command inside chroot without entering interactively
  pkg <args...>         Shortcut: exec pkg <args...>

Options:
  -C, --chroot <dir>            Chroot root (default: $CHROOT_DIR)
  -R, --repo <dir>              Repo path on host (default: $REPO_DIR)
      --repo-mount <path>       Repo mount path in chroot (default: $REPO_MOUNT)
      --cache <dir>             Host pkg cache dir (default: $PKG_CACHE_HOST)
      --db <dir>                Host pkg db dir (default: $PKG_DB_HOST)
      --no-resolv               Do not bind resolv.conf
      --no-pkgconf              Do not bind /etc/pkg.conf
      --keep-mounts             Keep mounts after 'enter' exits
  -h, --help                    Show help

Examples:
  sudo $(basename "$0") -C /mnt/sysroot -R /home/user/repo mount
  sudo $(basename "$0") -C /mnt/sysroot enter
  sudo $(basename "$0") -C /mnt/sysroot exec pkg check-updates
  sudo $(basename "$0") -C /mnt/sysroot pkg upgrade
EOF
}

is_mounted() {
  local target="$1"
  if command -v findmnt >/dev/null 2>&1; then
    findmnt -rn "$target" >/dev/null 2>&1
  else
    grep -qs " $target " /proc/mounts
  fi
}

ensure_file(){
  local f="$1"
  ensure_dir "$(dirname "$f")"
  [[ -e "$f" ]] || : > "$f"
}

ensure_dir(){
  local d="$1"
  [[ -d "$d" ]] || mkdir -p "$d"
}

mount_one(){
  local src="$1" target="$2" fstype="${3:-}" opts="${4:-}"
  ensure_dir "$target"
  if is_mounted "$target"; then
    msg "already mounted: $target"
    return 0
  fi
  msg "mount: $src -> $target"
  if [[ -n "$fstype" ]]; then
    mount -t "$fstype" ${opts:+-o "$opts"} "$src" "$target"
  else
    mount ${opts:+-o "$opts"} --bind "$src" "$target"
  fi
}

umount_one(){
  local target="$1"
  if is_mounted "$target"; then
    msg "umount: $target"
    umount -R "$target" 2>/dev/null || umount "$target"
  fi
}

do_mount() {
  [[ -d "$CHROOT_DIR" ]] || die "CHROOT_DIR not found: $CHROOT_DIR"

  # Base FS
  mount_one proc  "$CHROOT_DIR/proc" proc "nosuid,nodev,noexec"
  mount_one sysfs "$CHROOT_DIR/sys"  sysfs "nosuid,nodev,noexec"
  mount_one udev  "$CHROOT_DIR/dev"  devtmpfs "mode=0755,nosuid"
  ensure_dir "$CHROOT_DIR/dev/pts"
  mount_one devpts "$CHROOT_DIR/dev/pts" devpts "gid=5,mode=620,nosuid,noexec"
  ensure_dir "$CHROOT_DIR/run"
  if ! is_mounted "$CHROOT_DIR/run"; then
    msg "mount: tmpfs -> $CHROOT_DIR/run"
    mount -t tmpfs -o "mode=0755,nosuid,nodev" tmpfs "$CHROOT_DIR/run"
  fi

  # Repo bind
  [[ -d "$REPO_DIR" ]] || die "Repo dir not found on host: $REPO_DIR"
  mount_one "$REPO_DIR" "$CHROOT_DIR$REPO_MOUNT"

  # pkg cache/db binds (host <-> chroot)
  ensure_dir "$PKG_CACHE_HOST"
  ensure_dir "$PKG_DB_HOST"
  mount_one "$PKG_CACHE_HOST" "$CHROOT_DIR$PKG_CACHE_MOUNT"
  mount_one "$PKG_DB_HOST" "$CHROOT_DIR$PKG_DB_MOUNT"

  # resolv.conf
  if [[ "$BIND_RESOLV" == "1" ]]; then
    [[ -f "$HOST_RESOLV" ]] || die "Host resolv.conf not found: $HOST_RESOLV"
    ensure_file "$CHROOT_DIR$CHROOT_RESOLV"
    if is_mounted "$CHROOT_DIR$CHROOT_RESOLV"; then
      : # unlikely (file mount), ignore
    fi
    msg "bind resolv.conf"
    mount --bind "$HOST_RESOLV" "$CHROOT_DIR$CHROOT_RESOLV"
  fi

  # pkg.conf
  if [[ "$BIND_ETC_PKGCONF" == "1" ]]; then
    if [[ -f "$HOST_PKGCONF" ]]; then
      ensure_file "$CHROOT_DIR$CHROOT_PKGCONF"
      msg "bind pkg.conf"
      mount --bind "$HOST_PKGCONF" "$CHROOT_DIR$CHROOT_PKGCONF"
    else
      msg "WARN: $HOST_PKGCONF not found; skipping bind (create it to configure pkg)"
    fi
  fi
}

do_umount() {
  # Reverse order, safe even if not mounted
  umount_one "$CHROOT_DIR$CHROOT_PKGCONF" || true
  umount_one "$CHROOT_DIR$CHROOT_RESOLV" || true
  umount_one "$CHROOT_DIR$PKG_DB_MOUNT" || true
  umount_one "$CHROOT_DIR$PKG_CACHE_MOUNT" || true
  umount_one "$CHROOT_DIR$REPO_MOUNT" || true
  umount_one "$CHROOT_DIR/dev/pts" || true
  umount_one "$CHROOT_DIR/dev" || true
  umount_one "$CHROOT_DIR/run" || true
  umount_one "$CHROOT_DIR/sys" || true
  umount_one "$CHROOT_DIR/proc" || true
}

do_status() {
  msg "CHROOT_DIR=$CHROOT_DIR"
  if command -v findmnt >/dev/null 2>&1; then
    findmnt -R "$CHROOT_DIR" || true
  else
    grep " $CHROOT_DIR" /proc/mounts || true
  fi
}

chroot_run() {
  local cmd=("$@")
  [[ -x "$CHROOT_DIR/bin/sh" || -x "$CHROOT_DIR/bin/bash" ]] || die "chroot missing shell (/bin/sh or /bin/bash)"
  # Minimal environment
  env -i \
    HOME=/root \
    TERM="${TERM:-linux}" \
    PATH=/usr/sbin:/usr/bin:/sbin:/bin \
    CHROOT=1 \
    chroot "$CHROOT_DIR" "${cmd[@]}"
}

do_enter() {
  local shell="${1:-/bin/bash}"
  do_mount
  msg "entering chroot: $CHROOT_DIR ($shell)"
  chroot_run "$shell" -l
  if [[ "$KEEP_MOUNTS" != "1" ]]; then
    do_umount
  else
    msg "keeping mounts (KEEP_MOUNTS=1)"
  fi
}

do_exec() {
  shift || true
  [[ "$#" -ge 1 ]] || die "usage: exec <cmd...>"
  do_mount
  chroot_run "$@"
}

# ----------------------- argument parsing
if [[ "$#" -lt 1 ]]; then usage; exit 1; fi

args=()
while [[ "$#" -gt 0 ]]; do
  case "$1" in
    -C|--chroot) CHROOT_DIR="${2:-}"; shift 2 ;;
    -R|--repo) REPO_DIR="${2:-}"; shift 2 ;;
    --repo-mount) REPO_MOUNT="${2:-}"; shift 2 ;;
    --cache) PKG_CACHE_HOST="${2:-}"; shift 2 ;;
    --db) PKG_DB_HOST="${2:-}"; shift 2 ;;
    --no-resolv) BIND_RESOLV=0; shift ;;
    --no-pkgconf) BIND_ETC_PKGCONF=0; shift ;;
    --keep-mounts) KEEP_MOUNTS=1; shift ;;
    -h|--help) usage; exit 0 ;;
    *) args+=("$1"); shift ;;
  esac
done

cmd="${args[0]:-}"
case "$cmd" in
  mount) do_mount ;;
  umount) do_umount ;;
  status) do_status ;;
  enter) do_enter "${args[1]:-/bin/bash}" ;;
  exec) do_exec "${args[@]}" ;;
  pkg) do_exec exec pkg "${args[@]:1}" ;;
  *) usage; die "unknown command: $cmd" ;;
esac
