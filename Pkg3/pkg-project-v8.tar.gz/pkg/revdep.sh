#!/usr/bin/env sh
# revdep.sh (pkg edition) - reverse dependency / broken linkage scanner
# Adapted for pkg (source-based manager)
#
# What it does:
# - Scans binaries and shared objects in common paths (+ ld.so.conf paths)
# - Runs ldd to find "not found"
# - Maps the broken file to an installed package using pkg's DB
# - Suggests next actions (rebuild owner package, search candidates, ldconfig hints)
#
# Options:
# -a/--all       print all affected files (default prints one line per break)
# -r/--rebuild   rebuild & reinstall broken packages (root required)
# -p/--package   check only one installed package
# -f/--no-filter disable exclude filters from /etc/revdep.conf and /etc/revdep.d/*.conf
# -e/--exclude   exclude packages when rebuilding
# -y/--yes       do not ask confirmation when rebuilding
# --dry-run      show what would be rebuilt, don't execute
#
# Configuration:
# /etc/revdep.conf and /etc/revdep.d/*.conf (same syntax as original):
#   - lines starting with / ending in / => excluded dirs
#   - lines starting with / not ending in / => excluded files
#   - other lines matching .*\.so.* => excluded libs by name
#
set -eu

PRINTALL=0
REBUILD=0
NOCONFIRM=0
NO_FILTER=0
DRYRUN=0
PKG=""

FILE_LIST="/tmp/.revdep.$$"

cleanup() { rm -f "$FILE_LIST"; }
interrupted() { cleanup; echo; exit 1; }
trap interrupted 1 2 3 15

usage() {
	cat << EOF
Usage:
  $(basename "$0") [option] [arg]

Options:
  -a, --all                         print all affected files
  -r, --rebuild                     rebuild & reinstall broken package(s)
  -p, --package <pkg>               check only one installed package
  -f, --no-filter                   skip filter (exclude) dirs, files and libraries
  -e, --exclude <pkg1 pkg2 ...>     exclude package(s) when rebuilding (use with -r/--rebuild)
  -y, --yes                         dont ask confirmation to rebuild package (use with -r/--rebuild)
      --dry-run                     show actions, do not rebuild
  -h, --help                        print this help message
EOF
}

confirm() {
	printf "%s (Y/n) " "$1"
	read -r response
	case "$response" in
		[Nn][Oo]|[Nn]) echo "$2"; exit 2 ;;
		*) : ;;
	esac
}

extract_opts() {
	opts=""
	while [ "$1" ]; do
		case "$1" in
			--*) opts="$opts $1" ;;
			-*) char=${#1}; count=1
			    while [ "$count" != "$char" ]; do
					count=$((count+1))
					opts="$opts -$(echo "$1" | cut -c "$count")"
				done ;;
			*) opts="$opts $1" ;;
		esac
		shift
	done
	echo "$opts"
}

parse_opt() {
	expkg=""
	while [ "${1:-}" ]; do
		case "$1" in
			-a|--all)       PRINTALL=1 ;;
			-r|--rebuild)   REBUILD=1 ;;
			-y|--yes)       NOCONFIRM=1 ;;
			-f|--no-filter) NO_FILTER=1 ;;
			--dry-run)      DRYRUN=1 ;;
			-e|--exclude)	shift
                            while [ "${1:-}" ]; do
								case "$1" in
									-*) break ;;
									*) expkg="${expkg}${expkg:+ }$1" ;;
								esac
								shift
							done
                            continue ;;
			-p|--package)   PKG="${2:-}"; shift ;;
			-h|--help)		usage; exit 0 ;;
			*)				echo "Invalid option ($1)"; exit 1 ;;
		esac
		shift
	done
}

need_cmd() {
	command -v "$1" >/dev/null 2>&1 || { echo "Missing required command: $1" >&2; exit 1; }
}

need_cmd pkg
need_cmd find
need_cmd file
need_cmd ldd
need_cmd objdump
need_cmd awk

if [ "$(id -u)" != 0 ] && [ "$REBUILD" = 1 ]; then
	echo "$(basename "$0") needs root to rebuild packages"
	exit 1
fi

parse_opt $(extract_opts "$@")

# pkg DB root: derive by asking pkg (best-effort) or default to /var/lib/pkg
# Our pkg currently does not print DB dir, so we use env if set or fallback.
DB_ROOT="${DB_ROOT:-/var/lib/pkg}"
PKGDB_DIR="$DB_ROOT/db"

if [ -n "$PKG" ] && [ ! -d "$PKGDB_DIR/$PKG" ]; then
	echo "ERROR: package '$PKG' not installed"
	cleanup
	exit 1
fi

SEARCH_DIRS="/bin /usr/bin /sbin /usr/sbin /lib /usr/lib /lib64 /usr/lib64 /usr/libexec"
EXTRA_SEARCH_DIRS=""
if [ -f /etc/ld.so.conf ]; then
	while IFS= read -r line; do
		case "$line" in
			/*) EXTRA_SEARCH_DIRS="$EXTRA_SEARCH_DIRS $line" ;;
		esac
	done < /etc/ld.so.conf
fi
if [ -d /etc/ld.so.conf.d/ ]; then
	for conf in /etc/ld.so.conf.d/*.conf; do
		[ -f "$conf" ] || continue
		while IFS= read -r line; do
			case "$line" in
				/*) EXTRA_SEARCH_DIRS="$EXTRA_SEARCH_DIRS $line" ;;
			esac
		done < "$conf"
	done
fi

EXCLUDE_DIRS=""
EXCLUDE_FILES=""
EXCLUDE_LIBS=""

rev_exclude() {
	# excluded dirs
	EXCLUDE_DIRS="$(grep -v '^#' /etc/revdep.conf 2>/dev/null | grep '/$' | uniq | sed 's/\/*$//g')"
	EXCLUDE_DIRS="$EXCLUDE_DIRS $(grep -v '^#' /etc/revdep.d/*.conf 2>/dev/null | cut -d : -f2 | grep '/$' | uniq | sed 's/\/*$//g')"

	# excluded files
	EXCLUDE_FILES="$(grep -v '^#' /etc/revdep.conf 2>/dev/null | grep -v '/$' | grep '^/')"
	EXCLUDE_FILES="$EXCLUDE_FILES $(grep -v '^#' /etc/revdep.d/*.conf 2>/dev/null | cut -d : -f2 | grep -v '/$' | grep '^/')"

	# excluded libs by name
	EXCLUDE_LIBS="$(grep -v '^#' /etc/revdep.conf 2>/dev/null | grep -v '^/' | uniq | grep '.*\.so.*' || true)"
	EXCLUDE_LIBS="$EXCLUDE_LIBS $(grep -v '^#' /etc/revdep.d/*.conf 2>/dev/null | cut -d : -f2 | grep -v '^/' | uniq | grep '.*\.so.*' || true)"
}

if [ "$NO_FILTER" != 1 ]; then
	rev_exclude
fi

TARGET_SEARCH_DIRS="$SEARCH_DIRS $EXTRA_SEARCH_DIRS"

echo "SEARCH DIRS:"
for d in $TARGET_SEARCH_DIRS; do
	[ -d "$d" ] && echo " $d"
done
echo

echo "EXCLUDED DIRS:"
for dd in $EXCLUDE_DIRS; do
	echo " $dd"
done
echo

echo "EXCLUDED FILES:"
for ff in $EXCLUDE_FILES; do
	echo " $ff"
done
echo

echo "EXCLUDED LIBS:"
for ll in $EXCLUDE_LIBS; do
	echo " $ll"
done
echo


# helper: detect missing dynamic loader (interpreter) for ELF
check_interp_missing() {
	file="$1"
	# objdump -p prints "interpreter /lib64/ld-linux..."
	interp=$(objdump -p "$file" 2>/dev/null | awk '/interpreter/ {print $2; exit}')
	if [ -n "$interp" ] && [ ! -e "$interp" ]; then
		echo "$interp"
		return 0
	fi
	return 1
}

# build find filters
EXCLUDED_DIRS_EXPR=""
for d in $EXCLUDE_DIRS; do
	[ -d "$d" ] || continue
	EXCLUDED_DIRS_EXPR="$EXCLUDED_DIRS_EXPR -path $d -prune -o "
done
EXCLUDED_FILES_EXPR=""
for f in $EXCLUDE_FILES; do
	[ -f "$f" ] || continue
	EXCLUDED_FILES_EXPR="$EXCLUDED_FILES_EXPR ! -path $f "
done

# Collect file list
if [ -n "$PKG" ]; then
	printf "Collecting '%s' files from pkg DB... " "$PKG"
	# pkg stores paths without leading slash
	tail -n +1 "$PKGDB_DIR/$PKG/files" 2>/dev/null | sed 's#^#/#' > "$FILE_LIST"
else
	printf "Finding candidate ELF files... "
	find $SEARCH_DIRS $EXCLUDED_DIRS_EXPR $EXCLUDED_FILES_EXPR -type f \( -perm -001 -o -name '*.so' -o -name '*.so.*' \) -print 2>/dev/null | sort -u > "$FILE_LIST"
fi

total=$(wc -l "$FILE_LIST" | awk '{print $1}')
count=0
echo "$total files"

echo "Checking for broken linkage..."
ALLPKG=""
BROKEN=0

# helper: find owner package by path (calls pkg owner)
owner_of() {
	pkg owner "$1" 2>/dev/null || true
}

# helper: attempt to suggest candidate package names for missing lib
suggest_candidates() {
	lib="$1"
	base=$(echo "$lib" | sed 's/^lib//; s/\.so.*$//')
	echo "  suggestions:"
	echo "   - try: pkg search $base"
	echo "   - try: pkg search $lib"
	# direct suggestion if exactly one repo match exists
	match=$(pkg search "$base" 2>/dev/null | head -n 2 | sed -n '1,2p')
	count=$(echo "$match" | grep -c . || true)
	if [ "$count" = 1 ]; then
		echo "   - likely provider: pkg install $(echo "$match" | head -n1)"
	fi
	# if file exists somewhere else, suggest ldconfig / path fixes
	if find /lib /usr/lib /lib64 /usr/lib64 -name "$lib" 2>/dev/null | head -n1 | grep -q .; then
		echo "   - '$lib' exists on disk but not in loader paths: try: ldconfig"
	fi
	echo "   - check deps of suspected packages: pkg deps <pkg>"
}
# helper: check if a library name can be resolved on the system
lib_resolves() {
	lib="$1"
	if command -v ldconfig >/dev/null 2>&1; then
		ldconfig -p 2>/dev/null | awk '{print $1}' | grep -qx "$lib" && return 0
	fi
	# fallback: search common dirs
	find /lib /usr/lib /lib64 /usr/lib64 -name "$lib" 2>/dev/null | head -n 1 | grep -q . && return 0
	return 1
}

# helper: list missing libs using objdump/readelf style (no execution)
missing_libs_fallback() {
	file="$1"
	# objdump -p prints "NEEDED <lib>"
	objdump -p "$file" 2>/dev/null | awk '/NEEDED/ {print $2}' | while IFS= read -r l; do
		[ -n "$l" ] || continue
		echo "$EXCLUDE_LIBS" | tr ' ' '\n' | grep -qx "$l" && continue
		if ! lib_resolves "$l"; then
			echo "$l"
		fi
	done
}

# helper: list missing libs preferring ldd (more precise), fallback to objdump if ldd fails
missing_libs() {
	file="$1"
	if ldd "$file" 2>/dev/null | grep -q "not found"; then
		ldd "$file" 2>/dev/null | awk '/not found/ {print $1}' | sort -u
		return 0
	fi
	# fallback
	missing_libs_fallback "$file" | sort -u
}

while IFS= read -r line; do
	[ -n "$line" ] || continue
	count=$((count + 1))
	libname=${line##*/}
	printf " %d%% %s\033[0K\r" $((100*count/(total>0?total:1))) "$libname"

	case "$(file -bi "$line" 2>/dev/null)" in
		*application/x-sharedlib*|*application/x-executable*|*application/x-pie-executable*)
			interp_missing=$(check_interp_missing "$line" || true)
			if [ -n "${interp_missing:-}" ]; then
				owner=$(owner_of "$line")
				[ -n "$owner" ] || owner="(unknown-owner)"
				echo " $owner -> $line (missing interpreter $interp_missing)"
				echo "  suggestions:"
				echo "   - ensure loader exists (glibc/musl) and run: ldconfig"
				echo "   - rebuild owner: pkg reinstall $owner"
				BROKEN=1
			fi
			LIB_NAME=$(missing_libs "$line" 2>/dev/null || true)
			if [ -n "$LIB_NAME" ]; then
				# libs not found
				LIB_NAME=$(missing_libs "$line" 2>/dev/null || true)
				for l in $LIB_NAME; do
					echo "$EXCLUDE_LIBS" | tr ' ' '\n' | grep -qx "$l" && continue
					owner=$(owner_of "$line")
					[ -n "$owner" ] || owner="(unknown-owner)"
					[ "$PRINTALL" = 1 ] && echo " $owner -> $line (requires $l)"
					[ "$PRINTALL" = 1 ] || echo " $owner -> $line (requires $l)"
					BROKEN=1
					# remember packages
					echo "$expkg" | tr ' ' '\n' | grep -qx "$owner" && continue
					echo "$ALLPKG" | tr ' ' '\n' | grep -qx "$owner" && continue
					[ "$owner" = "(unknown-owner)" ] || ALLPKG="$ALLPKG $owner"

					# smart-ish hint block
					echo "  missing: $l"
					suggest_candidates "$l"
				done
			fi
			;;
	esac
done < "$FILE_LIST"

printf "\033[0K\n"

if [ "$BROKEN" = 0 ]; then
	echo "All packages are doing fine."
	cleanup
	exit 0
fi

if [ -n "$ALLPKG" ]; then
	echo
	echo "Broken package(s) (owners of broken files):"
	for p in $ALLPKG; do
		echo " $p"
	done
else
	echo
	echo "Broken files detected, but owner package could not be determined."
	echo "Tip: ensure pkg DB is consistent, or reinstall the package that installed the file."
fi

rebuild() {
	# rebuild in dependency order using pkg depends
	order=""
	for p in $ALLPKG; do
		for dep in $(pkg depends "$p"); do
			echo "$ALLPKG" | tr ' ' '\n' | grep -qx "$dep" || continue
			echo "$order" | tr ' ' '\n' | grep -qx "$dep" && continue
			order="${order}${order:+ }$dep"
		done
	done

	[ -n "$order" ] || return 0

	echo
	echo "Rebuild & reinstall order:"
	echo " $order"
	echo

	if [ "$NOCONFIRM" = 0 ] && [ "$DRYRUN" = 0 ]; then
		confirm "Continue rebuild & reinstall broken packages?" "Operation cancelled."
	fi

	for p in $order; do
		if [ "$DRYRUN" = 1 ]; then
			echo "(dry-run) would: pkg reinstall $p"
		else
			pkg reinstall "$p" || { cleanup; exit 1; }
		fi
	done
}

if [ "$REBUILD" = 1 ]; then
	rebuild
fi

cleanup
exit 0
