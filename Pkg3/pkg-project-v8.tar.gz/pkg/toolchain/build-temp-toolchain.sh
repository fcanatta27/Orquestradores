#!/usr/bin/env bash
# build-temp-toolchain.sh
#
# Objetivo:
#   Construir um toolchain temporário (x86_64, glibc) para iniciar um sistema do zero,
#   instalando em: /mnt/rootfs/tools
#
# Inspirado no fluxo clássico de "temporary toolchain" (estilo LFS), mas com:
#   - downloads automáticos (curl/wget)
#   - passos idempotentes (reconstrução por etapa)
#   - logs e validações de pré-requisitos
#
# ATENÇÃO:
#   Este script assume um "host" Linux funcional com ferramentas de build básicas já presentes.
#   Ele NÃO substitui um bootstrap stage0 real (sem compilador). Ele serve para construir o
#   toolchain temporário em /mnt/rootfs/tools, a partir de um host existente.
#
set -Eeuo pipefail

# ----------------------- UI básica
C0=$'\033[0m'; C1=$'\033[1m'; CG=$'\033[32m'; CY=$'\033[33m'; CR=$'\033[31m'; CB=$'\033[34m'
msg(){ printf "%s[%sTOOLCHAIN%s]%s %s\n" "$CB" "$C1" "$C0" "$C0" "$*"; }
ok(){ printf "%s[%sOK%s]%s %s\n" "$CG" "$C1" "$C0" "$C0" "$*"; }
warn(){ printf "%s[%sWARN%s]%s %s\n" "$CY" "$C1" "$C0" "$C0" "$*"; }
die(){ printf "%s[%sERROR%s]%s %s\n" "$CR" "$C1" "$C0" "$C0" "$*" >&2; exit 1; }

need(){ command -v "$1" >/dev/null 2>&1 || die "comando ausente: $1"; }

# ----------------------- Defaults (override via env)
: "${ROOTFS:=/mnt/rootfs}"
: "${TOOLS:=$ROOTFS/tools}"
: "${SOURCES:=$ROOTFS/sources}"
: "${BUILD:=$ROOTFS/build}"
: "${JOBS:=$(nproc 2>/dev/null || echo 2)}"
: "${TARGET:=x86_64-lfs-linux-gnu}"
: "${MAKEFLAGS:=-j${JOBS}}"
: "${UMASK:=022}"

# Versões (dez/2025)
: "${BINUTILS_VER:=2.45.1}"      # GNU binutils latest release citeturn0search0
: "${GCC_VER:=15.2.0}"           # GCC 15.2 supported release citeturn0search1
: "${LINUX_VER:=6.18.2}"         # kernel.org latest stable citeturn0search3
: "${GLIBC_VER:=2.42}"           # glibc tarballs on ftp.gnu.org citeturn1search0

# GCC deps
: "${GMP_VER:=6.3.0}"            # GMP stable citeturn1search2
: "${MPFR_VER:=4.2.2}"           # MPFR current citeturn1search3
: "${MPC_VER:=1.3.1}"            # MPC on ftp.gnu.org citeturn2search0
: "${ISL_VER:=0.27}"             # isl release on SourceForge citeturn2search9

: "${KEEP_BUILD_DIRS:=0}"        # 1 para manter diretórios de build
: "${STEP:=all}"                 # all|binutils1|gcc1|linuxhdr|glibc|libstdcxx|binutils2|gcc2

# ----------------------- Helpers
fetch_cmd() {
  if command -v curl >/dev/null 2>&1; then
    echo "curl -L --fail --retry 3 --retry-delay 2 -o"
  elif command -v wget >/dev/null 2>&1; then
    echo "wget -O"
  else
    die "precisa de curl ou wget para downloads"
  fi
}

download() {
  local url="$1" out="$2"
  local cmd; cmd="$(fetch_cmd)"
  if [[ -f "$out" ]]; then
    ok "cached: $(basename "$out")"
    return 0
  fi
  msg "download: $url"
  mkdir -p "$(dirname "$out")"
  # shellcheck disable=SC2086
  $cmd "$out" "$url"
}

extract() {
  local tar="$1" dest="$2"
  mkdir -p "$dest"
  case "$tar" in
    *.tar.xz) tar -xf "$tar" -C "$dest" ;;
    *.tar.gz) tar -xzf "$tar" -C "$dest" ;;
    *.tar.bz2) tar -xjf "$tar" -C "$dest" ;;
    *) die "formato desconhecido: $tar" ;;
  esac
}

runlog() {
  local name="$1"; shift
  local log="$BUILD/logs/${name}.log"
  mkdir -p "$BUILD/logs"
  msg "run: $name (log: $log)"
  ( set -Eeuo pipefail; "$@" ) >"$log" 2>&1 || { tail -n 60 "$log" >&2 || true; die "falha em $name (veja: $log)"; }
}

clean_dir() {
  local d="$1"
  [[ "$KEEP_BUILD_DIRS" == "1" ]] && return 0
  rm -rf "$d"
}

as_root_warn() {
  if [[ "$(id -u)" -ne 0 ]]; then
    warn "recomendado rodar como root para criar $TOOLS e symlink /tools (use sudo)."
  fi
}

setup_layout() {
  umask "$UMASK"
  mkdir -p "$SOURCES" "$BUILD"
  mkdir -p "$TOOLS"
  # symlink /tools -> $TOOLS (convenção comum para toolchain temporário)
  if [[ "$(id -u)" -eq 0 ]]; then
    if [[ -e /tools && ! -L /tools ]]; then
      warn "/tools existe e não é symlink; não vou sobrescrever."
    elif [[ ! -e /tools ]]; then
      ln -s "$TOOLS" /tools
      ok "symlink criado: /tools -> $TOOLS"
    fi
  fi
  ok "layout: ROOTFS=$ROOTFS TOOLS=$TOOLS"
}

require_host_tools() {
  # Conjunto mínimo para um host que já compila
  for c in bash make gcc g++ ld as ar ranlib strip tar xz gzip bzip2 patch sed awk perl python3; do
    need "$c"
  done
  need "install"
  need "mkdir"
  need "ln"
  command -v bison >/dev/null 2>&1 || warn "bison não encontrado (pode ser necessário para alguns componentes do GCC)"
  command -v flex >/dev/null 2>&1 || warn "flex não encontrado (pode ser necessário para alguns componentes do GCC)"
}

# URLs (oficiais)
url_binutils="https://ftp.gnu.org/gnu/binutils/binutils-${BINUTILS_VER}.tar.xz"
url_gcc="https://ftp.gnu.org/gnu/gcc/gcc-${GCC_VER}/gcc-${GCC_VER}.tar.xz"
url_linux="https://cdn.kernel.org/pub/linux/kernel/v6.x/linux-${LINUX_VER}.tar.xz"
url_glibc="https://ftp.gnu.org/gnu/libc/glibc-${GLIBC_VER}.tar.xz"

url_gmp="https://gmplib.org/download/gmp/gmp-${GMP_VER}.tar.xz"
url_mpfr="https://www.mpfr.org/mpfr-current/mpfr-${MPFR_VER}.tar.xz"
url_mpc="https://ftp.gnu.org/gnu/mpc/mpc-${MPC_VER}.tar.gz"
url_isl="https://downloads.sourceforge.net/project/libisl/isl-${ISL_VER}.tar.xz"

# ----------------------- Steps
step_binutils1() {
  msg "== binutils pass1 =="
  local tar="$SOURCES/binutils-${BINUTILS_VER}.tar.xz"
  download "$url_binutils" "$tar"

  rm -rf "$BUILD/binutils1-src" "$BUILD/binutils1-build"
  mkdir -p "$BUILD/binutils1-src" "$BUILD/binutils1-build"
  extract "$tar" "$BUILD/binutils1-src"
  local src="$BUILD/binutils1-src/binutils-${BINUTILS_VER}"
  local b="$BUILD/binutils1-build"
  runlog "binutils-pass1-configure" bash -lc "cd '$b' && '$src/configure' --prefix='$TOOLS' --with-sysroot='$ROOTFS' --target='$TARGET' --disable-nls --disable-werror"
  runlog "binutils-pass1-make" bash -lc "cd '$b' && make $MAKEFLAGS"
  runlog "binutils-pass1-install" bash -lc "cd '$b' && make install"
  ok "binutils pass1 instalado em $TOOLS"
}

step_gcc1() {
  msg "== gcc pass1 (compiler minimal) =="
  local tar="$SOURCES/gcc-${GCC_VER}.tar.xz"
  download "$url_gcc" "$tar"
  download "$url_gmp" "$SOURCES/gmp-${GMP_VER}.tar.xz"
  download "$url_mpfr" "$SOURCES/mpfr-${MPFR_VER}.tar.xz"
  download "$url_mpc" "$SOURCES/mpc-${MPC_VER}.tar.gz"
  download "$url_isl" "$SOURCES/isl-${ISL_VER}.tar.xz"

  rm -rf "$BUILD/gcc1-src" "$BUILD/gcc1-build"
  mkdir -p "$BUILD/gcc1-src" "$BUILD/gcc1-build"
  extract "$tar" "$BUILD/gcc1-src"
  local src="$BUILD/gcc1-src/gcc-${GCC_VER}"

  # Descompactar deps dentro da árvore do GCC (modo simples)
  extract "$SOURCES/gmp-${GMP_VER}.tar.xz" "$BUILD/gcc1-src"
  extract "$SOURCES/mpfr-${MPFR_VER}.tar.xz" "$BUILD/gcc1-src"
  extract "$SOURCES/mpc-${MPC_VER}.tar.gz" "$BUILD/gcc1-src"
  extract "$SOURCES/isl-${ISL_VER}.tar.xz" "$BUILD/gcc1-src"
  rm -rf "$src/gmp" "$src/mpfr" "$src/mpc" "$src/isl"
  mv "$BUILD/gcc1-src/gmp-${GMP_VER}" "$src/gmp"
  mv "$BUILD/gcc1-src/mpfr-${MPFR_VER}" "$src/mpfr"
  mv "$BUILD/gcc1-src/mpc-${MPC_VER}" "$src/mpc"
  mv "$BUILD/gcc1-src/isl-${ISL_VER}" "$src/isl"

  local b="$BUILD/gcc1-build"

  # Toolchain PATH
  export PATH="$TOOLS/bin:$PATH"

  # GCC sem headers (bootstrap)
  runlog "gcc-pass1-configure" bash -lc "cd '$b' && '$src/configure' \
    --target='$TARGET' --prefix='$TOOLS' \
    --with-glibc-version='${GLIBC_VER}' \
    --with-sysroot='$ROOTFS' \
    --with-newlib --without-headers \
    --enable-default-pie \
    --enable-default-ssp \
    --disable-nls \
    --disable-shared --disable-multilib \
    --disable-threads --disable-libatomic --disable-libgomp --disable-libquadmath --disable-libssp --disable-libvtv \
    --enable-languages=c,c++"

  runlog "gcc-pass1-make" bash -lc "cd '$b' && make $MAKEFLAGS all-gcc all-target-libgcc"
  runlog "gcc-pass1-install" bash -lc "cd '$b' && make install-gcc install-target-libgcc"
  ok "gcc pass1 instalado em $TOOLS"
}

step_linux_headers() {
  msg "== linux headers =="
  local tar="$SOURCES/linux-${LINUX_VER}.tar.xz"
  download "$url_linux" "$tar"
  rm -rf "$BUILD/linux-src"
  mkdir -p "$BUILD/linux-src"
  extract "$tar" "$BUILD/linux-src"
  local src="$BUILD/linux-src/linux-${LINUX_VER}"

  export PATH="$TOOLS/bin:$PATH"
  # Headers vão para sysroot do target dentro de tools
  runlog "linux-headers" bash -lc "cd '$src' && make mrproper && make headers && make INSTALL_HDR_PATH='$TOOLS/$TARGET' headers_install"
  ok "linux headers instalados em $TOOLS/$TARGET/include"
}

step_glibc() {
  msg "== glibc (para o toolchain temporário) =="
  local tar="$SOURCES/glibc-${GLIBC_VER}.tar.xz"
  download "$url_glibc" "$tar"
  rm -rf "$BUILD/glibc-src" "$BUILD/glibc-build"
  mkdir -p "$BUILD/glibc-src" "$BUILD/glibc-build"
  extract "$tar" "$BUILD/glibc-src"
  local src="$BUILD/glibc-src/glibc-${GLIBC_VER}"
  local b="$BUILD/glibc-build"

  export PATH="$TOOLS/bin:$PATH"

  # build triplet
  local build; build="$("$src/scripts/config.guess")"

  # sysroot headers já foram instalados em $TOOLS/$TARGET/include
  runlog "glibc-configure" bash -lc "cd '$b' && \
    CC='$TARGET-gcc' \
    '$src/configure' \
      --prefix='$TOOLS' \
      --host='$TARGET' \
      --build='$build' \
      --with-headers='$TOOLS/$TARGET/include' \
      --disable-multilib \
      libc_cv_slibdir='$TOOLS/lib'"

  runlog "glibc-make" bash -lc "cd '$b' && make $MAKEFLAGS"
  runlog "glibc-install" bash -lc "cd '$b' && make install"
  ok "glibc instalado em $TOOLS (temporário)"
}

step_libstdcxx() {
  msg "== libstdc++ (do gcc) =="
  local src="$BUILD/gcc1-src/gcc-${GCC_VER}"
  [[ -d "$src" ]] || die "gcc source não encontrado (rode gcc1 antes)"
  rm -rf "$BUILD/libstdcxx-build"
  mkdir -p "$BUILD/libstdcxx-build"

  export PATH="$TOOLS/bin:$PATH"
  local b="$BUILD/libstdcxx-build"
  runlog "libstdcxx-configure" bash -lc "cd '$b' && '$src/libstdc++-v3/configure' \
    --host='$TARGET' --build='$("$src/config.guess")' \
    --prefix='$TOOLS' \
    --disable-multilib --disable-nls \
    --with-gxx-include-dir='$TOOLS/$TARGET/include/c++/${GCC_VER}'"
  runlog "libstdcxx-make" bash -lc "cd '$b' && make $MAKEFLAGS"
  runlog "libstdcxx-install" bash -lc "cd '$b' && make install"
  ok "libstdc++ instalada em $TOOLS"
}

step_binutils2() {
  msg "== binutils pass2 (opcional/recomendado) =="
  # Rebuild binutils usando o novo sysroot/glibc
  local tar="$SOURCES/binutils-${BINUTILS_VER}.tar.xz"
  [[ -f "$tar" ]] || download "$url_binutils" "$tar"

  rm -rf "$BUILD/binutils2-src" "$BUILD/binutils2-build"
  mkdir -p "$BUILD/binutils2-src" "$BUILD/binutils2-build"
  extract "$tar" "$BUILD/binutils2-src"
  local src="$BUILD/binutils2-src/binutils-${BINUTILS_VER}"
  local b="$BUILD/binutils2-build"

  export PATH="$TOOLS/bin:$PATH"
  runlog "binutils-pass2-configure" bash -lc "cd '$b' && '$src/configure' \
    --prefix='$TOOLS' --target='$TARGET' --with-sysroot='$ROOTFS' \
    --disable-nls --disable-werror"
  runlog "binutils-pass2-make" bash -lc "cd '$b' && make $MAKEFLAGS"
  runlog "binutils-pass2-install" bash -lc "cd '$b' && make install"
  ok "binutils pass2 instalado"
}

step_gcc2() {
  msg "== gcc pass2 (recomendado) =="
  # Rebuild GCC agora com glibc presente
  local tar="$SOURCES/gcc-${GCC_VER}.tar.xz"
  [[ -f "$tar" ]] || download "$url_gcc" "$tar"

  rm -rf "$BUILD/gcc2-src" "$BUILD/gcc2-build"
  mkdir -p "$BUILD/gcc2-src" "$BUILD/gcc2-build"
  extract "$tar" "$BUILD/gcc2-src"
  local src="$BUILD/gcc2-src/gcc-${GCC_VER}"

  # Deps
  extract "$SOURCES/gmp-${GMP_VER}.tar.xz" "$BUILD/gcc2-src"
  extract "$SOURCES/mpfr-${MPFR_VER}.tar.xz" "$BUILD/gcc2-src"
  extract "$SOURCES/mpc-${MPC_VER}.tar.gz" "$BUILD/gcc2-src"
  extract "$SOURCES/isl-${ISL_VER}.tar.xz" "$BUILD/gcc2-src"
  rm -rf "$src/gmp" "$src/mpfr" "$src/mpc" "$src/isl"
  mv "$BUILD/gcc2-src/gmp-${GMP_VER}" "$src/gmp"
  mv "$BUILD/gcc2-src/mpfr-${MPFR_VER}" "$src/mpfr"
  mv "$BUILD/gcc2-src/mpc-${MPC_VER}" "$src/mpc"
  mv "$BUILD/gcc2-src/isl-${ISL_VER}" "$src/isl"

  export PATH="$TOOLS/bin:$PATH"
  local b="$BUILD/gcc2-build"

  runlog "gcc-pass2-configure" bash -lc "cd '$b' && '$src/configure' \
    --target='$TARGET' --prefix='$TOOLS' \
    --with-sysroot='$ROOTFS' \
    --disable-nls \
    --enable-default-pie --enable-default-ssp \
    --enable-languages=c,c++ \
    --disable-multilib"
  runlog "gcc-pass2-make" bash -lc "cd '$b' && make $MAKEFLAGS"
  runlog "gcc-pass2-install" bash -lc "cd '$b' && make install"
  ok "gcc pass2 instalado"
}

post_checks() {
  msg "== checks =="
  export PATH="$TOOLS/bin:$PATH"
  "$TARGET-gcc" -v >/dev/null 2>&1 || die "gcc do target não executa"
  "$TARGET-ld" -v >/dev/null 2>&1 || die "ld do target não executa"
  ok "toolchain básico operacional em $TOOLS"
  msg "Dica: export PATH=\"$TOOLS/bin:\$PATH\""
}

main() {
  as_root_warn
  setup_layout
  require_host_tools

  case "$STEP" in
    all)
      step_binutils1
      step_gcc1
      step_linux_headers
      step_glibc
      step_libstdcxx
      step_binutils2
      step_gcc2
      post_checks
      ;;
    binutils1) step_binutils1 ;;
    gcc1) step_gcc1 ;;
    linuxhdr) step_linux_headers ;;
    glibc) step_glibc ;;
    libstdcxx) step_libstdcxx ;;
    binutils2) step_binutils2 ;;
    gcc2) step_gcc2 ;;
    *) die "STEP inválido: $STEP" ;;
  esac
}

# Flags simples
if [[ "${1:-}" == "-h" || "${1:-}" == "--help" ]]; then
  cat <<EOF
Uso:
  sudo ./build-temp-toolchain.sh

Opções por env:
  ROOTFS=/mnt/rootfs
  TOOLS=\$ROOTFS/tools
  TARGET=x86_64-lfs-linux-gnu
  STEP=all|binutils1|gcc1|linuxhdr|glibc|libstdcxx|binutils2|gcc2
  JOBS=<n>
  KEEP_BUILD_DIRS=1

Versões (override por env):
  BINUTILS_VER, GCC_VER, LINUX_VER, GLIBC_VER, GMP_VER, MPFR_VER, MPC_VER, ISL_VER

EOF
  exit 0
fi

main
