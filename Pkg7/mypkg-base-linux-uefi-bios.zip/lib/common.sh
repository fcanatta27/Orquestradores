#!/bin/sh
set -eu
: "${PROJECT_NAME:=mypkg-base}"
: "${CONFIG_FILE:=./config.sh}"

ts() { date +"%Y-%m-%d %H:%M:%S"; }
log() { printf '%s [%s] %s\n' "$(ts)" "$PROJECT_NAME" "$*" >&2; }
die() { log "ERROR: $*"; exit 1; }

need_cmd() { command -v "$1" >/dev/null 2>&1 || die "Comando requerido não encontrado: $1"; }
need_root() { [ "$(id -u)" -eq 0 ] || die "Este comando precisa de root (use sudo)."; }

acquire_lock() {
  lockdir="$1"; i=0
  while :; do
    if mkdir "$lockdir" 2>/dev/null; then
      printf '%s\n' "$$" > "$lockdir/pid" 2>/dev/null || true
      return 0
    fi
    i=$((i+1))
    [ "$i" -le 300 ] || die "Falha ao adquirir lock: $lockdir"
    sleep 1
  done
}
release_lock() {
  lockdir="$1"
  [ -d "$lockdir" ] || return 0
  rm -f "$lockdir/pid" 2>/dev/null || true
  rmdir "$lockdir" 2>/dev/null || true
}

ensure_dir() {
  d="$1"; mode="${2:-0755}"
  [ -n "$d" ] || die "ensure_dir: caminho vazio"
  [ -d "$d" ] || mkdir -p "$d"
  chmod "$mode" "$d" 2>/dev/null || true
}

mktemp_dir() {
  if command -v mktemp >/dev/null 2>&1; then
    mktemp -d "${1:-/tmp}/${PROJECT_NAME}.XXXXXX"
  else
    d="${1:-/tmp}/${PROJECT_NAME}.$$.$(date +%s)"
    (umask 077 && mkdir -p "$d") || return 1
    printf '%s\n' "$d"
  fi
}

load_config() {
  [ -f "$CONFIG_FILE" ] || die "Arquivo config não encontrado: $CONFIG_FILE"
  # shellcheck disable=SC1090
  . "$CONFIG_FILE"
}

require_vars() {
  for v in "$@"; do
    eval "val=\${$v:-}"
    [ -n "$val" ] || die "Variável obrigatória ausente em config.sh: $v"
  done
}

fetch() {
  url="$1"; out="$2"
  [ -n "$url" ] && [ -n "$out" ] || die "fetch: args inválidos"
  if [ -f "$out" ]; then
    log "Distfile já existe: $out"
    return 0
  fi
  ensure_dir "$(dirname "$out")" 0755
  if command -v wget >/dev/null 2>&1; then
    log "Download: $url"
    wget -O "$out" "$url"
  elif command -v curl >/dev/null 2>&1; then
    log "Download: $url"
    curl -L -o "$out" "$url"
  else
    die "Precisa de wget ou curl para download"
  fi
}

verify_sha256() {
  file="$1"; sha="$2"
  [ -n "$sha" ] || return 0
  need_cmd sha256sum
  printf '%s  %s\n' "$sha" "$file" | sha256sum -c - >/dev/null 2>&1 || die "SHA256 inválido para $file"
}

host_firmware_mode() {
  if [ -d /sys/firmware/efi ] && [ -n "$(ls -A /sys/firmware/efi 2>/dev/null || true)" ]; then
    printf 'uefi\n'
  else
    printf 'bios\n'
  fi
}
