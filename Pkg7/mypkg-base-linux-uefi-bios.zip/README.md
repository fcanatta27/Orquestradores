# mypkg-base-linux (UEFI + BIOS)

Pipeline POSIX para construir uma base Linux com:
- toolchain + glibc no chroot
- busybox bootstrap (/bin/sh)
- sysvinit (scripts básicos)
- kernel em /boot
- GRUB com detecção UEFI/BIOS
- geração de fstab, modules-load e checklist
- stage opcional de deps do host

## Como usar
1) `cp config.sh.example config.sh` e edite.
2) Rode:
```sh
sudo ./bin/run-stages.sh
```
Logs: `$WORK_DIR/logs/*.log`

## Chroot
```sh
sudo ./bin/chrootctl.sh --root "$CHROOT_DIR" enter
```

## UEFI vs BIOS
O stage `08-grub.sh` detecta via `/sys/firmware/efi`.
- UEFI: usa `EFI_DEV` e monta em `$CHROOT_DIR$EFI_MOUNTPOINT`.
- BIOS: usa `GRUB_BIOS_DISK`.

## Arquivos gerados
- `/etc/fstab`
- `/etc/modules-load.d/base.conf`
- `/root/FIRST_BOOT_CHECKLIST.txt`
- `/etc/base-system.ready` (ready=1 no handoff)

## Observações
- `grub.cfg` é mínimo; ajuste `root=` se necessário (UUID recomendado).
- Instalar bootloader mexe em disco; revise `config.sh`.
