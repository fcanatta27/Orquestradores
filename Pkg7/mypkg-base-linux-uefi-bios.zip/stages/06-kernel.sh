#!/bin/sh
set -eu
CONFIG_FILE="${1:-./config.sh}"
BASE_DIR=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
. "$BASE_DIR/lib/common.sh"
CONFIG_FILE="$CONFIG_FILE"
load_config
need_root
require_vars CHROOT_DIR WORK_DIR DISTFILES_DIR JOBS
KERNEL_VER="${KERNEL_VER:-6.18.3}"
KERNEL_TAR="linux-$KERNEL_VER.tar.xz"
KERNEL_URL="${KERNEL_URL:-https://cdn.kernel.org/pub/linux/kernel/v6.x/$KERNEL_TAR}"
KERNEL_SHA256="${KERNEL_SHA256:-}"
fetch "$KERNEL_URL" "$DISTFILES_DIR/$KERNEL_TAR"; verify_sha256 "$DISTFILES_DIR/$KERNEL_TAR" "$KERNEL_SHA256"
need_cmd tar; need_cmd make; need_cmd gcc
bdir=$(mktemp_dir "$WORK_DIR"); trap 'rm -rf "$bdir"' EXIT INT TERM
tar -xf "$DISTFILES_DIR/$KERNEL_TAR" -C "$bdir"
cd "$bdir/linux-$KERNEL_VER"
make x86_64_defconfig
[ -x scripts/config ] && { scripts/config --enable DEVTMPFS --enable DEVTMPFS_MOUNT || true; scripts/config --enable EFI_STUB --enable EFI || true; } || true
make -j"$JOBS"
make -j"$JOBS" modules || true
mkdir -p "$CHROOT_DIR/boot"
cp -f arch/x86/boot/bzImage "$CHROOT_DIR/boot/vmlinuz-$KERNEL_VER"
cp -f System.map "$CHROOT_DIR/boot/System.map-$KERNEL_VER" 2>/dev/null || true
cp -f .config "$CHROOT_DIR/boot/config-$KERNEL_VER" 2>/dev/null || true
make INSTALL_MOD_PATH="$CHROOT_DIR" modules_install || true
ln -sf "vmlinuz-$KERNEL_VER" "$CHROOT_DIR/boot/vmlinuz" 2>/dev/null || true
log "OK: kernel instalado."
