#!/bin/sh
set -eu
CONFIG_FILE="${1:-./config.sh}"
BASE_DIR=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
. "$BASE_DIR/lib/common.sh"
CONFIG_FILE="$CONFIG_FILE"
load_config
need_root
require_vars CHROOT_DIR ROOT_DEV HOSTNAME
get_uuid(){ dev="$1"; command -v blkid >/dev/null 2>&1 && blkid -s UUID -o value "$dev" 2>/dev/null || true; }
root_uuid="$(get_uuid "$ROOT_DEV")"
swap_uuid=""; efi_uuid=""
[ -n "${SWAP_DEV:-}" ] && swap_uuid="$(get_uuid "$SWAP_DEV")"
[ -n "${EFI_DEV:-}" ] && efi_uuid="$(get_uuid "$EFI_DEV")"
fstab="$CHROOT_DIR/etc/fstab"; mkdir -p "$CHROOT_DIR/etc"; : > "$fstab"
add(){ printf '%s\n' "$*" >> "$fstab"; }
add "# /etc/fstab (gerado)"
if [ -n "$root_uuid" ]; then add "UUID=$root_uuid  /  ext4  defaults,noatime  0 1"; else add "$ROOT_DEV  /  ext4  defaults,noatime  0 1"; fi
if [ -n "${EFI_DEV:-}" ]; then
  mp="${EFI_MOUNTPOINT:-/boot/efi}"
  mkdir -p "$CHROOT_DIR$mp"
  if [ -n "$efi_uuid" ]; then add "UUID=$efi_uuid  $mp  vfat  umask=0077,shortname=winnt  0 2"; else add "$EFI_DEV  $mp  vfat  umask=0077,shortname=winnt  0 2"; fi
fi
if [ -n "${SWAP_DEV:-}" ]; then
  if [ -n "$swap_uuid" ]; then add "UUID=$swap_uuid  none  swap  sw  0 0"; else add "$SWAP_DEV  none  swap  sw  0 0"; fi
fi
add "proc  /proc  proc  nosuid,noexec,nodev  0 0"
add "sysfs /sys   sysfs nosuid,noexec,nodev  0 0"
add "tmpfs /run   tmpfs nosuid,nodev,mode=755 0 0"
mkdir -p "$CHROOT_DIR/etc/modules-load.d"
ml="$CHROOT_DIR/etc/modules-load.d/base.conf"; : > "$ml"; printf '# módulos\n' >> "$ml"
for m in $MODULES_LOAD; do printf '%s\n' "$m" >> "$ml"; done
mkdir -p "$CHROOT_DIR/root"
cat > "$CHROOT_DIR/root/FIRST_BOOT_CHECKLIST.txt" <<'EOF'
FIRST BOOT CHECKLIST
1) passwd
2) criar usuário
3) revisar /boot/grub/grub.cfg (root=...)
4) revisar /etc/fstab e mount -a
5) revisar /etc/sysconfig/network.conf e rede
6) dmesg para validar drivers
7) depois: mypkg para instalar programas finais
EOF
cat > "$CHROOT_DIR/etc/base-system.ready" <<EOF
ready=0
hostname=$HOSTNAME
EOF
log "OK: fstab/modules/checklist/marker gerados."
