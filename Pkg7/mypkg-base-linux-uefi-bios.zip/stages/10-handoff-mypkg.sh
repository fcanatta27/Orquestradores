#!/bin/sh
set -eu
CONFIG_FILE="${1:-./config.sh}"
BASE_DIR=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
. "$BASE_DIR/lib/common.sh"
CONFIG_FILE="$CONFIG_FILE"
load_config
need_root
require_vars CHROOT_DIR HOSTNAME
marker="$CHROOT_DIR/etc/base-system.ready"
tmp="$marker.tmp"
awk 'BEGIN{done=0} /^ready=/ {print "ready=1"; done=1; next} {print} END{if(!done) print "ready=1"}' "$marker" 2>/dev/null > "$tmp" || printf 'ready=1\nhostname=%s\n' "$HOSTNAME" > "$tmp"
mv "$tmp" "$marker"
mkdir -p "$CHROOT_DIR/var/lib/mypkg/db" "$CHROOT_DIR/var/cache/mypkg/distfiles" "$CHROOT_DIR/var/log/mypkg"
chmod 0755 "$CHROOT_DIR/var/lib/mypkg" "$CHROOT_DIR/var/cache/mypkg" "$CHROOT_DIR/var/log/mypkg" 2>/dev/null || true
log "OK: handoff pronto (ready=1)."
