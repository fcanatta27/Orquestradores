#!/bin/sh
set -eu
CONFIG_FILE="${1:-./config.sh}"
BASE_DIR=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
. "$BASE_DIR/lib/common.sh"
CONFIG_FILE="$CONFIG_FILE"
load_config
need_root
require_vars CHROOT_DIR WORK_DIR DISTFILES_DIR JOBS
WGET2_VER="${WGET2_VER:-2.2.1}"
WGET2_TAR="wget2-$WGET2_VER.tar.gz"
WGET2_URL="${WGET2_URL:-https://ftp.gnu.org/gnu/wget/$WGET2_TAR}"
WGET2_SHA256="${WGET2_SHA256:-}"
fetch "$WGET2_URL" "$DISTFILES_DIR/$WGET2_TAR"; verify_sha256 "$DISTFILES_DIR/$WGET2_TAR" "$WGET2_SHA256"
need_cmd tar; need_cmd make; need_cmd gcc
bdir=$(mktemp_dir "$WORK_DIR"); trap 'rm -rf "$bdir"' EXIT INT TERM
tar -xf "$DISTFILES_DIR/$WGET2_TAR" -C "$bdir"
cd "$bdir/wget2-$WGET2_VER"
./configure --prefix=/usr
make -j"$JOBS"
make DESTDIR="$CHROOT_DIR" install
log "OK: wget2 instalado."
