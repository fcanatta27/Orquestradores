#!/bin/sh
set -eu
CONFIG_FILE="${1:-./config.sh}"
BASE_DIR=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
. "$BASE_DIR/lib/common.sh"
CONFIG_FILE="$CONFIG_FILE"
load_config
need_root
require_vars CHROOT_DIR WORK_DIR DISTFILES_DIR JOBS ROOT_DEV GRUB_BIOS_DISK
GRUB_VER="${GRUB_VER:-2.12}"
GRUB_TAR="grub-$GRUB_VER.tar.xz"
GRUB_URL="${GRUB_URL:-https://ftp.gnu.org/gnu/grub/$GRUB_TAR}"
GRUB_SHA256="${GRUB_SHA256:-}"
fetch "$GRUB_URL" "$DISTFILES_DIR/$GRUB_TAR"; verify_sha256 "$DISTFILES_DIR/$GRUB_TAR" "$GRUB_SHA256"
need_cmd tar; need_cmd make; need_cmd gcc
bdir=$(mktemp_dir "$WORK_DIR"); trap 'rm -rf "$bdir"' EXIT INT TERM
tar -xf "$DISTFILES_DIR/$GRUB_TAR" -C "$bdir"
cd "$bdir/grub-$GRUB_VER"
./configure --prefix=/usr --sbindir=/sbin --sysconfdir=/etc --disable-werror
make -j"$JOBS"
make DESTDIR="$CHROOT_DIR" install
mkdir -p "$CHROOT_DIR/boot/grub"
cat > "$CHROOT_DIR/boot/grub/grub.cfg" <<EOF
set default=0
set timeout=3
menuentry "MyLinux" {
    linux /boot/vmlinuz root=$ROOT_DEV ro quiet
}
EOF
mode="$(host_firmware_mode)"
log "Firmware host: $mode"
if [ "$mode" = "uefi" ]; then
  require_vars EFI_DEV EFI_MOUNTPOINT
  mkdir -p "$CHROOT_DIR$EFI_MOUNTPOINT"
  if ! grep -q " $CHROOT_DIR$EFI_MOUNTPOINT " /proc/mounts 2>/dev/null; then
    log "Montando ESP ($EFI_DEV) em $CHROOT_DIR$EFI_MOUNTPOINT"
    mount "$EFI_DEV" "$CHROOT_DIR$EFI_MOUNTPOINT"
  fi
  inst="/usr/sbin/grub-install"; [ -x "$CHROOT_DIR$inst" ] || inst="/sbin/grub-install"
  [ -x "$CHROOT_DIR$inst" ] || die "grub-install não encontrado no chroot"
  chroot "$CHROOT_DIR" "$inst" --target=x86_64-efi --efi-directory="$EFI_MOUNTPOINT" --bootloader-id=MyLinux --recheck
else
  inst="/usr/sbin/grub-install"; [ -x "$CHROOT_DIR$inst" ] || inst="/sbin/grub-install"
  [ -x "$CHROOT_DIR$inst" ] || die "grub-install não encontrado no chroot"
  chroot "$CHROOT_DIR" "$inst" --target=i386-pc "$GRUB_BIOS_DISK" --recheck
fi
log "OK: GRUB instalado."
