#!/bin/sh
set -eu
CONFIG_FILE="${1:-./config.sh}"
BASE_DIR=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
. "$BASE_DIR/lib/common.sh"
CONFIG_FILE="$CONFIG_FILE"
load_config
require_vars CHROOT_DIR WORK_DIR DISTFILES_DIR ROOT_DEV GRUB_BIOS_DISK HOSTNAME
log "Checando comandos essenciais no host..."
need_cmd mount; need_cmd chroot; need_cmd tar; need_cmd xz
need_cmd make || true; need_cmd gcc || true; need_cmd g++ || true
ensure_dir "$WORK_DIR" 0755; ensure_dir "$DISTFILES_DIR" 0755; ensure_dir "$WORK_DIR/logs" 0755; ensure_dir "$CHROOT_DIR" 0755
log "OK: host e diretórios preparados."
