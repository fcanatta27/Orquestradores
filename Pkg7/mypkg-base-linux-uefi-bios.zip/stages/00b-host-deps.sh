#!/bin/sh
set -eu
CONFIG_FILE="${1:-./config.sh}"
BASE_DIR=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
. "$BASE_DIR/lib/common.sh"
CONFIG_FILE="$CONFIG_FILE"
load_config
need_root
pkgs_common="build-essential bison flex gawk texinfo gettext autopoint pkg-config python3 perl patch xz-utils gzip bzip2 wget curl git rsync ca-certificates libssl-dev libncurses-dev libelf-dev bc"
log "AUTO_INSTALL_HOST_DEPS=$AUTO_INSTALL_HOST_DEPS"
[ "${AUTO_INSTALL_HOST_DEPS:-0}" = "1" ] || log "Modo dry-run (defina AUTO_INSTALL_HOST_DEPS=1 para instalar automaticamente)."
if command -v apt-get >/dev/null 2>&1; then
  log "Host: apt (Debian/Ubuntu). Sugestão: apt-get update && apt-get install -y $pkgs_common"
  if [ "${AUTO_INSTALL_HOST_DEPS:-0}" = "1" ]; then
    apt-get update
    # shellcheck disable=SC2086
    apt-get install -y $pkgs_common
  fi
else
  log "Host: gerenciador não-apt. Instale manualmente deps equivalentes."
fi
log "OK: host deps (dry-run/auto)."
