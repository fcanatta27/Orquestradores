#!/bin/sh
set -eu
CONFIG_FILE="${1:-./config.sh}"
BASE_DIR=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
. "$BASE_DIR/lib/common.sh"
CONFIG_FILE="$CONFIG_FILE"
load_config
need_root
require_vars CHROOT_DIR WORK_DIR DISTFILES_DIR JOBS CPU_TUNE CFLAGS_COMMON
BINUTILS_VER="${BINUTILS_VER:-2.45.1}"
GCC_VER="${GCC_VER:-15.2.0}"
GLIBC_VER="${GLIBC_VER:-2.42}"
BINUTILS_TAR="binutils-$BINUTILS_VER.tar.xz"
GCC_TAR="gcc-$GCC_VER.tar.xz"
GLIBC_TAR="glibc-$GLIBC_VER.tar.xz"
BINUTILS_URL="${BINUTILS_URL:-https://ftp.gnu.org/gnu/binutils/$BINUTILS_TAR}"
GCC_URL="${GCC_URL:-https://ftp.gnu.org/gnu/gcc/gcc-$GCC_VER/$GCC_TAR}"
GLIBC_URL="${GLIBC_URL:-https://ftp.gnu.org/gnu/glibc/$GLIBC_TAR}"
BINUTILS_SHA256="${BINUTILS_SHA256:-}"; GCC_SHA256="${GCC_SHA256:-}"; GLIBC_SHA256="${GLIBC_SHA256:-}"
if [ "${CPU_TUNE:-generic}" = "native" ]; then CFLAGS="$CFLAGS_COMMON -march=native -mtune=native"; else CFLAGS="$CFLAGS_COMMON -march=x86-64 -mtune=generic"; fi
export CFLAGS CXXFLAGS="$CFLAGS"
need_cmd tar; need_cmd make; need_cmd gcc; need_cmd g++; need_cmd sed; need_cmd awk
fetch "$BINUTILS_URL" "$DISTFILES_DIR/$BINUTILS_TAR"; verify_sha256 "$DISTFILES_DIR/$BINUTILS_TAR" "$BINUTILS_SHA256"
fetch "$GCC_URL" "$DISTFILES_DIR/$GCC_TAR"; verify_sha256 "$DISTFILES_DIR/$GCC_TAR" "$GCC_SHA256"
fetch "$GLIBC_URL" "$DISTFILES_DIR/$GLIBC_TAR"; verify_sha256 "$DISTFILES_DIR/$GLIBC_TAR" "$GLIBC_SHA256"
buildroot=$(mktemp_dir "$WORK_DIR"); trap 'rm -rf "$buildroot"' EXIT INT TERM
mkdir -p "$buildroot/src"
tar -xf "$DISTFILES_DIR/$BINUTILS_TAR" -C "$buildroot/src"
tar -xf "$DISTFILES_DIR/$GCC_TAR" -C "$buildroot/src"
tar -xf "$DISTFILES_DIR/$GLIBC_TAR" -C "$buildroot/src"
mkdir -p "$buildroot/build-binutils"
cd "$buildroot/build-binutils"
"$buildroot/src/binutils-$BINUTILS_VER/configure" --prefix=/usr --with-sysroot="$CHROOT_DIR" --disable-nls --disable-werror
make -j"$JOBS"
make DESTDIR="$CHROOT_DIR" install
mkdir -p "$buildroot/build-gcc"
cd "$buildroot/build-gcc"
if [ -x "$buildroot/src/gcc-$GCC_VER/contrib/download_prerequisites" ]; then (cd "$buildroot/src/gcc-$GCC_VER" && ./contrib/download_prerequisites) || true; fi
"$buildroot/src/gcc-$GCC_VER/configure" --prefix=/usr --with-sysroot="$CHROOT_DIR" --disable-nls --enable-languages=c,c++ --disable-multilib
make -j"$JOBS"
make DESTDIR="$CHROOT_DIR" install
mkdir -p "$buildroot/build-glibc"
cd "$buildroot/build-glibc"
"$buildroot/src/glibc-$GLIBC_VER/configure" --prefix=/usr --host=x86_64-pc-linux-gnu --build=x86_64-pc-linux-gnu --enable-kernel=4.14 --with-headers=/usr/include libc_cv_slibdir=/usr/lib
make -j"$JOBS"
make DESTDIR="$CHROOT_DIR" install
mkdir -p "$CHROOT_DIR/etc"
[ -f "$CHROOT_DIR/etc/ld.so.conf" ] || printf '/usr/local/lib\n/usr/lib\n/lib\n' > "$CHROOT_DIR/etc/ld.so.conf"
log "OK: toolchain + glibc instalada no chroot."
