#!/bin/sh
set -eu
CONFIG_FILE="${1:-./config.sh}"
BASE_DIR=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
. "$BASE_DIR/lib/common.sh"
CONFIG_FILE="$CONFIG_FILE"
load_config
need_root
require_vars CHROOT_DIR WORK_DIR DISTFILES_DIR JOBS HOSTNAME
SYSV_VER="${SYSV_VER:-3.15}"
SYSV_TAR="sysvinit-$SYSV_VER.tar.xz"
SYSV_URL="${SYSV_URL:-https://download.savannah.gnu.org/releases/sysvinit/$SYSV_TAR}"
SYSV_SHA256="${SYSV_SHA256:-}"
fetch "$SYSV_URL" "$DISTFILES_DIR/$SYSV_TAR"; verify_sha256 "$DISTFILES_DIR/$SYSV_TAR" "$SYSV_SHA256"
need_cmd tar; need_cmd make
bdir=$(mktemp_dir "$WORK_DIR"); trap 'rm -rf "$bdir"' EXIT INT TERM
tar -xf "$DISTFILES_DIR/$SYSV_TAR" -C "$bdir"
cd "$bdir/sysvinit-$SYSV_VER"
make -j"$JOBS"
make ROOT="$CHROOT_DIR" install
cat > "$CHROOT_DIR/etc/inittab" <<'EOF'
id:3:initdefault:
si::sysinit:/etc/rc.d/rc.S
l3:3:wait:/etc/rc.d/rc 3
ca:12345:ctrlaltdel:/sbin/shutdown -t1 -a -r now
EOF
mkdir -p "$CHROOT_DIR/etc/rc.d" "$CHROOT_DIR/etc/rc.d/init.d" "$CHROOT_DIR/etc/rc.d/rcS.d" "$CHROOT_DIR/etc/rc.d/rc3.d" "$CHROOT_DIR/etc/sysconfig"
cat > "$CHROOT_DIR/etc/rc.d/rc.S" <<'EOF'
#!/bin/sh
PATH=/usr/sbin:/usr/bin:/sbin:/bin
mount -n -t proc proc /proc 2>/dev/null || true
mount -n -t sysfs sysfs /sys 2>/dev/null || true
mount -n -t tmpfs tmpfs /run 2>/dev/null || true
if [ -d /etc/modules-load.d ]; then
  for f in /etc/modules-load.d/*.conf; do
    [ -f "$f" ] || continue
    while IFS= read -r m; do
      case "$m" in ''|\#*) continue ;; esac
      modprobe "$m" 2>/dev/null || true
    done < "$f"
  done
fi
if [ -f /etc/hostname ]; then hn=$(cat /etc/hostname 2>/dev/null || true); [ -n "$hn" ] && hostname "$hn" 2>/dev/null || true; fi
command -v syslogd >/dev/null 2>&1 && syslogd 2>/dev/null || true
command -v klogd >/dev/null 2>&1 && klogd 2>/dev/null || true
for s in /etc/rc.d/rcS.d/S*; do [ -x "$s" ] && "$s" start || true; done
EOF
chmod 0755 "$CHROOT_DIR/etc/rc.d/rc.S"
cat > "$CHROOT_DIR/etc/rc.d/rc" <<'EOF'
#!/bin/sh
runlevel="${1:-3}"
PATH=/usr/sbin:/usr/bin:/sbin:/bin
dir="/etc/rc.d/rc${runlevel}.d"
[ -d "$dir" ] || exit 0
for s in "$dir"/S*; do [ -x "$s" ] && "$s" start || true; done
exit 0
EOF
chmod 0755 "$CHROOT_DIR/etc/rc.d/rc"
cat > "$CHROOT_DIR/etc/rc.d/init.d/mountfs" <<'EOF'
#!/bin/sh
case "$1" in start) mount -a 2>/dev/null || true ;; esac
exit 0
EOF
chmod 0755 "$CHROOT_DIR/etc/rc.d/init.d/mountfs"
cat > "$CHROOT_DIR/etc/rc.d/init.d/network" <<'EOF'
#!/bin/sh
CONF=/etc/sysconfig/network.conf
IFACE=""; USE_DHCP=1; STATIC_IP=""; GATEWAY=""; DNS1=""; DNS2=""
[ -f "$CONF" ] && . "$CONF" || true
auto_iface(){ command -v ip >/dev/null 2>&1 && ip -o link | awk -F': ' '{print $2}' | awk '!/^lo$/ {print; exit}' || echo eth0; }
start_net(){
  [ -n "$IFACE" ] || IFACE="$(auto_iface)"
  ip link set "$IFACE" up 2>/dev/null || true
  if [ "${USE_DHCP:-1}" -eq 1 ]; then
    command -v udhcpc >/dev/null 2>&1 && udhcpc -i "$IFACE" -q -t 5 -T 3 2>/dev/null || true
    command -v dhclient >/dev/null 2>&1 && dhclient "$IFACE" 2>/dev/null || true
  else
    [ -n "$STATIC_IP" ] && ip addr add "$STATIC_IP" dev "$IFACE" 2>/dev/null || true
    [ -n "$GATEWAY" ] && ip route add default via "$GATEWAY" 2>/dev/null || true
  fi
  if [ -n "$DNS1" ] || [ -n "$DNS2" ]; then
    : > /etc/resolv.conf
    [ -n "$DNS1" ] && echo "nameserver $DNS1" >> /etc/resolv.conf
    [ -n "$DNS2" ] && echo "nameserver $DNS2" >> /etc/resolv.conf
  fi
}
stop_net(){ [ -n "$IFACE" ] || IFACE="$(auto_iface)"; ip link set "$IFACE" down 2>/dev/null || true; }
case "$1" in start) start_net ;; stop) stop_net ;; restart) stop_net; start_net ;; *) echo "usage: $0 {start|stop|restart}"; exit 1 ;; esac
EOF
chmod 0755 "$CHROOT_DIR/etc/rc.d/init.d/network"
cat > "$CHROOT_DIR/etc/sysconfig/network.conf" <<EOF
IFACE="${NET_IFACE:-}"
USE_DHCP=${NET_USE_DHCP:-1}
STATIC_IP="${NET_STATIC_IP:-}"
GATEWAY="${NET_GATEWAY:-}"
DNS1="${NET_DNS1:-1.1.1.1}"
DNS2="${NET_DNS2:-8.8.8.8}"
EOF
ln -sf ../init.d/mountfs "$CHROOT_DIR/etc/rc.d/rcS.d/S10mountfs" 2>/dev/null || true
ln -sf ../init.d/network "$CHROOT_DIR/etc/rc.d/rc3.d/S20network" 2>/dev/null || true
log "OK: sysvinit instalado e configurado."
