#!/bin/sh
set -eu
CONFIG_FILE="${1:-./config.sh}"
BASE_DIR=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
. "$BASE_DIR/lib/common.sh"
CONFIG_FILE="$CONFIG_FILE"
load_config
need_root
require_vars CHROOT_DIR WORK_DIR DISTFILES_DIR JOBS
BUSYBOX_VER="${BUSYBOX_VER:-1.36.1}"
BUSYBOX_TAR="busybox-$BUSYBOX_VER.tar.bz2"
BUSYBOX_URL="${BUSYBOX_URL:-https://busybox.net/downloads/$BUSYBOX_TAR}"
BUSYBOX_SHA256="${BUSYBOX_SHA256:-}"
fetch "$BUSYBOX_URL" "$DISTFILES_DIR/$BUSYBOX_TAR"
verify_sha256 "$DISTFILES_DIR/$BUSYBOX_TAR" "$BUSYBOX_SHA256"
need_cmd tar; need_cmd make; need_cmd gcc
bdir=$(mktemp_dir "$WORK_DIR"); trap 'rm -rf "$bdir"' EXIT INT TERM
tar -xf "$DISTFILES_DIR/$BUSYBOX_TAR" -C "$bdir"
cd "$bdir/busybox-$BUSYBOX_VER"
make defconfig
if grep -q '^# CONFIG_STATIC is not set' .config; then sed -i 's/^# CONFIG_STATIC is not set/CONFIG_STATIC=y/' .config; else grep -q '^CONFIG_STATIC=y' .config || printf '\nCONFIG_STATIC=y\n' >> .config; fi
grep -q '^CONFIG_ASH=y' .config || printf '\nCONFIG_ASH=y\n' >> .config
make -j"$JOBS"
make CONFIG_PREFIX="$CHROOT_DIR" install
[ -x "$CHROOT_DIR/bin/sh" ] || ln -sf busybox "$CHROOT_DIR/bin/sh" 2>/dev/null || true
log "OK: busybox bootstrap instalado."
