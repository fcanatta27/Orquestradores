#!/bin/sh
set -eu
CONFIG_FILE="${1:-./config.sh}"
BASE_DIR=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
. "$BASE_DIR/lib/common.sh"
CONFIG_FILE="$CONFIG_FILE"
load_config
need_root
require_vars CHROOT_DIR HOSTNAME
log "Criando layout mínimo em $CHROOT_DIR..."
for d in bin sbin lib lib64 usr/bin usr/sbin usr/lib usr/lib64 etc var tmp root home proc sys dev run mnt opt boot; do mkdir -p "$CHROOT_DIR/$d"; done
chmod 1777 "$CHROOT_DIR/tmp" 2>/dev/null || true
mkdir -p "$CHROOT_DIR/var/lib/mypkg" "$CHROOT_DIR/var/cache/mypkg" "$CHROOT_DIR/var/log/mypkg"
mkdir -p "$CHROOT_DIR/etc/modules-load.d" "$CHROOT_DIR/etc/rc.d/init.d" "$CHROOT_DIR/etc/rc.d/rcS.d" "$CHROOT_DIR/etc/rc.d/rc3.d"
mkdir -p "$CHROOT_DIR/boot/grub" "$CHROOT_DIR/boot/efi" "$CHROOT_DIR/etc/sysconfig"
printf '%s\n' "$HOSTNAME" > "$CHROOT_DIR/etc/hostname" 2>/dev/null || true
[ -f "$CHROOT_DIR/etc/passwd" ] || printf 'root:x:0:0:root:/root:/bin/sh\n' > "$CHROOT_DIR/etc/passwd"
[ -f "$CHROOT_DIR/etc/group" ] || printf 'root:x:0:\ntty:x:5:\n' > "$CHROOT_DIR/etc/group"
log "OK: layout criado."
