#!/bin/sh
set -eu
CONFIG_FILE="${1:-./config.sh}"
BASE_DIR=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
. "$BASE_DIR/lib/common.sh"
CONFIG_FILE="$CONFIG_FILE"
load_config
need_root
require_vars CHROOT_DIR NET_DNS1
[ -x "$CHROOT_DIR/bin/sh" ] || die "Sem /bin/sh no chroot. Rode o stage 02."
mkdir -p "$CHROOT_DIR/dev" "$CHROOT_DIR/proc" "$CHROOT_DIR/sys" "$CHROOT_DIR/run"
cat > "$CHROOT_DIR/etc/profile" <<'EOF'
export PATH=/usr/sbin:/usr/bin:/sbin:/bin
export PS1='\u:\w\$ '
EOF
cat > "$CHROOT_DIR/etc/resolv.conf" <<EOF
nameserver ${NET_DNS1:-1.1.1.1}
EOF
[ -n "${NET_DNS2:-}" ] && printf 'nameserver %s\n' "$NET_DNS2" >> "$CHROOT_DIR/etc/resolv.conf"
ln -sf /proc/self/mounts "$CHROOT_DIR/etc/mtab" 2>/dev/null || true
log "OK: base mínimo preparado."
