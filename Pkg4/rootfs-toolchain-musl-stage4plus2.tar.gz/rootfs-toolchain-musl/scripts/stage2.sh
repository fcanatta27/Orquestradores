#!/bin/sh
# stage2.sh - Build a compact Stage2 inside ROOTFS using chroot-run.sh.
# POSIX /bin/sh only. Retomada por markers + logs.
#
# Goal: provide enough tools to build Stage3 comfortably, without bloat.

set -eu

###############################################################################
# Configuration (edit here or override via environment)
###############################################################################

ROOTFS=${ROOTFS:-/mnt/rootfs}
TOOLS=${TOOLS:-$ROOTFS/tools}
TARGET=${TARGET:-x86_64-linux-musl}

SRCDIR=${SRCDIR:-$ROOTFS/sources}
BUILDDIR=${BUILDDIR:-$ROOTFS/build-stage2}
STATE=${STATE:-$ROOTFS/state-stage2}
LOGDIR=${LOGDIR:-$ROOTFS/logs-stage2}

JOBS=${JOBS:-1}

# Safe defaults
CFLAGS_BASE=${CFLAGS_BASE:--O2 -pipe}
CFLAGS_HARDEN=${CFLAGS_HARDEN:--fstack-protector-strong -D_FORTIFY_SOURCE=2}
CFLAGS=${CFLAGS:-$CFLAGS_BASE $CFLAGS_HARDEN}
CXXFLAGS=${CXXFLAGS:-$CFLAGS}
LDFLAGS=${LDFLAGS:--Wl,-z,relro -Wl,-z,now}

# Versions (keep in sync with your tarballs)
BINUTILS_VER=${BINUTILS_VER:-2.45.1}
GCC_VER=${GCC_VER:-15.2.0}

COREUTILS_VER=${COREUTILS_VER:-9.9}
TAR_VER=${TAR_VER:-1.35}
UTIL_LINUX_VER=${UTIL_LINUX_VER:-2.41.3}

BISON_VER=${BISON_VER:-3.8.2}
FLEX_VER=${FLEX_VER:-2.6.4}
TEXINFO_VER=${TEXINFO_VER:-7.1}
GPERF_VER=${GPERF_VER:-3.1}
PERL_VER=${PERL_VER:-5.40.1}

# GCC deps (bundled into GCC source tree during build)
GMP_VER=${GMP_VER:-6.3.0}
MPFR_VER=${MPFR_VER:-4.2.2}
MPC_VER=${MPC_VER:-1.3.1}
ISL_VER=${ISL_VER:-0.27}

CHROOT_RUN=${CHROOT_RUN:-./scripts/chroot-run.sh}

# Default bind mounts for chroot-run.sh:
# Map sources and build dirs inside chroot as /sources and /build
BIND_MOUNTS=${BIND_MOUNTS:-"$SRCDIR:/sources $BUILDDIR:/build"}
BIND_RO_MOUNTS=${BIND_RO_MOUNTS:-}

###############################################################################
# Helpers
###############################################################################

umask 022

msg(){ printf '%s\n' "$*" >&2; }
die(){ msg "ERROR: $*"; exit 1; }
need(){ command -v "$1" >/dev/null 2>&1 || die "missing: $1"; }
ensure(){ [ -d "$1" ] || mkdir -p "$1"; }

state_has(){ [ -f "$STATE/$1.ok" ]; }
state_mark(){ : >"$STATE/$1.ok"; }

tb_find() {
  name=$1 ver=$2
  for ext in tar.xz tar.gz tgz tar.bz2 tar; do
    p="$SRCDIR/$name-$ver.$ext"
    [ -f "$p" ] && { printf '%s\n' "$p"; return 0; }
  done
  return 1
}

run_step(){
  step=$1; shift
  ensure "$LOGDIR"
  log="$LOGDIR/$step.log"
  msg "==> $step"
  msg "    log: $log"
  ( set -eu; "$@" ) >"$log" 2>&1
}

chrun(){
  ROOTFS="$ROOTFS" BIND_MOUNTS="$BIND_MOUNTS" BIND_RO_MOUNTS="$BIND_RO_MOUNTS" \
    "$CHROOT_RUN" run "$1"
}

###############################################################################
# Steps
###############################################################################

step_00_sanity(){
  need tar
  need make
  ensure "$STATE" "$LOGDIR" "$BUILDDIR" "$SRCDIR"
  [ -x "$CHROOT_RUN" ] || die "missing CHROOT_RUN: $CHROOT_RUN"
  ensure "$ROOTFS/sources" "$ROOTFS/build-stage2"
}

step_10_native_binutils(){
  state_has 10_native_binutils && return 0
  tb=$(tb_find binutils "$BINUTILS_VER") || die "missing binutils tarball"
  chrun "
set -eu
cd /build
rm -rf binutils-build binutils-$BINUTILS_VER
tar -xf /sources/$(basename \"$tb\")
mkdir -p binutils-build
cd binutils-build
../binutils-$BINUTILS_VER/configure \\
  --prefix=/usr \\
  --build=$TARGET \\
  --host=$TARGET \\
  --target=$TARGET \\
  --disable-multilib \\
  --disable-nls \\
  --enable-gold \\
  --enable-plugins
make -j$JOBS
make install
"
  state_mark 10_native_binutils
}

step_20_native_gcc(){
  state_has 20_native_gcc && return 0
  tb=$(tb_find gcc "$GCC_VER") || die "missing gcc tarball"
  gmp=$(tb_find gmp "$GMP_VER") || die "missing gmp"
  mpfr=$(tb_find mpfr "$MPFR_VER") || die "missing mpfr"
  mpc=$(tb_find mpc "$MPC_VER") || die "missing mpc"
  isl=$(tb_find isl "$ISL_VER") || die "missing isl"

  chrun "
set -eu
cd /build
rm -rf gcc-build gcc-$GCC_VER
tar -xf /sources/$(basename \"$tb\")
cd gcc-$GCC_VER
tar -xf /sources/$(basename \"$gmp\");  mv gmp-$GMP_VER gmp
tar -xf /sources/$(basename \"$mpfr\"); mv mpfr-$MPFR_VER mpfr
tar -xf /sources/$(basename \"$mpc\");  mv mpc-$MPC_VER mpc
tar -xf /sources/$(basename \"$isl\");  mv isl-$ISL_VER isl
cd /build
mkdir -p gcc-build
cd gcc-build
export CFLAGS='$CFLAGS'
export CXXFLAGS='$CXXFLAGS'
export LDFLAGS='$LDFLAGS'
../gcc-$GCC_VER/configure \\
  --prefix=/usr \\
  --build=$TARGET \\
  --host=$TARGET \\
  --target=$TARGET \\
  --disable-multilib \\
  --disable-nls \\
  --enable-languages=c,c++ \\
  --with-native-system-header-dir=/usr/include \\
  --disable-libsanitizer \\
  --disable-libssp \\
  --disable-libquadmath \\
  --disable-libquadmath-support
make -j$JOBS
make install
"
  state_mark 20_native_gcc
}

step_30_coreutils_tar_util_linux(){
  state_has 30_coreutils_tar_util_linux && return 0
  core=$(tb_find coreutils "$COREUTILS_VER") || die "missing coreutils"
  tarb=$(tb_find tar "$TAR_VER") || die "missing tar"
  utl=$(tb_find util-linux "$UTIL_LINUX_VER") || die "missing util-linux"

  chrun "
set -eu
cd /build

# coreutils
rm -rf coreutils-$COREUTILS_VER coreutils-build
tar -xf /sources/$(basename \"$core\")
mkdir -p coreutils-build && cd coreutils-build
../coreutils-$COREUTILS_VER/configure --prefix=/usr --enable-install-program=hostname
make -j$JOBS
make install
cd /build

# tar
rm -rf tar-$TAR_VER tar-build
tar -xf /sources/$(basename \"$tarb\")
mkdir -p tar-build && cd tar-build
../tar-$TAR_VER/configure --prefix=/usr
make -j$JOBS
make install
cd /build

# util-linux (avoid login/su/setuid pieces; keep build tools)
rm -rf util-linux-$UTIL_LINUX_VER util-linux-build
tar -xf /sources/$(basename \"$utl\")
mkdir -p util-linux-build && cd util-linux-build
../util-linux-$UTIL_LINUX_VER/configure \\
  --prefix=/usr \\
  --disable-chfn-chsh \\
  --disable-login \\
  --disable-su \\
  --disable-setpriv \\
  --disable-runuser \\
  --disable-pylibmount \\
  --without-python \\
  --without-systemd \\
  --disable-makeinstall-chown \\
  --disable-makeinstall-setuid
make -j$JOBS
make install
"
  state_mark 30_coreutils_tar_util_linux
}

step_40_build_helpers(){
  state_has 40_build_helpers && return 0
  bison=$(tb_find bison "$BISON_VER") || die "missing bison"
  flex=$(tb_find flex "$FLEX_VER") || die "missing flex"
  texi=$(tb_find texinfo "$TEXINFO_VER") || die "missing texinfo"
  gprf=$(tb_find gperf "$GPERF_VER") || die "missing gperf"
  perl=$(tb_find perl "$PERL_VER") || die "missing perl"

  chrun "
set -eu
cd /build

# bison
rm -rf bison-$BISON_VER bison-build
tar -xf /sources/$(basename \"$bison\")
mkdir -p bison-build && cd bison-build
../bison-$BISON_VER/configure --prefix=/usr
make -j$JOBS
make install
cd /build

# flex
rm -rf flex-$FLEX_VER flex-build
tar -xf /sources/$(basename \"$flex\")
mkdir -p flex-build && cd flex-build
../flex-$FLEX_VER/configure --prefix=/usr
make -j$JOBS
make install
cd /build

# texinfo
rm -rf texinfo-$TEXINFO_VER texinfo-build
tar -xf /sources/$(basename \"$texi\")
mkdir -p texinfo-build && cd texinfo-build
../texinfo-$TEXINFO_VER/configure --prefix=/usr
make -j$JOBS
make install
cd /build

# gperf
rm -rf gperf-$GPERF_VER gperf-build
tar -xf /sources/$(basename \"$gprf\")
mkdir -p gperf-build && cd gperf-build
../gperf-$GPERF_VER/configure --prefix=/usr
make -j$JOBS
make install
cd /build

# perl (needed by many upstream build systems)
rm -rf perl-$PERL_VER
tar -xf /sources/$(basename \"$perl\")
cd perl-$PERL_VER
sh Configure -des -Dprefix=/usr -Dvendorprefix=/usr -Duseshrplib
make -j$JOBS
make install
"
  state_mark 40_build_helpers
}

step_90_verify(){
  state_has 90_verify && return 0
  chrun "
set -eu
command -v gcc >/dev/null
command -v ld  >/dev/null
command -v ar  >/dev/null
gcc --version
ld --version
cat > /tmp/stage2-smoke.c <<'C'
#include <stdio.h>
int main(void){ puts(\"stage2 ok\"); return 0; }
C
gcc -O2 /tmp/stage2-smoke.c -o /tmp/stage2-smoke
/tmp/stage2-smoke
"
  state_mark 90_verify
}

###############################################################################
# Main
###############################################################################

cmd=${1:-all}
case "$cmd" in
  all)
    run_step 00_sanity step_00_sanity
    run_step 10_native_binutils step_10_native_binutils
    run_step 20_native_gcc step_20_native_gcc
    run_step 30_coreutils_tar_util_linux step_30_coreutils_tar_util_linux
    run_step 40_build_helpers step_40_build_helpers
    run_step 90_verify step_90_verify
    ;;
  verify)
    run_step 90_verify step_90_verify
    ;;
  *)
    die "unknown command: $cmd"
    ;;
esac
