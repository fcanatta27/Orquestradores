#!/bin/sh
# revdep.sh - Reverse dependency / broken linkage scanner (musl-friendly)
#
# SPDX-License-Identifier: GPL-3.0-or-later
#
# Purpose:
#   Scan a root filesystem for ELF executables and shared libraries, then:
#     - list missing DT_NEEDED libraries
#     - optionally list all dependencies
#     - optionally validate PT_INTERP (musl loader)
#
# Design goals:
#   - POSIX /bin/sh only
#   - minimal external commands: find, awk, sed, sort, uniq, readelf
#   - fast enough for repeated runs via a cached library index
#
# Exit codes:
#   0: no missing libs found
#   2: missing libs found (or strict checks failed)
#   1: usage or fatal error

set -eu

ROOT=/
PRINT_ALL=0
STRICT=0
NO_COLOR=0
FORMAT=plain

# Override paths (space-separated, absolute inside ROOT)
OVERRIDE_PATHS=""

# Ignore patterns (shell patterns, space-separated)
IGNORE_FILE_PATTERNS="/proc/* /sys/* /dev/*"
IGNORE_LIB_PATTERNS="ld-linux*.so* linux-vdso.so*"

# Validate interpreter (musl); set to empty to disable
EXPECT_INTERP="/lib/ld-musl-x86_64.so.1"

msg(){ printf '%s\n' "$*" >&2; }
die(){ msg "ERROR: $*"; exit 1; }

need(){ command -v "$1" >/dev/null 2>&1 || die "missing command: $1"; }

usage() {
  cat <<EOF
Usage:
  $0 [options]

Options:
  --root <path>          Root filesystem to scan (default: /)
  --paths "<p1 p2 ...>"  Override library search paths (inside root)
  --all                  Print all DT_NEEDED edges (not only missing)
  --strict               Exit 2 if any file has unexpected interpreter
  --expect-interp <p>    Expected PT_INTERP path (default: /lib/ld-musl-x86_64.so.1); empty disables
  --ignore-file "<pat..>" Ignore file glob patterns (default covers /proc,/sys,/dev)
  --ignore-lib "<pat..>"  Ignore library glob patterns
  --format plain|tsv     Output format (default: plain)
  --no-color             Disable color (plain format only)
  -h, --help

Exit:
  0 ok, 2 problems found, 1 fatal
EOF
}

parse_args() {
  while [ $# -gt 0 ]; do
    case "$1" in
      --root) ROOT=$2; shift 2 ;;
      --paths) OVERRIDE_PATHS=$2; shift 2 ;;
      --all) PRINT_ALL=1; shift ;;
      --strict) STRICT=1; shift ;;
      --expect-interp) EXPECT_INTERP=$2; shift 2 ;;
      --ignore-file) IGNORE_FILE_PATTERNS=$2; shift 2 ;;
      --ignore-lib) IGNORE_LIB_PATTERNS=$2; shift 2 ;;
      --format) FORMAT=$2; shift 2 ;;
      --no-color) NO_COLOR=1; shift ;;
      -h|--help) usage; exit 0 ;;
      *) die "unknown option: $1" ;;
    esac
  done
}

case "$ROOT" in
  /) : ;;
  */) ROOT=${ROOT%/} ;;
  *) : ;;
esac

# color
c_reset='' c_red='' c_yellow='' c_green='' c_bold=''
if [ "$NO_COLOR" = "0" ] && [ -t 2 ]; then
  c_reset='\033[0m'
  c_red='\033[31m'
  c_yellow='\033[33m'
  c_green='\033[32m'
  c_bold='\033[1m'
fi

is_ignored_file() {
  f=$1
  for pat in $IGNORE_FILE_PATTERNS; do
    case "$f" in
      $pat) return 0 ;;
    esac
  done
  return 1
}

is_ignored_lib() {
  lib=$1
  for pat in $IGNORE_LIB_PATTERNS; do
    case "$lib" in
      $pat) return 0 ;;
    esac
  done
  return 1
}

# Build library index: SONAME-like file names -> paths
# Cached under ROOT/var/cache/revdep
cache_dir() {
  d="$ROOT/var/cache/revdep"
  mkdir -p "$d" 2>/dev/null || :
  printf '%s\n' "$d"
}

lib_paths() {
  if [ -n "$OVERRIDE_PATHS" ]; then
    printf '%s\n' "$OVERRIDE_PATHS"
    return 0
  fi
  # Common loader search paths; adjust as needed
  printf '%s\n' "/lib /usr/lib /usr/local/lib"
}

build_index() {
  idx=$1
  : >"$idx"
  for p in $(lib_paths); do
    [ -d "$ROOT$p" ] || continue
    find "$ROOT$p" -xdev -type f -name '*.so*' 2>/dev/null | while IFS= read -r full; do
      rel=${full#"$ROOT"}
      base=$(basename "$rel")
      printf '%s\t%s\n' "$base" "$rel"
    done
  done | sort -u >"$idx"
}

index_lookup() {
  lib=$1 idx=$2
  # first match is enough
  awk -F'\t' -v n="$lib" '($1==n){print $2; exit 0}' "$idx"
}

elf_needed() {
  f=$1
  readelf -d "$f" 2>/dev/null | awk -F'[][]' '/Shared library: \[/{print $2}'
}

elf_interp() {
  f=$1
  readelf -l "$f" 2>/dev/null | awk '/Requesting program interpreter/{gsub(/.*\[/,""); gsub(/\].*/,""); print; exit}'
}

scan() {
  need find
  need awk
  need readelf
  need sort

  cd "$ROOT" || die "cannot access ROOT: $ROOT"

  cdir=$(cache_dir)
  idx="$cdir/libindex.tsv"
  if [ ! -f "$idx" ]; then
    build_index "$idx"
  fi

  missing=0
  badinterp=0

  # Collect candidates: ELF executables and shared objects in common locations
  find . -xdev \( -type f -o -type l \) 2>/dev/null | while IFS= read -r p; do
    # skip ignored
    is_ignored_file "$p" && continue
    # resolve to a file path in ROOT
    fp="$ROOT/${p#./}"
    [ -f "$fp" ] || continue

    # Quick ELF magic check
    # POSIX: read first 4 bytes via dd+od is heavy; use readelf attempt
    needed=$(elf_needed "$fp" 2>/dev/null || :)
    interp=""
    if [ "$STRICT" = "1" ] && [ -n "$EXPECT_INTERP" ]; then
      interp=$(elf_interp "$fp" 2>/dev/null || :)
      if [ -n "$interp" ] && [ "$interp" != "$EXPECT_INTERP" ]; then
        badinterp=$((badinterp+1))
        if [ "$FORMAT" = "tsv" ]; then
          printf 'BAD_INTERP\t%s\t%s\t%s\n' "${p#./}" "$interp" "$EXPECT_INTERP"
        else
          msg "${c_yellow}BAD_INTERP${c_reset} ${p#./} interp=$interp expected=$EXPECT_INTERP"
        fi
      fi
    fi

    [ -n "$needed" ] || continue

    for lib in $needed; do
      is_ignored_lib "$lib" && continue
      found=$(index_lookup "$lib" "$idx" || :)
      if [ -z "$found" ]; then
        missing=$((missing+1))
        if [ "$FORMAT" = "tsv" ]; then
          printf 'MISSING\t%s\t%s\n' "${p#./}" "$lib"
        else
          msg "${c_red}MISSING${c_reset} ${p#./} needs $lib"
        fi
      else
        if [ "$PRINT_ALL" = "1" ]; then
          if [ "$FORMAT" = "tsv" ]; then
            printf 'OK\t%s\t%s\t%s\n' "${p#./}" "$lib" "$found"
          else
            msg "${c_green}OK${c_reset} ${p#./} needs $lib -> $found"
          fi
        fi
      fi
    done
  done

  # Summaries: the while loop is in a subshell in many sh implementations.
  # To keep exit codes correct, re-scan using temp files.
}

scan_with_report() {
  tmp="$ROOT/var/cache/revdep/scan.tsv.$$"
  rm -f "$tmp" 2>/dev/null || :
  # capture output in TSV always for counting
  NO_COLOR=1 FORMAT=tsv PRINT_ALL="$PRINT_ALL" STRICT="$STRICT" EXPECT_INTERP="$EXPECT_INTERP" \
    OVERRIDE_PATHS="$OVERRIDE_PATHS" IGNORE_FILE_PATTERNS="$IGNORE_FILE_PATTERNS" IGNORE_LIB_PATTERNS="$IGNORE_LIB_PATTERNS" \
    sh "$0" --root "$ROOT" --format tsv ${PRINT_ALL:+--all} ${STRICT:+--strict} --expect-interp "$EXPECT_INTERP" --ignore-file "$IGNORE_FILE_PATTERNS" --ignore-lib "$IGNORE_LIB_PATTERNS" --paths "$OVERRIDE_PATHS" 2>/dev/null >"$tmp" || :

  miss=$(awk -F'\t' '$1=="MISSING"{c++} END{print c+0}' "$tmp")
  bad=$(awk -F'\t' '$1=="BAD_INTERP"{c++} END{print c+0}' "$tmp")

  # Print in requested format
  if [ "$FORMAT" = "tsv" ]; then
    cat "$tmp"
  else
    # plain: re-run scan with colors
    NO_COLOR="$NO_COLOR" FORMAT=plain PRINT_ALL="$PRINT_ALL" STRICT="$STRICT" EXPECT_INTERP="$EXPECT_INTERP" \
      OVERRIDE_PATHS="$OVERRIDE_PATHS" IGNORE_FILE_PATTERNS="$IGNORE_FILE_PATTERNS" IGNORE_LIB_PATTERNS="$IGNORE_LIB_PATTERNS" \
      scan_plain
  fi

  rm -f "$tmp" 2>/dev/null || :

  if [ "$miss" -gt 0 ] || [ "$bad" -gt 0 ]; then
    msg "${c_bold}revdep:${c_reset} missing=$miss bad_interp=$bad"
    exit 2
  fi
  msg "${c_bold}revdep:${c_reset} ok"
  exit 0
}

scan_plain() {
  # plain scan without subshell-counting requirements; intended for interactive output
  need find; need awk; need readelf; need sort
  cd "$ROOT" || die "cannot access ROOT: $ROOT"
  cdir=$(cache_dir)
  idx="$cdir/libindex.tsv"
  [ -f "$idx" ] || build_index "$idx"

  find . -xdev -type f 2>/dev/null | while IFS= read -r p; do
    is_ignored_file "$p" && continue
    fp="$ROOT/${p#./}"
    needed=$(elf_needed "$fp" 2>/dev/null || :)
    if [ "$STRICT" = "1" ] && [ -n "$EXPECT_INTERP" ]; then
      interp=$(elf_interp "$fp" 2>/dev/null || :)
      if [ -n "$interp" ] && [ "$interp" != "$EXPECT_INTERP" ]; then
        msg "${c_yellow}BAD_INTERP${c_reset} ${p#./} interp=$interp expected=$EXPECT_INTERP"
      fi
    fi
    [ -n "$needed" ] || continue
    for lib in $needed; do
      is_ignored_lib "$lib" && continue
      found=$(index_lookup "$lib" "$idx" || :)
      if [ -z "$found" ]; then
        msg "${c_red}MISSING${c_reset} ${p#./} needs $lib"
      else
        [ "$PRINT_ALL" = "1" ] && msg "${c_green}OK${c_reset} ${p#./} needs $lib -> $found"
      fi
    done
  done
}

main() {
  parse_args "$@"
  case "$FORMAT" in
    plain|tsv) : ;;
    *) die "unknown format: $FORMAT" ;;
  esac

  # In tsv mode, do a direct scan (no summary)
  if [ "$FORMAT" = "tsv" ]; then
    need find; need awk; need readelf; need sort
    cd "$ROOT" || die "cannot access ROOT: $ROOT"
    cdir=$(cache_dir)
    idx="$cdir/libindex.tsv"
    [ -f "$idx" ] || build_index "$idx"

    find . -xdev -type f 2>/dev/null | while IFS= read -r p; do
      is_ignored_file "$p" && continue
      fp="$ROOT/${p#./}"
      needed=$(elf_needed "$fp" 2>/dev/null || :)
      if [ "$STRICT" = "1" ] && [ -n "$EXPECT_INTERP" ]; then
        interp=$(elf_interp "$fp" 2>/dev/null || :)
        if [ -n "$interp" ] && [ "$interp" != "$EXPECT_INTERP" ]; then
          printf 'BAD_INTERP\t%s\t%s\t%s\n' "${p#./}" "$interp" "$EXPECT_INTERP"
        fi
      fi
      [ -n "$needed" ] || continue
      for lib in $needed; do
        is_ignored_lib "$lib" && continue
        found=$(index_lookup "$lib" "$idx" || :)
        if [ -z "$found" ]; then
          printf 'MISSING\t%s\t%s\n' "${p#./}" "$lib"
        else
          [ "$PRINT_ALL" = "1" ] && printf 'OK\t%s\t%s\t%s\n' "${p#./}" "$lib" "$found"
        fi
      done
    done
    exit 0
  fi

  scan_with_report
}

main "$@"
