#!/bin/sh
# chroot-run.sh - POSIX helper to run commands in a chroot with safe mounts.
#
# Subcommands:
#   run   '<cmd>'  : mount, run command in chroot, unmount
#   shell          : mount, interactive shell, unmount on exit
#   mount          : mount only
#   umount         : unmount only (best-effort)
#
# Environment (override as needed):
#   ROOTFS=/mnt/rootfs
#   CHROOT_SHELL=/bin/sh
#   PATH_IN_CHROOT=/usr/bin:/bin:/usr/sbin:/sbin:/tools/bin
#   BIND_MOUNTS="/host/path:/inside/chroot ..."
#   BIND_RO_MOUNTS="/host/path:/inside/chroot ..."

set -eu

ROOTFS=${ROOTFS:-/mnt/rootfs}
CHROOT_SHELL=${CHROOT_SHELL:-/bin/sh}
PATH_IN_CHROOT=${PATH_IN_CHROOT:-/usr/bin:/bin:/usr/sbin:/sbin:/tools/bin}

BIND_MOUNTS=${BIND_MOUNTS:-}
BIND_RO_MOUNTS=${BIND_RO_MOUNTS:-}

msg() { printf '%s\n' "$*" >&2; }
die() { msg "ERROR: $*"; exit 1; }
need() { command -v "$1" >/dev/null 2>&1 || die "missing command: $1"; }

is_mounted() {
  mp=$1
  [ -r /proc/mounts ] || return 1
  # mountpoint is the 2nd field in /proc/mounts; assume no spaces in mp
  grep -F " $mp " /proc/mounts >/dev/null 2>&1
}

# Track mountpoints we mounted, to unmount in reverse order
MOUNTED=""

push_mount() {
  MOUNTED="$1 $MOUNTED"
}

mount_fs() {
  fstype=$1
  src=$2
  dst=$3
  opts=${4:-}
  mkdir -p "$dst"
  if ! is_mounted "$dst"; then
    if [ -n "$opts" ]; then
      mount -t "$fstype" -o "$opts" "$src" "$dst"
    else
      mount -t "$fstype" "$src" "$dst"
    fi
    push_mount "$dst"
  fi
}

mount_bind() {
  src=$1
  dst=$2
  ro=$3
  mkdir -p "$dst"
  if ! is_mounted "$dst"; then
    mount --bind "$src" "$dst"
    push_mount "$dst"
    if [ "$ro" = "1" ]; then
      # remount RO best-effort; different util-linux versions vary
      mount -o remount,ro,bind "$dst" 2>/dev/null || mount -o remount,ro "$dst" 2>/dev/null || :
    fi
  fi
}

do_mounts() {
  need awk
  need mount
  [ -d "$ROOTFS" ] || die "ROOTFS not found: $ROOTFS"
  mkdir -p "$ROOTFS/proc" "$ROOTFS/sys" "$ROOTFS/dev" "$ROOTFS/dev/pts"

  mount_fs proc proc "$ROOTFS/proc"
  mount_fs sysfs sysfs "$ROOTFS/sys"
  mount_bind /dev "$ROOTFS/dev" 0
  mount_fs devpts devpts "$ROOTFS/dev/pts" "gid=5,mode=620"

  if [ -n "$BIND_MOUNTS" ]; then
    for pair in $BIND_MOUNTS; do
      src=${pair%%:*}
      dst=${pair#*:}
      [ -e "$src" ] || die "bind source not found: $src"
      case "$dst" in
        /*) : ;;
        *) die "bind target must be absolute: $dst" ;;
      esac
      mount_bind "$src" "$ROOTFS$dst" 0
    done
  fi

  if [ -n "$BIND_RO_MOUNTS" ]; then
    for pair in $BIND_RO_MOUNTS; do
      src=${pair%%:*}
      dst=${pair#*:}
      [ -e "$src" ] || die "bind source not found: $src"
      case "$dst" in
        /*) : ;;
        *) die "bind target must be absolute: $dst" ;;
      esac
      mount_bind "$src" "$ROOTFS$dst" 1
    done
  fi
}

do_umounts() {
  need umount
  for mp in $MOUNTED; do
    if is_mounted "$mp"; then
      umount "$mp" 2>/dev/null || umount -l "$mp" 2>/dev/null || :
    fi
  done
  MOUNTED=""
}

run_chroot() {
  need chroot
  [ -x "$ROOTFS$CHROOT_SHELL" ] || die "missing shell in chroot: $CHROOT_SHELL"
  cmd=$1
  chroot "$ROOTFS" "$CHROOT_SHELL" -c "export PATH='$PATH_IN_CHROOT'; umask 022; $cmd"
}

usage() {
  cat <<EOF
Usage:
  $0 run '<cmd>'     Mount, run command in chroot, unmount
  $0 shell           Mount, interactive shell, unmount on exit
  $0 mount           Only mount
  $0 umount          Unmount (best-effort)
Env:
  ROOTFS=/mnt/rootfs
  CHROOT_SHELL=/bin/sh
  PATH_IN_CHROOT=/usr/bin:/bin:/usr/sbin:/sbin:/tools/bin
  BIND_MOUNTS="/host:/inside ..."
  BIND_RO_MOUNTS="/host:/inside ..."
EOF
}

sub=${1:-help}
shift 2>/dev/null || :

case "$sub" in
  run)
    [ $# -ge 1 ] || die "run requires a command string"
    do_mounts
    trap 'do_umounts' EXIT INT TERM
    run_chroot "$1"
    ;;
  shell)
    do_mounts
    trap 'do_umounts' EXIT INT TERM
    run_chroot "exec $CHROOT_SHELL -l"
    ;;
  mount)
    do_mounts
    msg "Mounted. Run: $0 umount"
    ;;
  umount)
    do_umounts
    msg "Unmounted."
    ;;
  help|-h|--help)
    usage
    ;;
  *)
    usage
    die "unknown subcommand: $sub"
    ;;
esac
