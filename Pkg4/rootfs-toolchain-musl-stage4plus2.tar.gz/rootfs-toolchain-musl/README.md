# rootfs-toolchain-musl

This project is released under the MIT License. See `LICENSE`.


Construção **reprodutível e retomável** de um toolchain temporário (estilo *LFS/Stage0*) usando **musl libc** para **x86_64**, instalando em:

- `TOOLS=/mnt/rootfs/tools` (padrão)
- `SYSROOT=/mnt/rootfs/tools/x86_64-linux-musl` (padrão)

O foco é uma alternativa **simples, compacta e funcional** ao fluxo do LFS para obter um toolchain temporário pronto para o **Stage1** (construção do sistema base).

## O que este projeto constrói

Ordem (com retomada automática por *markers*):

1. **Linux kernel headers** (UAPI) no sysroot
2. **Binutils** cross (`as`, `ld`, `ar`, `ranlib`, etc.)
3. **GCC pass1** (C + `libgcc`, sem headers libc)
4. **musl libc** (headers + libs no sysroot)
5. **GCC final** (C/C++ completo, apontando para o sysroot musl)
6. **Verificação** (compila e tenta executar um binário estático)

## Arquivos

- `build.sh` — script POSIX puro, resumível e com logs por etapa
- `README.md` — este documento

## Pré-requisitos (host)

Você precisa de um host Linux x86_64 relativamente padrão (Debian/Ubuntu/Fedora/Arch etc.) com ferramentas de compilação.

### Pacotes mínimos (host)

- `sh` (POSIX), `make`
- Compilador/assembler do host: `gcc` e `g++`
- Ferramentas básicas: `tar`, `awk`, `sed`, `mkdir`, `rm`
- Decompressão: `xz`, `gzip`, `bzip2`
- Opcional, mas recomendado: `sha256sum`

Em distros Debian/Ubuntu, normalmente:

```sh
sudo apt-get install build-essential tar xz-utils gzip bzip2 coreutils gawk sed
```

### Permissões / montagem

1. Garanta que **`/mnt/rootfs` exista e esteja montado** (se for um rootfs em outra partição).
2. Garanta que seu usuário tenha permissão de escrita em `/mnt/rootfs` (ou execute como root).
3. Garanta espaço em disco (ordem de dezenas de GB é normal para GCC + sources).

## Como obter os sources

O script **não baixa automaticamente** (para evitar dependência rígida de `curl/wget`).  
Você deve colocar os tarballs em:

- `SRCDIR=/mnt/rootfs/sources` (padrão)

Nomes esperados (por padrão):

- `binutils-2.45.1.tar.bz2`
- `gcc-15.2.0.tar.xz`
- `linux-6.18.2.tar.xz`
- `musl-1.2.5.tar.gz`
- `gmp-6.3.0.tar.xz`
- `mpfr-4.2.2.tar.xz`
- `mpc-1.3.1.tar.gz`
- `isl-0.27.tar.xz`

### URLs oficiais sugeridas

- Binutils: `https://ftp.gnu.org/gnu/binutils/`
- GCC: `https://ftp.gnu.org/gnu/gcc/gcc-15.2.0/`
- Linux: `https://www.kernel.org/pub/linux/kernel/v6.x/`
- musl: `https://musl.libc.org/releases/`
- GMP: `https://ftp.gnu.org/gnu/gmp/`
- MPFR: `https://ftp.gnu.org/gnu/mpfr/`
- MPC: `https://ftp.gnu.org/gnu/mpc/`
- ISL: `https://libisl.sourceforge.io/`

### Verificação de integridade

Por padrão, o script verifica SHA256 (se `sha256sum` existir). Para GCC, você pode (opcionalmente) fornecer um SHA512 oficial e habilitar `VERIFY_SHA512=1`.  
Você pode desabilitar:

```sh
VERIFY_SHA256=0 ./build.sh all
```

Para habilitar SHA512 (ex.: para o tarball do GCC), defina também:

```sh
VERIFY_SHA512=1 \
SHA512_GCC_XZ=<sha512_oficial_do_gcc_tar_xz> \
./build.sh all
```

Obs.: Linux kernel normalmente se verifica via assinatura PGP (`.tar.sign`). O script não falha por checksum do kernel.

## Como executar

1. Descompacte o pacote em algum diretório (ex.: `~/src/rootfs-toolchain-musl`).
2. Garanta que os tarballs estão em `/mnt/rootfs/sources`.
3. Execute:

```sh
cd rootfs-toolchain-musl
./build.sh all
```

### Variáveis configuráveis

Você pode sobrescrever qualquer variável via ambiente:

```sh
ROOTFS=/mnt/rootfs TOOLS=/mnt/rootfs/tools SRCDIR=/mnt/rootfs/sources BUILDDIR=/mnt/rootfs/build-toolchain JOBS=4 ./build.sh all
```

Principais:

- `ROOTFS` — ponto de montagem do rootfs
- `TOOLS` — prefixo da toolchain temporária
- `TARGET` — triple (padrão `x86_64-linux-musl`)
- `SYSROOT` — sysroot do target (padrão `$TOOLS/$TARGET`)
- `SRCDIR` — onde ficam os tarballs
- `BUILDDIR` — onde ficam os builds e logs
- `JOBS` — paralelismo do `make`
- `VERIFY_SHA256` — 1/0

### Retomada (resume)

O script grava markers em:

- `$BUILDDIR/state/*.done`

Se você interromper (Ctrl+C, reboot, etc.), basta rodar de novo:

```sh
./build.sh all
```

Ele pula automaticamente etapas concluídas.

### Limpeza

- Remover apenas a área de build/logs (não remove o toolchain instalado):

```sh
./build.sh clean
```

- Resetar build + state (não remove o toolchain instalado):

```sh
./build.sh reset
```

Se você quiser apagar o toolchain instalado, remova manualmente:

```sh
rm -rf /mnt/rootfs/tools
```

## Estrutura esperada ao final

- `/mnt/rootfs/tools/bin/x86_64-linux-musl-gcc`
- `/mnt/rootfs/tools/bin/x86_64-linux-musl-ld`
- `/mnt/rootfs/tools/x86_64-linux-musl/usr/include` (headers do kernel + musl)
- `/mnt/rootfs/tools/x86_64-linux-musl/lib/ld-musl-x86_64.so.1` (loader musl)

## Verificação (o que é checado)

A etapa `90_verify`:

- garante que `as/ld/gcc` do target executam
- checa `gcc -print-sysroot` (aviso se não bater)
- compila um **hello world estático** e tenta executar no host
- testa o pré-processador com headers musl

Se o host não for x86_64 Linux (ex.: build cross em outra arquitetura), a execução do binário pode falhar; o script só avisa.

## Notas importantes / escolhas técnicas

- Este toolchain é um **bootstrap**. Hardening agressivo (FORTIFY/CFI/LTO etc.) fica melhor para o Stage1/Stage2.
- O GCC é construído em duas fases para evitar dependência circular com libc.
- As libs GMP/MPFR/MPC/ISL são injetadas **in-tree** no source do GCC, evitando depender do host para elas.

## Troubleshooting

### “missing tarball”
Coloque o tarball esperado em `$SRCDIR` com o nome correto ou ajuste a variável `*_TAR`.

### Erros com `tar` e `.xz`
Você precisa de um `tar` com suporte a xz (GNU tar) **ou** de `xz` instalado.

### Falha ao executar o binário de teste
Se seu host não for x86_64 Linux, é esperado. Rode apenas `./build.sh verify` depois em um host compatível.

### “sha256 mismatch”
Baixe novamente a fonte, ou desabilite com `VERIFY_SHA256=0` (não recomendado).

## Licença

Este pacote de scripts e documentação é distribuído sob a licença **MIT**.  
Observação: os tarballs de terceiros (GCC, binutils, musl, kernel etc.) mantêm suas respectivas licenças.

Este projeto é apenas um script de automação. Os softwares baixados (GCC, binutils, musl, linux, etc.) têm suas próprias licenças.

---

## Stage1 (userland mínimo)

O script `scripts/stage1.sh` constrói um userland enxuto dentro de `ROOTFS` usando a toolchain temporária em `/tools`.

### Pré-requisitos

- Toolchain temporária concluída (`./build.sh all`)
- Tarballs do Stage1 em `${SRCDIR}` (padrão: `/mnt/rootfs/sources`)
- Execução como `root` (ou usuário com permissões para escrever em `ROOTFS`)

### Execução

```sh
cd rootfs-toolchain-musl
ROOTFS=/mnt/rootfs JOBS=4 ./scripts/stage1.sh all
```

### Retomada e logs

- Markers: `ROOTFS/state-stage1/*.ok`
- Logs: `ROOTFS/logs-stage1/*.log`

---

## chroot seguro e execução sem permanência

O script `scripts/chroot-run.sh` prepara um ambiente mínimo de chroot, executa um comando e desmonta tudo ao final. Ele evita que você “fique preso” no chroot e reduz risco de deixar mounts pendurados.

### O que ele monta

- `/proc` (proc)
- `/sys` (sysfs)
- `/dev` (bind)
- `/dev/pts` (devpts)

### Bind-mounts opcionais

Você pode mapear diretórios do host para dentro do chroot, em modo leitura-escrita ou somente-leitura.

- `BIND_MOUNTS="/host/path:/inside/chroot ..."`
- `BIND_RO_MOUNTS="/host/path:/inside/chroot ..."`

Exemplo:

```sh
ROOTFS=/mnt/rootfs \
BIND_MOUNTS="/mnt/rootfs/sources:/sources /mnt/rootfs/build-stage2:/build" \
./scripts/chroot-run.sh run 'ls -la /sources'
```

### Exemplos de uso

```sh
# Executar um comando e sair
ROOTFS=/mnt/rootfs ./scripts/chroot-run.sh run 'uname -a'

# Entrar em shell interativo (desmonta ao sair)
ROOTFS=/mnt/rootfs ./scripts/chroot-run.sh shell
```

---

## Stage2 (tooling para construir o Stage3 com tranquilidade)

O Stage2 instala um conjunto de ferramentas suficiente para construir o Stage3 (sistema final) de forma robusta, mantendo um perfil enxuto (sem “mundo inteiro”).

### O que o Stage2 instala

- Toolchain nativo em `/usr`: `binutils` + `gcc` (C/C++)
- Base de userland para builds e manutenção:
  - `coreutils`, `tar`, `util-linux` (configurado para evitar componentes de login/su/setuid)
- Ferramentas de build amplamente necessárias:
  - `bison`, `flex`, `texinfo`, `gperf`, `perl`

### Pré-requisitos

- Stage1 concluído
- Tarballs adicionais em `${SRCDIR}` (padrão `/mnt/rootfs/sources`)
- Permissão para `mount/chroot` (normalmente: rodar como root)

### Execução

```sh
cd rootfs-toolchain-musl
ROOTFS=/mnt/rootfs JOBS=4 ./scripts/stage2.sh all
```

### Retomada e logs

- Markers: `ROOTFS/state-stage2/*.ok`
- Logs: `ROOTFS/logs-stage2/*.log`

### Verificação

A etapa final compila e executa um binário simples dentro do chroot para validar que o `gcc` nativo e o runtime musl estão operacionais.


## Stage3 (sistema final)

O Stage3 instala um sistema final compacto (mas completo) com:

- **init**: runit
- **base system**: layout, configs, eudev, kmod, e2fsprogs, ssl
- **network**: iproute2 + dhcpcd
- **wifi**: iw + wpa_supplicant (opcional)
- **kernel**: Linux (build + install)
- **boot**: GRUB UEFI (opcional; requer ESP montada)
- **apps**: vim + w3m
- **health check**: revdep (verificação de bibliotecas faltando)

### Tarballs adicionais esperados

O Stage3 procura em `SRCDIR` (padrão: `/mnt/rootfs/sources`) por tarballs com os nomes padrão `nome-versao.tar.*`.
As versões padrão são configuráveis no topo de `scripts/stage3.sh`.

### Executar Stage3

```sh
cd rootfs-toolchain-musl
ROOTFS=/mnt/rootfs JOBS=4 ./scripts/stage3.sh all
```

Retomada:
- markers: `/mnt/rootfs/state-stage3/*.ok`
- logs: `/mnt/rootfs/logs-stage3/*.log`

### GRUB UEFI

Para instalar o GRUB no ESP, você deve:

1. Montar sua partição EFI dentro do rootfs, por padrão em `ROOTFS/boot/efi`.
2. Definir `GRUB_DISK` (ex.: `/dev/nvme0n1` ou `/dev/sda`).

Exemplo:

```sh
mount /dev/sda1 /mnt/rootfs/boot/efi
ROOTFS=/mnt/rootfs GRUB_DISK=/dev/sda ./scripts/stage3.sh grub
```

Se `GRUB_DISK` estiver vazio, o Stage3 **apenas** compila e instala os binários do GRUB em `/usr`, e gera um `grub.cfg` mínimo em `/boot/grub/grub.cfg`.

### Kernel

Por padrão o kernel usa `defconfig`. Para usar um `.config` próprio, defina `KERNEL_CONFIG_FILE` apontando para um arquivo no host e faça bind-mount dele (veja `scripts/chroot-run.sh`).

---

## Build completo em um comando

O script `scripts/system-build.sh` executa Stage0→Stage3 com um UI simples (contadores e progresso), além de logs em cada etapa:

```sh
cd rootfs-toolchain-musl
ROOTFS=/mnt/rootfs JOBS=4 ./scripts/system-build.sh
```

Você pode desativar etapas:

```sh
RUN_STAGE3=0 ./scripts/system-build.sh
```

---

## revdep (verificação de linkage)

O `scripts/revdep.sh` faz um scan no rootfs para encontrar binários/ELFs com dependências `.so` ausentes.

Exemplo:

```sh
# Dentro do chroot (recomendado)
ROOTFS=/mnt/rootfs ./scripts/chroot-run.sh run '/usr/sbin/revdep.sh --root / --no-color'
```

### Licença do revdep

O arquivo `scripts/revdep.sh` é **GPL-3.0** (derivado do script enviado pelo autor). O restante do projeto permanece sob **MIT**.
Veja `LICENSE` e `LICENSES/GPL-3.0.txt`.


## Stage3 (sistema base final, sem desktop)

O `scripts/stage3.sh` instala e configura um sistema base completo (ainda **sem desktop**; isso fica para um Stage4).

Inclui:
- **runit** como init/supervisor
- Base do sistema: layout + configs, `zlib`, `openssl`, `e2fsprogs`, `kmod`, `eudev`
- Rede: `iproute2` + `dhcpcd`
- Essenciais adicionais (para um Stage4 “tranquilo” sem bloat):
  - `cpio` (necessário para initramfs)
  - `procps-ng` (`ps`, `top`)
  - `psmisc` (`killall`, `pstree`)
  - `iputils` (`ping`, `tracepath`)
  - `kbd` (`loadkeys`, `setfont`)
- Wi-Fi (opcional): `libnl`, `iw`, `wpa_supplicant`
- Áudio (opcional): `alsa-lib`, `alsa-utils`
- Apps de terminal: `vim`, `w3m`
- Kernel (build+install)
- GRUB UEFI (opcional)
- `revdep.sh` (scan de linkage)

### Rodar Stage3

```sh
ROOTFS=/mnt/rootfs JOBS=4 ./scripts/stage3.sh all
```

### Rodar uma etapa específica

```sh
./scripts/stage3.sh list
./scripts/stage3.sh step 45_essentials
```

### Rastreamento de installs e remoção por manifest

O Stage3 pode registrar manifests dos arquivos adicionados por cada pacote (útil para remover depois sem gerenciador de pacotes):

- `TRACK_INSTALLS=1` (padrão) grava manifests em:
  - `/mnt/rootfs/var/lib/stage-build/manifests/<pkg>.list`

Para remover um pacote com manifest:

```sh
ROOTFS=/mnt/rootfs ./scripts/system-build.sh remove-pkg procps-ng
```

## initramfs (opcional, sem dracut)

O `scripts/initramfs.sh` gera um initramfs `cpio` (opcionalmente comprimido) usando binários do seu rootfs e copiando dependências ELF via `readelf`.

Exemplo (após kernel instalado):

```sh
ROOTFS=/mnt/rootfs \
KVER=6.x.y \
ROOTDEV=/dev/sda2 \
ROOTFS_TYPE=ext4 \
INITRAMFS_NAME=initramfs.cpio.gz \
INITRAMFS_COMPRESS=gzip \
./scripts/initramfs.sh build
```

Integração no Stage3:
- `ENABLE_INITRAMFS=1` adiciona a etapa `85_initramfs` após `80_kernel`.

## system-build.sh (orquestrador)

Comandos principais:

```sh
# pipeline completo
ROOTFS=/mnt/rootfs JOBS=4 ./scripts/system-build.sh build

# ver status
ROOTFS=/mnt/rootfs ./scripts/system-build.sh status

# limpeza segura de builds
ROOTFS=/mnt/rootfs ./scripts/system-build.sh clean-builddirs

# remover toolchain temporária (/tools)
ROOTFS=/mnt/rootfs ./scripts/system-build.sh remove-toolchain

# remover pacote por manifest (quando existir)
ROOTFS=/mnt/rootfs ./scripts/system-build.sh remove-pkg cpio
```

Variáveis úteis:
- `PIPELINE="stage0 stage1 stage2 stage3"`
- `PRUNE_BUILDDIRS=1`
- `PRUNE_TOOLCHAIN=1`

## revdep.sh (evoluído)

O `scripts/revdep.sh` agora:
- constrói um índice cacheado de bibliotecas em `ROOT/var/cache/revdep/`
- suporta:
  - `--root`
  - `--paths`
  - `--all`
  - `--strict` + `--expect-interp`
  - `--ignore-file`, `--ignore-lib`
  - `--format plain|tsv`
- retorna exit code `2` se encontrar problemas (útil em CI/Stage3).

Exemplo:

```sh
./scripts/revdep.sh --root /mnt/rootfs --strict
```


## Stage4 (dev tooling + Wayland/Sway stack)

O Stage4 adiciona tooling moderno e uma stack gráfica **Wayland funcional** com **Sway (wlroots)** e utilitários essenciais.
Ele é modular: habilite/desabilite componentes via variáveis no topo do `scripts/stage4.sh`.

### O que instala (por padrão)

Dev tooling:
- curl, wget, git
- Python 3, CMake, Meson, Ninja, ccache
- LLVM/Clang

Wayland/Wlroots base:
- wayland, wayland-protocols
- libdrm, libxkbcommon, xkeyboard-config, pixman
- seatd, libevdev, mtdev, libinput
- wlroots
- Mesa (EGL/GBM/GL) com drivers configuráveis (Gallium + DRI)

Sway + utilitários Wayland:
- sway (+ opcionais: swaybg/swayidle/swaylock se você fornecer os tarballs)
- grim, slurp, wl-clipboard, wayland-utils (se você fornecer os tarballs)
- foot (terminal Wayland)

Sessão e integração (screen sharing / áudio moderno):
- PipeWire (bibliotecas + daemon), WirePlumber (policy/session manager)
- xdg-desktop-portal + xdg-desktop-portal-wlr (backend p/ wlroots)
- script helper `/usr/bin/wayland-session-init` para iniciar serviços de sessão

Sistema/serviços necessários para UX:
- dbus (service runit criado em `/etc/sv/dbus` e linkado em `/etc/service/dbus`)

Fontes (por padrão, se você fornecer os tarballs):
- DejaVu, Noto (incl. emoji opcional), JetBrains Mono, NerdFonts (tarball preparado), Font Awesome
- Substitutos livres para nomes proprietários comuns:
  - "Times New Roman" → Liberation Serif / TeX Gyre Termes
  - "Courier New" → Liberation Mono / DejaVu Sans Mono

Multimídia:
- FFmpeg (base funcional; codecs externos pesados são intencionalmente evitados)

### Variáveis importantes

- `ENABLE_SWAY=1|0`
- `ENABLE_WAYLAND_UTILS=1|0`
- `ENABLE_FFMPEG=1|0`
- `ENABLE_DBUS=1|0`
- `ENABLE_FONTS_EXTRA=1|0` (instala conjuntos de fontes, exige tarballs)
- `ENABLE_PIPEWIRE=1|0` / `ENABLE_WIREPLUMBER=1|0`
- `ENABLE_XDG_PORTAL=1|0` / `ENABLE_XDG_PORTAL_WLR=1|0`
- `ENABLE_XWAYLAND=1|0` (pesado; desligado por padrão)
- `ENABLE_PALEMOON=1|0` (**experimental em musl**, ver abaixo)

### Tarballs extras esperados (Stage4+)

Além dos tarballs já citados nas seções anteriores, para PipeWire/Portais e fontes você deve adicionar em `SRCDIR` (por padrão `/mnt/rootfs/sources`) arquivos com nomes compatíveis com:

- `pipewire-${PIPEWIRE_VER}.tar.*`
- `wireplumber-${WIREPLUMBER_VER}.tar.*`
- `xdg-desktop-portal-${XDG_DESKTOP_PORTAL_VER}.tar.*`
- `xdg-desktop-portal-wlr-${XDG_DESKTOP_PORTAL_WLR_VER}.tar.*`
- `gstreamer-${GSTREAMER_VER}.tar.*`
- `gst-plugins-base-${GST_PLUGINS_BASE_VER}.tar.*`
- `json-glib-${JSON_GLIB_VER}.tar.*`
- `libxml2-${LIBXML2_VER}.tar.*`
- `fuse3-${FUSE3_VER}.tar.*` (ou `fuse-${FUSE3_VER}.tar.*`, conforme seu tarball)
- `libgudev-${LIBGUDEV_VER}.tar.*`

Fontes (opcional, mas recomendado):

- `dejavu-fonts-ttf-${DEJAVU_FONTS_VER}.tar.*`
- `noto-fonts-${NOTO_FONTS_VER}.tar.*`
- `noto-emoji-${NOTO_EMOJI_VER}.tar.*` (opcional)
- `jetbrains-mono-${JETBRAINS_MONO_VER}.tar.*`
- `font-awesome-${FONT_AWESOME_VER}.tar.*`
- `nerdfonts-${NERDFONTS_VER}.tar.*`
- `liberation-fonts-${LIBERATION_FONTS_VER}.tar.*`
- `tex-gyre-${TEXGYRE_FONTS_VER}.tar.*`

Observação: vários projetos distribuem fontes como `.zip`. Para evitar dependência de `unzip`, repack esses zips para `tar.*` antes de colocar em `SRCDIR`.

Mesa/Drivers:
- `MESA_GALLIUM="iris,radeonsi,nouveau,virgl,svga,llvmpipe"` (default)
- `MESA_DRI="i965"` (default)
- `MESA_PLATFORMS="wayland"` (default; se você habilitar Xwayland no futuro, use `wayland,x11`)
- `MESA_VULKAN=""` (default vazio)

### Como rodar

```sh
ROOTFS=/mnt/rootfs JOBS=4 ./scripts/stage4.sh all
```

Desligar LLVM e Mesa:
```sh
ROOTFS=/mnt/rootfs ENABLE_LLVM=0 ENABLE_MESA=0 ./scripts/stage4.sh all
```

Ajustar drivers do Mesa:
```sh
ROOTFS=/mnt/rootfs MESA_GALLIUM="iris,radeonsi,llvmpipe" MESA_DRI="i965" ./scripts/stage4.sh all
```

### Sway: primeiro boot (dica prática)

Depois que o sistema estiver bootando com runit, você pode iniciar o compositor:
```sh
sway
```

Um `config` mínimo é instalado em `/etc/sway/config` (se não existir) e o terminal padrão é `foot`.

Para um desktop completo (áudio + screen sharing no Wayland), o `/etc/sway/config` chama:

- `wayland-session-init` (se presente)

Esse helper inicia (uma vez por login) pipewire/wireplumber e xdg-portals no contexto do usuário.

Observação: em sistemas sem logind, `wayland-session-init` cria um `XDG_RUNTIME_DIR` por usuário em `/run/user/<uid>` (ou cai para `/tmp`).

### Pale Moon (observação importante)

Upstream do Pale Moon requer **Python 2.7 + autoconf 2.13 + yasm** e não suporta musl oficialmente.
Por isso, `ENABLE_PALEMOON=1` está **desligado** e a etapa aborta com uma mensagem orientando a usar patches/ambiente específico.

### Retomada / logs

- Markers: `/mnt/rootfs/state-stage4/*.done`
- Logs: `/mnt/rootfs/logs-stage4/*.log`
- Manifests (remoção): `/mnt/rootfs/var/lib/stage-build/manifests/*.list`

## system-build.sh (orquestração)

O `scripts/system-build.sh` agora suporta Stage0..Stage4 e também empacotamento e ISO:

```sh
ROOTFS=/mnt/rootfs JOBS=4 ./scripts/system-build.sh build
```

Ver status:
```sh
ROOTFS=/mnt/rootfs ./scripts/system-build.sh status
```

Checagem real do host (comandos necessários para orquestrar):
```sh
./scripts/system-build.sh doctor
```

Limpar build dirs:
```sh
ROOTFS=/mnt/rootfs ./scripts/system-build.sh clean-builddirs all
```

Remover toolchain temporária:
```sh
ROOTFS=/mnt/rootfs ./scripts/system-build.sh remove-toolchain
```

Remover um pacote instalado via manifest:
```sh
ROOTFS=/mnt/rootfs ./scripts/system-build.sh remove-pkg curl
```

## build.sh (Stage0) - comandos novos

Além de `all/clean/...`, o Stage0 agora tem:

```sh
./build.sh check-host
./build.sh env
```

## pack.sh (empacotar por stage/perfil)

Gera tarballs do rootfs (base/full/por stage).

```sh
ROOTFS=/mnt/rootfs OUTDIR=./artifacts ./scripts/pack.sh base
ROOTFS=/mnt/rootfs OUTDIR=./artifacts ./scripts/pack.sh full
ROOTFS=/mnt/rootfs OUTDIR=./artifacts ./scripts/pack.sh stage3
```

`base` exclui: `sources/`, `build-*`, `logs-*`, `state-*`, `tools/`.

## mkiso.sh (ISO opcional)

Cria um ISO bootável (se o host tiver as ferramentas necessárias).

Requisitos no host:
- `grub-mkrescue`
- `xorriso`
- `mtools` (ou `mformat`)

Exemplo:
```sh
ROOTFS=/mnt/rootfs ISO_OUT=./artifacts/system.iso ./scripts/mkiso.sh build
```

Atenção:
- você precisa ter `vmlinuz` e `initramfs` em `$ROOTFS/boot/`.
- ajuste `CMDLINE` (root=) no ambiente se necessário.

