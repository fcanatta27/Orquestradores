#!/bin/sh
# rootfs-toolchain-musl
# Build a minimal temporary toolchain (binutils + gcc + musl + linux headers)
# for x86_64-linux-musl into /mnt/rootfs/tools (by default).
#
# POSIX /bin/sh only. No bashisms.

set -eu

###############################################################################
# Configuration (edit here or override via environment)
###############################################################################

# Root of your target filesystem (mount point).
ROOTFS=${ROOTFS:-/mnt/rootfs}

# Installation prefix for the temporary toolchain.
TOOLS=${TOOLS:-$ROOTFS/tools}

# Toolchain target triple (musl).
TARGET=${TARGET:-x86_64-linux-musl}

# Build / source directories (kept under ROOTFS by default).
SRCDIR=${SRCDIR:-$ROOTFS/sources}
BUILDDIR=${BUILDDIR:-$ROOTFS/build-toolchain}
LOGDIR=${LOGDIR:-$BUILDDIR/logs}
STATEDIR=${STATEDIR:-$BUILDDIR/state}

# Sysroot for the target (headers+libc live here).
SYSROOT=${SYSROOT:-$TOOLS/$TARGET}

# Make parallelism (keep conservative by default; override if you want).
JOBS=${JOBS:-1}

# Common environment hardening. Keep conservative for bootstrap reliability.
# (Aggressive hardening can break early compiler/libc builds.)
CFLAGS_HOST=${CFLAGS_HOST:-"-O2 -pipe"}
CXXFLAGS_HOST=${CXXFLAGS_HOST:-"$CFLAGS_HOST"}
LDFLAGS_HOST=${LDFLAGS_HOST:-""}

# Versions (as of 2026-01-01)
BINUTILS_VER=${BINUTILS_VER:-2.45.1}
GCC_VER=${GCC_VER:-15.2.0}
LINUX_VER=${LINUX_VER:-6.18.2}
MUSL_VER=${MUSL_VER:-1.2.5}

GMP_VER=${GMP_VER:-6.3.0}
MPFR_VER=${MPFR_VER:-4.2.2}
MPC_VER=${MPC_VER:-1.3.1}
ISL_VER=${ISL_VER:-0.27}

# Source tarball filenames (expected in $SRCDIR)
BINUTILS_TAR=${BINUTILS_TAR:-binutils-$BINUTILS_VER.tar.bz2}
GCC_TAR=${GCC_TAR:-gcc-$GCC_VER.tar.xz}
LINUX_TAR=${LINUX_TAR:-linux-$LINUX_VER.tar.xz}
MUSL_TAR=${MUSL_TAR:-musl-$MUSL_VER.tar.gz}

GMP_TAR=${GMP_TAR:-gmp-$GMP_VER.tar.xz}
MPFR_TAR=${MPFR_TAR:-mpfr-$MPFR_VER.tar.xz}
MPC_TAR=${MPC_TAR:-mpc-$MPC_VER.tar.gz}
ISL_TAR=${ISL_TAR:-isl-$ISL_VER.tar.xz}

# Optional SHA256 verification (set to "0" to disable).
VERIFY_SHA256=${VERIFY_SHA256:-1}

# Optional SHA512 verification (set to "0" to disable).
VERIFY_SHA512=${VERIFY_SHA512:-0}

# Known-good SHA256 sums (for convenience; you may override or disable).
# Note: Linux kernel tarballs are typically verified via PGP signature;
# this script does not hard-fail on missing kernel checksum.
SHA256_BINUTILS_BZ2=${SHA256_BINUTILS_BZ2:-860daddec9085cb4011279136fc8ad29eb533e9446d7524af7f517dd18f00224}
SHA256_MUSL_GZ=${SHA256_MUSL_GZ:-a9a118bbe84d8764da0ea0d28b3ab3fae8477fc7e4085d90102b8596fc7c75e4}
SHA256_GMP_XZ=${SHA256_GMP_XZ:-a3c2b80201b89e68616f4ad30bc66aee4927c3ce50e33929ca819d5c43538898}
SHA256_MPFR_XZ=${SHA256_MPFR_XZ:-b67ba0383ef7e8a8563734e2e889ef5ec3c3b898a01d00fa0a6869ad81c6ce01}
SHA256_MPC_GZ=${SHA256_MPC_GZ:-ab642492f5cf882b74aa0cb730cd410a81edcdbec895183ce930e706c1c759b8}
SHA256_ISL_XZ=${SHA256_ISL_XZ:-6d8babb59e7b672e8cb7870e874f3f7b813b6e00e6af3f8b04f7579965643d5c}

# If you provide it, GCC can be verified via sha512 (preferred by GNU).
SHA512_GCC_XZ=${SHA512_GCC_XZ:-""}

###############################################################################
# Helpers
###############################################################################

umask 022

msg() { printf '%s\n' "$*" >&2; }
die() { msg "ERROR: $*"; exit 1; }

have_cmd() { command -v "$1" >/dev/null 2>&1; }

need_cmd() {
  for c in "$@"; do
    have_cmd "$c" || die "required command not found in PATH: $c"
  done
}

ensure_dirs() {
  mkdir -p "$SRCDIR" "$BUILDDIR" "$LOGDIR" "$STATEDIR" "$TOOLS" "$SYSROOT"
}

state_done() { [ -f "$STATEDIR/$1.done" ]; }
mark_done() { : > "$STATEDIR/$1.done"; }

run_logged() {
  step=$1
  shift
  log="$LOGDIR/$step.log"
  msg "==> $step"
  msg "    log: $log"
  (
    set -eu
    "$@"
  ) >"$log" 2>&1
}

rm_rf() {
  # portable 'rm -rf' wrapper
  [ $# -ge 1 ] || return 0
  # POSIX: rm does not guarantee support for "--".
  # Also protect against paths starting with '-'.
  for p in "$@"; do
    case $p in
      -*)
        # If relative, prefix with ./ to avoid option parsing.
        case $p in
          /*) rm -rf "$p" ;;
          *) rm -rf "./$p" ;;
        esac
        ;;
      *)
        rm -rf "$p"
        ;;
    esac
  done
}

extract_tarball() {
  tarball=$1
  dest=$2
  [ -f "$tarball" ] || die "missing tarball: $tarball"
  mkdir -p "$dest"
  # Prefer explicit decompression for portability.
  # Note: POSIX sh lacks pipefail; avoid pipelines so decompressor errors are not hidden.
  tmp_tar="$BUILDDIR/work/.extract.tmp.tar"
  rm_rf "$tmp_tar"
  case $tarball in
    *.tar.gz|*.tgz)
      have_cmd gzip || die "gzip not found (needed to extract: $tarball)"
      gzip -dc "$tarball" >"$tmp_tar"
      tar -xf "$tmp_tar" -C "$dest"
      ;;
    *.tar.bz2|*.tbz2)
      have_cmd bzip2 || die "bzip2 not found (needed to extract: $tarball)"
      bzip2 -dc "$tarball" >"$tmp_tar"
      tar -xf "$tmp_tar" -C "$dest"
      ;;
    *.tar.xz|*.txz)
      have_cmd xz || die "xz not found (needed to extract: $tarball)"
      xz -dc "$tarball" >"$tmp_tar"
      tar -xf "$tmp_tar" -C "$dest"
      ;;
    *.tar)
      tar -xf "$tarball" -C "$dest"
      ;;
    *)
      # Fallback: try tar's auto-detection.
      tar -xf "$tarball" -C "$dest"
      ;;
  esac
  rm_rf "$tmp_tar"
}

verify_sha256_one() {
  name=$1
  file=$2
  expected=$3

  [ "$VERIFY_SHA256" -eq 1 ] || return 0
  [ -n "$expected" ] || return 0
  have_cmd sha256sum || { msg "WARN: sha256sum not found; skipping checksums"; return 0; }

  got=$(sha256sum "$file" | awk '{print $1}')
  if [ "$got" != "$expected" ]; then
    die "sha256 mismatch for $name: expected $expected, got $got"
  fi
}

verify_sha512_one() {
  name=$1
  file=$2
  expected=$3

  [ "$VERIFY_SHA512" -eq 1 ] || return 0
  [ -n "$expected" ] || return 0
  have_cmd sha512sum || { msg "WARN: sha512sum not found; skipping sha512 checks"; return 0; }

  got=$(sha512sum "$file" | awk '{print $1}')
  if [ "$got" != "$expected" ]; then
    die "sha512 mismatch for $name: expected $expected, got $got"
  fi
}

verify_sources() {
  verify_sha256_one "binutils" "$SRCDIR/$BINUTILS_TAR" "$SHA256_BINUTILS_BZ2"
  verify_sha256_one "musl" "$SRCDIR/$MUSL_TAR" "$SHA256_MUSL_GZ"
  verify_sha256_one "gmp" "$SRCDIR/$GMP_TAR" "$SHA256_GMP_XZ"
  verify_sha256_one "mpfr" "$SRCDIR/$MPFR_TAR" "$SHA256_MPFR_XZ"
  verify_sha256_one "mpc" "$SRCDIR/$MPC_TAR" "$SHA256_MPC_GZ"
  verify_sha256_one "isl" "$SRCDIR/$ISL_TAR" "$SHA256_ISL_XZ"
  verify_sha512_one "gcc" "$SRCDIR/$GCC_TAR" "$SHA512_GCC_XZ"
  # Linux kernel: recommend PGP verification; checksum not enforced here.
}

clean_buildtree() {
  rm_rf "$BUILDDIR/work"
  mkdir -p "$BUILDDIR/work"
}

enter_work() { cd "$BUILDDIR/work"; }

set_tool_env() {
  # Prefer the newly built tools.
  PATH="$TOOLS/bin:$PATH"
  export PATH

  # Keep locale deterministic for builds.
  LC_ALL=C
  export LC_ALL

  # Avoid host contamination through pkg-config etc.
  # (Users can override if they know what they're doing.)
  unset PKG_CONFIG_PATH 2>/dev/null || :
  unset PKG_CONFIG_LIBDIR 2>/dev/null || :
  unset PKG_CONFIG_SYSROOT_DIR 2>/dev/null || :

  # Conservative build flags.
  CFLAGS="$CFLAGS_HOST"
  CXXFLAGS="$CXXFLAGS_HOST"
  LDFLAGS="$LDFLAGS_HOST"
  export CFLAGS CXXFLAGS LDFLAGS
}


check_host() {
  # Real host-side requirements for Stage0 toolchain build
  need_cmd sh
  need_cmd make
  need_cmd tar
  need_cmd awk
  need_cmd sed
  need_cmd grep
  need_cmd find
  need_cmd sort
  need_cmd xz || :
  need_cmd gzip || :
  need_cmd bzip2 || :
  need_cmd gcc || die "host gcc required (build toolchain bootstrap)"
  need_cmd g++ || :
  msg "Host check: OK"
}

print_env() {
  cat <<EOF
ROOTFS=$ROOTFS
TOOLS=$TOOLS
SYSROOT=$SYSROOT
TARGET=$TARGET
SRCDIR=$SRCDIR
BUILDDIR=$BUILDDIR
LOGDIR=$LOGDIR
STATEDIR=$STATEDIR
JOBS=$JOBS
EOF
}

###############################################################################
# Build steps
###############################################################################

step_00_sanity() {
  ensure_dirs
  need_cmd sh mkdir rm tar make awk sed
  need_cmd gcc g++

  for c in bzip2 xz gzip; do
    if ! have_cmd "$c"; then
      msg "WARN: decompressor not found in PATH: $c (tar may still handle it depending on implementation)"
    fi
  done

  verify_sources

  # Basic invariants.
  case "$TARGET" in
    x86_64-*-musl) : ;;
    *) die "TARGET must be a musl triple (expected x86_64-*-musl); got: $TARGET" ;;
  esac

  # Show config snapshot.
  msg "ROOTFS   = $ROOTFS"
  msg "TOOLS    = $TOOLS"
  msg "SYSROOT  = $SYSROOT"
  msg "SRCDIR   = $SRCDIR"
  msg "BUILDDIR = $BUILDDIR"
  msg "TARGET   = $TARGET"
  msg "JOBS     = $JOBS"
}

step_10_linux_headers() {
  clean_buildtree
  enter_work
  extract_tarball "$SRCDIR/$LINUX_TAR" .
  linuxdir="linux-$LINUX_VER"
  [ -d "$linuxdir" ] || die "expected directory not found after extract: $linuxdir"

  cd "$linuxdir"
  # Install kernel headers to sysroot.
  # headers_install is the stable interface for userspace headers.
  make mrproper
  # Install into sysroot under /usr, matching GCC's default header search.
  make headers_install ARCH=x86_64 INSTALL_HDR_PATH="$SYSROOT/usr"

  # Kernel headers should live under $SYSROOT/usr/include.
  [ -f "$SYSROOT/usr/include/linux/version.h" ] || msg "WARN: did not find linux/version.h (this can be OK on newer kernels)"
}

step_20_binutils() {
  clean_buildtree
  enter_work
  extract_tarball "$SRCDIR/$BINUTILS_TAR" .
  src="binutils-$BINUTILS_VER"
  [ -d "$src" ] || die "expected directory not found after extract: $src"

  mkdir -p build-binutils
  cd build-binutils

  "../$src/configure" \
    --prefix="$TOOLS" \
    --target="$TARGET" \
    --with-sysroot="$SYSROOT" \
    --disable-nls \
    --disable-werror \
    --enable-deterministic-archives

  make -j "$JOBS"
  make install

  # Minimal smoke test
  [ -x "$TOOLS/bin/$TARGET-ld" ] || die "binutils install looks broken: missing $TOOLS/bin/$TARGET-ld"
}

inject_gcc_prereqs() {
  gccsrc=$1

  # Extract and move prerequisite libraries into GCC source tree.
  # GCC accepts in-tree dirs named: gmp mpfr mpc isl
  rm_rf "$gccsrc/gmp" "$gccsrc/mpfr" "$gccsrc/mpc" "$gccsrc/isl"

  tmp="$BUILDDIR/work/_gcc_prereqs"
  rm_rf "$tmp"
  mkdir -p "$tmp"
  extract_tarball "$SRCDIR/$GMP_TAR" "$tmp"
  extract_tarball "$SRCDIR/$MPFR_TAR" "$tmp"
  extract_tarball "$SRCDIR/$MPC_TAR" "$tmp"
  extract_tarball "$SRCDIR/$ISL_TAR" "$tmp"

  mv "$tmp/gmp-$GMP_VER" "$gccsrc/gmp"
  mv "$tmp/mpfr-$MPFR_VER" "$gccsrc/mpfr"
  mv "$tmp/mpc-$MPC_VER" "$gccsrc/mpc"
  mv "$tmp/isl-$ISL_VER" "$gccsrc/isl"
  rm_rf "$tmp"
}

step_30_gcc_pass1() {
  clean_buildtree
  enter_work
  extract_tarball "$SRCDIR/$GCC_TAR" .
  src="gcc-$GCC_VER"
  [ -d "$src" ] || die "expected directory not found after extract: $src"

  inject_gcc_prereqs "$PWD/$src"

  mkdir -p build-gcc-pass1
  cd build-gcc-pass1

  "../$src/configure" \
    --prefix="$TOOLS" \
    --target="$TARGET" \
    --with-sysroot="$SYSROOT" \
    --with-native-system-header-dir=/usr/include \
    --disable-nls \
    --disable-multilib \
    --disable-shared \
    --disable-threads \
    --enable-languages=c \
    --without-headers \
    --with-newlib \
    --disable-libatomic \
    --disable-libgomp \
    --disable-libquadmath \
    --disable-libsanitizer \
    --disable-libssp \
    --disable-libvtv \
    --disable-libstdcxx-pch

  make -j "$JOBS" all-gcc
  make -j "$JOBS" all-target-libgcc
  make install-gcc
  make install-target-libgcc

  [ -x "$TOOLS/bin/$TARGET-gcc" ] || die "gcc pass1 install looks broken: missing $TOOLS/bin/$TARGET-gcc"
}

step_40_musl() {
  clean_buildtree
  enter_work
  extract_tarball "$SRCDIR/$MUSL_TAR" .
  src="musl-$MUSL_VER"
  [ -d "$src" ] || die "expected directory not found after extract: $src"

  cd "$src"

  # musl prefers CC set; CROSS_COMPILE is also supported.
  CC="$TARGET-gcc" \
  CROSS_COMPILE="$TARGET-" \
  ./configure \
    --prefix=/usr \
    --syslibdir=/lib

  make -j "$JOBS"
  DESTDIR="$SYSROOT" make install

  # Ensure dynamic loader exists in sysroot.
  [ -f "$SYSROOT/lib/ld-musl-x86_64.so.1" ] || die "musl install looks broken: missing ld-musl-x86_64.so.1 in sysroot"
}

step_50_gcc_final() {
  clean_buildtree
  enter_work
  extract_tarball "$SRCDIR/$GCC_TAR" .
  src="gcc-$GCC_VER"
  [ -d "$src" ] || die "expected directory not found after extract: $src"

  inject_gcc_prereqs "$PWD/$src"

  mkdir -p build-gcc-final
  cd build-gcc-final

  "../$src/configure" \
    --prefix="$TOOLS" \
    --target="$TARGET" \
    --with-sysroot="$SYSROOT" \
    --with-native-system-header-dir=/usr/include \
    --disable-nls \
    --disable-multilib \
    --enable-languages=c,c++ \
    --enable-shared \
    --enable-threads=posix \
    --disable-libsanitizer \
    --enable-initfini-array

  make -j "$JOBS"
  make install

  [ -x "$TOOLS/bin/$TARGET-gcc" ] || die "gcc final install looks broken: missing $TOOLS/bin/$TARGET-gcc"
  [ -x "$TOOLS/bin/$TARGET-g++" ] || die "gcc final install looks broken: missing $TOOLS/bin/$TARGET-g++"
}

step_90_verify() {
  set_tool_env

  # Verify binutils presence.
  "$TARGET-ld" --version >/dev/null 2>&1 || die "cannot execute $TARGET-ld from PATH"
  "$TARGET-as" --version >/dev/null 2>&1 || die "cannot execute $TARGET-as from PATH"

  # Verify gcc presence.
  "$TARGET-gcc" --version >/dev/null 2>&1 || die "cannot execute $TARGET-gcc from PATH"

  # Verify sysroot wiring.
  sysroot=$("$TARGET-gcc" -print-sysroot 2>/dev/null || :)
  if [ -n "$sysroot" ] && [ "$sysroot" != "$SYSROOT" ]; then
    msg "WARN: gcc -print-sysroot returned: $sysroot"
    msg "      expected: $SYSROOT"
  fi

  # Build and run a static test binary (should run on x86_64 host).
  tdir="$BUILDDIR/work/verify"
  rm_rf "$tdir"
  mkdir -p "$tdir"
  cat >"$tdir/hello.c" <<'EOF'
#include <stdio.h>
int main(void) {
  puts("toolchain-ok");
  return 0;
}
EOF

  ( cd "$tdir" && "$TARGET-gcc" -static -O2 -pipe hello.c -o hello )
  [ -x "$tdir/hello" ] || die "failed to produce test binary"

  # Attempt to execute. If the host isn't x86_64 Linux, this will fail; keep it informative.
  if "$tdir/hello" >/dev/null 2>&1; then
    out=$("$tdir/hello" 2>/dev/null || :)
    [ "$out" = "toolchain-ok" ] || die "unexpected output from test binary"
  else
    msg "WARN: could not execute test binary on this host. If you are cross-building, this can be expected."
  fi

  # Verify libc headers appear usable.
  echo '#include <stdlib.h>' | "$TARGET-gcc" -E - >/dev/null 2>&1 || die "preprocessor failed with musl headers"

  msg "SUCCESS: toolchain appears functional for stage1 bootstrapping."
}

###############################################################################
# Orchestration (resumable)
###############################################################################

run_step() {
  id=$1
  fn=$2

  if state_done "$id"; then
    msg "==> skip $id (already done)"
    return 0
  fi

  set_tool_env
  run_logged "$id" "$fn"
  mark_done "$id"
}

usage() {
  cat <<EOF
Usage:
  $0 [command]

Commands:
  all       Build complete temporary toolchain and run verification (default)
  verify    Run verification only (does not rebuild)
  clean     Remove build directory ($BUILDDIR) only (does NOT remove $TOOLS)
  reset     Remove build directory AND state markers (does NOT remove $TOOLS)
  help      Show this help

Environment overrides (examples):
  ROOTFS=/mnt/rootfs TOOLS=/mnt/rootfs/tools JOBS=4 $0 all
  VERIFY_SHA256=0 $0 all
EOF
}

cmd=${1:-all}

case "$cmd" in
  help|-h|--help) usage; exit 0 ;;
  check-host)
    check_host
    exit 0
    ;;
  env)
    print_env
    exit 0
    ;;
  clean)
    rm_rf "$BUILDDIR"
    msg "Removed build directory: $BUILDDIR"
    exit 0
    ;;
  reset)
    rm_rf "$BUILDDIR"
    mkdir -p "$BUILDDIR"
    msg "Removed build directory and state: $BUILDDIR"
    exit 0
    ;;
  verify)
    ensure_dirs
    set_tool_env
    step_90_verify
    exit 0
    ;;
  all)
    run_step "00_sanity" step_00_sanity
    run_step "10_linux_headers" step_10_linux_headers
    run_step "20_binutils" step_20_binutils
    run_step "30_gcc_pass1" step_30_gcc_pass1
    run_step "40_musl" step_40_musl
    run_step "50_gcc_final" step_50_gcc_final
    run_step "90_verify" step_90_verify
    ;;
  *)
    usage
    die "unknown command: $cmd"
    ;;
esac
