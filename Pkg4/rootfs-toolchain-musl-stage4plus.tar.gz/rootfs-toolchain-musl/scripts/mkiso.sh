#!/bin/sh
# mkiso.sh - Create a bootable ISO (optional) from an already built ROOTFS.
# POSIX /bin/sh only.
#
# This script is intentionally conservative: it only runs if the required host
# tools exist. It does not attempt to partition disks.
#
# Requirements on host:
#   - grub-mkrescue
#   - xorriso (often used by grub-mkrescue)
#   - mtools (often needed by grub-mkrescue for EFI image)
#
# Example:
#   ROOTFS=/mnt/rootfs ISO_OUT=./artifacts/system.iso ./scripts/mkiso.sh build

set -eu

ROOTFS=${ROOTFS:-/mnt/rootfs}
ISO_OUT=${ISO_OUT:-./artifacts/rootfs.iso}
WORKDIR=${WORKDIR:-./artifacts/.iso-work}
LABEL=${LABEL:-ROOTFSMUSL}

KERNEL_PATH=${KERNEL_PATH:-$ROOTFS/boot/vmlinuz}
INITRAMFS_PATH=${INITRAMFS_PATH:-$ROOTFS/boot/initramfs.cpio.gz}

# Kernel cmdline (adjust ROOT=)
CMDLINE=${CMDLINE:-"root=/dev/sda2 rw quiet"}

msg(){ printf '%s
' "$*" >&2; }
die(){ msg "ERROR: $*"; exit 1; }
need(){ command -v "$1" >/dev/null 2>&1 || die "missing host tool: $1"; }

need grub-mkrescue
need xorriso
need mformat || need mtools  # some distros provide mformat
need tar

[ -f "$KERNEL_PATH" ] || die "Kernel not found: $KERNEL_PATH"
[ -f "$INITRAMFS_PATH" ] || die "Initramfs not found: $INITRAMFS_PATH"

rm -rf "$WORKDIR"
mkdir -p "$WORKDIR/iso/boot/grub"
mkdir -p "$(dirname "$ISO_OUT")"

cp -f "$KERNEL_PATH" "$WORKDIR/iso/boot/vmlinuz"
cp -f "$INITRAMFS_PATH" "$WORKDIR/iso/boot/initramfs"

cat >"$WORKDIR/iso/boot/grub/grub.cfg" <<EOF
set default=0
set timeout=5

menuentry "rootfs-musl" {
  linux /boot/vmlinuz $CMDLINE
  initrd /boot/initramfs
}
EOF

grub-mkrescue -o "$ISO_OUT" -volid "$LABEL" "$WORKDIR/iso" >/dev/null 2>&1 || die "grub-mkrescue failed"

msg "Wrote ISO: $ISO_OUT"
