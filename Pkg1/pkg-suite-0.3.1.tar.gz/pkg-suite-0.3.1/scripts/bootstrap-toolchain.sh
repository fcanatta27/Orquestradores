#!/bin/sh
# bootstrap-toolchain.sh - cria cross-toolchain temporária (stage1/stage2) usando pkg-build + pkg

set -eu

die() { printf 'bootstrap: error: %s\n' "$*" >&2; exit 1; }
msg() { printf '%s\n' "$*" >&2; }

WORKSPACE="$(pwd)"
SYSROOT="/mnt/rootfs"
TOOLS="/mnt/rootfs/tools"
TARGET=""
HOST=""
JOBS=""
RECIPES=""
REPO=""
BIN_DIR=""

usage() {
  cat <<'EOF'
bootstrap-toolchain.sh - cria cross-toolchain temporária com musl em /mnt/rootfs/tools

USO:
  sudo bootstrap-toolchain.sh [opções] {prepare|stage1|stage2|all|status}

OPÇÕES:
  --workspace DIR     workspace (default: diretório atual)
  --sysroot PATH      sysroot alvo (default: /mnt/rootfs)
  --tools PATH        tools no sysroot (default: /mnt/rootfs/tools)
  --target TRIPLE     target triple (ex: x86_64-linux-musl) [obrigatório]
  --host TRIPLE       host triple (default: gcc -dumpmachine)
  -j N                paralelismo (default: nproc ou 1)
  --recipes DIR       diretório recipes (default: $WORKSPACE/recipes)
  --repo DIR          diretório repo (default: $WORKSPACE/repo)
  --bindir DIR        diretório com pkg/pkg-build (default: $WORKSPACE/bin)

ESTÁGIOS:
  prepare => cria diretórios mínimos no sysroot
  stage1  => linux-headers, binutils, gcc-pass1
  stage2  => musl, gcc-pass2
  all     => stage1 + stage2
  status  => lista pacotes instalados no sysroot

EXEMPLO:
  sudo ./scripts/bootstrap-toolchain.sh --workspace $(pwd) --target x86_64-linux-musl all
EOF
}

detect_jobs() { command -v nproc >/dev/null 2>&1 && nproc || echo 1; }
detect_host() { command -v gcc >/dev/null 2>&1 && gcc -dumpmachine 2>/dev/null || true; }

prepare_sysroot() {
  # diretórios mínimos para toolchain temporária
  mkdir -p "$SYSROOT" "$TOOLS" "$SYSROOT/usr" "$SYSROOT/lib" "$SYSROOT/usr/lib" "$SYSROOT/usr/include"
}


is_installed() { [ -d "$SYSROOT/var/lib/pkg/installed/$1" ]; }

install_if_missing() {
  p="$1"
  if is_installed "$p"; then
    msg "ok (já instalado): $p"
    return 0
  fi
  msg "instalando no sysroot: $p"
  "$BIN_DIR/pkg" --root "$SYSROOT" install "$p"
}

ensure_repo_configured() {
  "$BIN_DIR/pkg" --root "$SYSROOT" init >/dev/null 2>&1 || true
  conf="$SYSROOT/etc/pkg/repos.conf"
  mkdir -p "$(dirname "$conf")"
  touch "$conf"
  if ! awk -v n="core" '($1==n){found=1} END{exit found?0:1}' "$conf"; then
    "$BIN_DIR/pkg" --root "$SYSROOT" repo add core "$REPO"
  fi
}

build_and_publish() {
  stage="$1"; shift 1
  msg "=== BUILD ($stage) ==="
  "$BIN_DIR/pkg-build" --workspace "$WORKSPACE" --recipes "$RECIPES" --repo "$REPO" \
    --sysroot "$SYSROOT" --tools "$TOOLS" --target "$TARGET" \
    ${HOST:+--host "$HOST"} ${JOBS:+-j "$JOBS"} \
    build "$@"
}

status() {
  d="$SYSROOT/var/lib/pkg/installed"
  msg "SYSROOT: $SYSROOT"
  if [ -d "$d" ]; then
    ls -1 "$d" | sort || true
  else
    msg "(nenhum pacote instalado ainda)"
  fi
}

main() {
  while [ $# -gt 0 ]; do
    case "$1" in
      --workspace) WORKSPACE="${2:-}"; shift 2 ;;
      --sysroot) SYSROOT="${2:-}"; shift 2 ;;
      --tools) TOOLS="${2:-}"; shift 2 ;;
      --target) TARGET="${2:-}"; shift 2 ;;
      --host) HOST="${2:-}"; shift 2 ;;
      -j) JOBS="${2:-}"; shift 2 ;;
      --recipes) RECIPES="${2:-}"; shift 2 ;;
      --repo) REPO="${2:-}"; shift 2 ;;
      --bindir) BIN_DIR="${2:-}"; shift 2 ;;
      -h|--help|help) usage; exit 0 ;;
      --) shift; break ;;
      *) break ;;
    esac
  done

  cmd="${1:-}"; shift 1 || true
  [ -n "$cmd" ] || { usage; exit 1; }

  [ -n "$TARGET" ] || die "--target é obrigatório (ex: x86_64-linux-musl)"
  [ -n "$RECIPES" ] || RECIPES="$WORKSPACE/recipes"
  [ -n "$REPO" ] || REPO="$WORKSPACE/repo"
  [ -n "$BIN_DIR" ] || BIN_DIR="$WORKSPACE/bin"
  [ -n "$JOBS" ] || JOBS="$(detect_jobs)"
  [ -n "$HOST" ] || HOST="$(detect_host)"

  [ -x "$BIN_DIR/pkg" ] || die "pkg não encontrado: $BIN_DIR/pkg"
  [ -x "$BIN_DIR/pkg-build" ] || die "pkg-build não encontrado: $BIN_DIR/pkg-build"

  mkdir -p "$REPO"

  case "$cmd" in
    prepare)
      prepare_sysroot
      ensure_repo_configured
      msg "sysroot preparado"
      status
      exit 0
      ;;
    status) status; exit 0 ;;
    stage1)
      build_and_publish stage1 linux-headers binutils gcc-pass1
      ensure_repo_configured
      install_if_missing linux-headers
      install_if_missing binutils
      install_if_missing gcc-pass1
      ;;
    stage2)
      build_and_publish stage2 musl gcc-pass2
      ensure_repo_configured
      install_if_missing musl
      install_if_missing gcc-pass2
      ;;
    all)
      "$0" --workspace "$WORKSPACE" --sysroot "$SYSROOT" --tools "$TOOLS" --target "$TARGET" \
           ${HOST:+--host "$HOST"} -j "$JOBS" --recipes "$RECIPES" --repo "$REPO" --bindir "$BIN_DIR" stage1
      "$0" --workspace "$WORKSPACE" --sysroot "$SYSROOT" --tools "$TOOLS" --target "$TARGET" \
           ${HOST:+--host "$HOST"} -j "$JOBS" --recipes "$RECIPES" --repo "$REPO" --bindir "$BIN_DIR" stage2
      ;;
    *) die "estágio/comando desconhecido: $cmd" ;;
  esac

  msg "=== DONE ($cmd) ==="
  status
}

main "$@"
