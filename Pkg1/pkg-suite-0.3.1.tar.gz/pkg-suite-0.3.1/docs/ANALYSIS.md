# Análise técnica - pkg-suite 0.3.1

## Escopo
Revisão dos scripts:
- `bin/pkg`
- `bin/pkg-build`
- `scripts/bootstrap-toolchain.sh`

E das receitas sob `recipes/<categoria>/<nome>/`.

## Pontos principais (resumo)
- `pkg`: valida tar (sem path absoluto/traversal), verifica SHA256, detecta colisões, registra arquivos, remove com precisão, resolve dependências e detecta ciclos.
- `pkg-build`: resolve dependências (build_depends ∪ depends) com ordenação topológica e detecção de ciclos; suporta receitas categorizadas.
- bootstrap: automatiza stage1/stage2, evita reinstalar pacotes no sysroot e garante repo configurado.

## Observações
- `build_depends` e `depends` são apenas **nomes de receitas/pacotes do seu ecossistema**.
- Ferramentas do host (gcc/make/curl/patch) devem ser garantidas pelo ambiente.


## Correções aplicadas em 0.3.1
- `gcc-pass1` corrigido para stage1 real (somente C, `--without-headers`, `install-gcc` + `target-libgcc`).
- `binutils`, `linux-headers`, `musl` e `gcc-pass2` normalizados para builds limpos (`rm -rf $BUILDDIR`) e uso consistente de variáveis exportadas pelo `pkg-build`.
- `bootstrap-toolchain.sh` ganhou comando `prepare` para criar diretórios mínimos do sysroot antes do stage1.
