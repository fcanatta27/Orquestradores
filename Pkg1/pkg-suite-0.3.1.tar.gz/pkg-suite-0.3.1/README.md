# pkg-suite 0.3.1

## O que você recebe
- `bin/pkg`: gerenciador de pacotes binários.
- `bin/pkg-build`: builder/orquestrador de receitas (gera `repo.db` automaticamente).
- `scripts/bootstrap-toolchain.sh`: cria cross-toolchain temporária (stage1/stage2) em `/mnt/rootfs/tools`.
- `recipes/` organizadas por categoria: `recipes/<categoria>/<nome>/`.

## Estrutura
```
bin/      -> executáveis (pkg, pkg-build)
scripts/  -> automações (bootstrap-toolchain.sh)
recipes/  -> receitas por categoria
docs/     -> análise técnica
```

## Como o `pkg` funciona
### Repositórios
Um repo é um diretório contendo `repo.db` + pacotes `.tar.gz`.

Formato de linha em `repo.db`:
`name|version|rel|arch|sha256|filename|desc|depends_csv`

### Pacotes
Um pacote é um `.tar.gz` com:
- `PKGINFO` na raiz
- paths **relativos**
O `pkg` recusa:
- path absoluto
- path traversal (`..`)
- colisões (a menos que `--force`)

## Comandos do `pkg` (exemplos e combinações)
```sh
sudo ./bin/pkg --root /mnt/rootfs init
sudo ./bin/pkg --root /mnt/rootfs repo add core $(pwd)/repo
./bin/pkg --root /mnt/rootfs search gcc
./bin/pkg --root /mnt/rootfs info musl

# instalar com deps (padrão)
sudo ./bin/pkg --root /mnt/rootfs install musl

# instalar sem deps
sudo ./bin/pkg --root /mnt/rootfs --no-deps install musl

# remover com verificação de dependentes
sudo ./bin/pkg --root /mnt/rootfs remove musl

# remover em cascata
sudo ./bin/pkg --root /mnt/rootfs --cascade remove musl

# upgrade
sudo ./bin/pkg --root /mnt/rootfs upgrade
```

## Como o `pkg-build` funciona
- lê `recipes/.../<pkg>/recipe.conf`
- resolve `build_depends ∪ depends` com detecção de ciclos
- executa `build.sh` (instala em `$STAGING`)
- empacota via `pkg build`
- publica em `repo/` e atualiza `repo.db`

Exemplo:
```sh
./bin/pkg-build init
./bin/pkg-build --sysroot /mnt/rootfs --tools /mnt/rootfs/tools --target x86_64-linux-musl build gcc-pass2
```

## Bootstrap do cross-toolchain temporário (automático)
### Tudo (stage1 + stage2)
```sh
sudo ./scripts/bootstrap-toolchain.sh --workspace $(pwd) --target x86_64-linux-musl prepare
sudo ./scripts/bootstrap-toolchain.sh --workspace $(pwd) --target x86_64-linux-musl all
```

### Apenas stage1
```sh
sudo ./scripts/bootstrap-toolchain.sh --workspace $(pwd) --target x86_64-linux-musl stage1
```

### Apenas stage2
```sh
sudo ./scripts/bootstrap-toolchain.sh --workspace $(pwd) --target x86_64-linux-musl stage2
```

### Status
```sh
sudo ./scripts/bootstrap-toolchain.sh --workspace $(pwd) --target x86_64-linux-musl status
```

## Notas
- As receitas supõem um host com gcc/make/tar/curl/patch.
- `docs/ANALYSIS.md` contém detalhes técnicos do design.
