#!/bin/sh
set -eu

rm -rf "$BUILDDIR"
mkdir -p "$BUILDDIR"
cd "$BUILDDIR"

"$SRCDIR/configure"   --prefix="$TOOLS_PREFIX"   --target="$TARGET"   --with-sysroot="$SYSROOT"   --disable-nls   --disable-multilib

make -j"$JOBS"
make DESTDIR="$STAGING" install
