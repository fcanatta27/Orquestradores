#!/bin/sh
set -eu

# gcc-pass2: GCC final do toolchain temporário (/tools) usando libc/headers presentes no sysroot.

if [ -x "$SRCDIR/contrib/download_prerequisites" ]; then
  (cd "$SRCDIR" && sh contrib/download_prerequisites)
fi

rm -rf "$BUILDDIR"
mkdir -p "$BUILDDIR"
cd "$BUILDDIR"

"$SRCDIR/configure"   --prefix="$TOOLS_PREFIX"   --target="$TARGET"   --with-sysroot="$SYSROOT"   --disable-nls   --disable-multilib   --enable-languages=c,c++   --enable-threads=posix   --enable-shared   --enable-default-pie   --enable-default-ssp   --with-system-zlib

make -j"$JOBS"
make DESTDIR="$STAGING" install
