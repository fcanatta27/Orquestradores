#!/bin/sh
set -eu

# gcc-pass1: compilador bootstrap (somente C), sem libc/headers do alvo.
# Objetivo: produzir ${TARGET}-gcc funcional para compilar musl (stage2).

# Baixa pré-requisitos (gmp/mpfr/mpc/isl) se ainda não existirem no source tree.
if [ -x "$SRCDIR/contrib/download_prerequisites" ]; then
  (cd "$SRCDIR" && sh contrib/download_prerequisites)
fi

rm -rf "$BUILDDIR"
mkdir -p "$BUILDDIR"
cd "$BUILDDIR"

"$SRCDIR/configure"   --prefix="$TOOLS_PREFIX"   --target="$TARGET"   --with-sysroot="$SYSROOT"   --disable-nls   --disable-multilib   --enable-languages=c   --without-headers   --disable-shared   --disable-threads   --disable-libatomic   --disable-libgomp   --disable-libquadmath   --disable-libssp   --disable-libvtv   --disable-libstdcxx

make -j"$JOBS" all-gcc
make DESTDIR="$STAGING" install-gcc

# Recomendado: libgcc mínimo (ajuda o link do alvo mesmo antes da libc completa)
make -j"$JOBS" all-target-libgcc
make DESTDIR="$STAGING" install-target-libgcc
