#!/bin/sh
set -eu

# musl: libc do alvo. Instala em SYSROOT (/usr + /lib) via STAGING.
# Requer ${TARGET}-gcc disponível no PATH (pkg-build já prefixa $TOOLS_PATH/bin).

cd "$SRCDIR"

# Para cross, explicitar CC e AR
export CC="${TARGET}-gcc"
export AR="${TARGET}-ar"
export RANLIB="${TARGET}-ranlib"

# Configure: prefix /usr, syslibdir /lib para layout tradicional.
./configure   --prefix=/usr   --syslibdir=/lib   --target="$TARGET"

make -j"$JOBS"
make DESTDIR="$STAGING" install
