#!/bin/sh
set -eu

# linux-headers: instala headers userspace do kernel no sysroot via staging.
# Esses headers são necessários para compilar a libc (musl) e parte do toolchain.

# Mapeamento mínimo de arch (TARGET -> KARCH)
case "${TARGET%%-*}" in
  x86_64) KARCH="x86" ;;
  i?86)   KARCH="x86" ;;
  aarch64) KARCH="arm64" ;;
  arm*)   KARCH="arm" ;;
  riscv64) KARCH="riscv" ;;
  *)      KARCH="${TARGET%%-*}" ;;
esac

cd "$SRCDIR"

make mrproper

mkdir -p "$STAGING/usr"
make ARCH="$KARCH" INSTALL_HDR_PATH="$STAGING/usr" headers_install
