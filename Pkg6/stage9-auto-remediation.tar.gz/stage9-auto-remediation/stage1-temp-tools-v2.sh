#!/bin/sh
# stage1-temp-tools.sh
# Build "Stage 1" after the temporary toolchain: LFS 12.4-style temporary tools
# installed into $TOOLS, using the cross toolchain already present in $TOOLS.
#
# One script, two modes:
#   ./stage1-temp-tools.sh            -> builds Chapter 6 temporary tools in $TOOLS
#   ./stage1-temp-tools.sh chroot     -> prepares mounts and enters chroot to build Chapter 7 extra temp tools
#
# POSIX sh only. Logs per step. Defensive checks and post-install validation.
#
# License: MIT (see LICENSE in this package)

###############################################################################
# User-configurable variables (edit here only)
###############################################################################
ROOT="/mnt/rootfs"
TOOLS="${ROOT}/tools"
TARGET="x86_64-lfs-linux-gnu"

# Workspace
WORKDIR="${ROOT}/.stage1-build"
SRCDIR="${WORKDIR}/sources"
BUILDDIR="${WORKDIR}/build"
LOGDIR="${WORKDIR}/logs"

# LFS stable book reference (used only to fetch the canonical wget-list + md5sums)
LFS_STABLE_BASE="https://www.linuxfromscratch.org/lfs/downloads/stable"

# Which phase to run
PHASE="${1:-tools}"   # tools | chroot

# Parallelism
JOBS="$(getconf _NPROCESSORS_ONLN 2>/dev/null || echo 1)"
MAKEFLAGS="-j${JOBS}"

# Safety toggles
ALLOW_ROOT="1"        # 0 = refuse to run as root
KEEP_WORKDIR="0"      # 1 = do not delete build trees after success
MOUNT_VFS="1"         # 1 = mount /dev /proc /sys /run when PHASE=chroot

###############################################################################
# LFS 12.4 package versions (temporary tools)
# (Pinned to the LFS 12.4 stable book list for compatibility and to keep the set complete.)
###############################################################################
# Chapter 6: Cross Compiling Temporary Tools
M4_VER="1.4.20"
NCURSES_VER="6.5-20250809"
BASH_VER="5.3"
COREUTILS_VER="9.7"
DIFFUTILS_VER="3.12"
FILE_VER="5.46"
FINDUTILS_VER="4.10.0"
GAWK_VER="5.3.2"
GREP_VER="3.12"
GZIP_VER="1.14"
MAKE_VER="4.4.1"
PATCH_VER="2.8"
SED_VER="4.9"
TAR_VER="1.35"
XZ_VER="5.8.1"
BINUTILS_VER="2.45"    # pass 2 (same major as book)
GCC_VER="15.2.0"       # pass 2

# Chapter 7: Additional Temporary Tools (inside chroot)
GETTEXT_VER="0.26"
BISON_VER="3.8.2"
PERL_VER="5.42.0"
PYTHON_VER="3.13.7"
TEXINFO_VER="7.2"
UTIL_LINUX_VER="2.41.1"

###############################################################################
# End of user variables
###############################################################################

set -eu
umask 022
IFS="$(printf ' \t\n')"
export LC_ALL=C

say() { printf '%s\n' "$*"; }
die() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }

need_cmd() { command -v "$1" >/dev/null 2>&1 || die "missing required command: $1"; }
have() { command -v "$1" >/dev/null 2>&1; }

as_user_warning() {
  if [ "$(id -u)" -eq 0 ] && [ "${ALLOW_ROOT}" != "1" ]; then
    die "refusing to run as root (ALLOW_ROOT=0)"
  fi
  if [ "$(id -u)" -eq 0 ]; then
    say "WARNING: running as root. Prefer an unprivileged build user where possible."
  fi
}

mkdirp() { [ -d "$1" ] || mkdir -p "$1"; }

run_logged() {
  name="$1"; shift
  logfile="${LOGDIR}/${name}.log"
  say "==> $name"
  ( "$@" ) >"$logfile" 2>&1 || die "$name failed; see $logfile"
}

fetch() {
  url="$1"
  out="$2"
  if [ -f "$out" ]; then
    return 0
  fi
  if have curl; then
    curl -L --fail --retry 3 --retry-delay 2 -o "$out".tmp "$url"
  elif have wget; then
    wget -O "$out".tmp "$url"
  else
    die "need curl or wget"
  fi
  mv "$out".tmp "$out"
}

md5_file() {
  f="$1"
  if have md5sum; then
    md5sum "$f" | awk '{print $1}'
  elif have md5; then
    md5 -q "$f"
  else
    die "need md5sum (recommended) or md5"
  fi
}

verify_md5() {
  f="$1"
  expected="$2"
  got="$(md5_file "$f")"
  [ "$got" = "$expected" ] || die "md5 mismatch for $(basename "$f"): expected $expected got $got"
}

# Load md5sums from LFS stable downloads (md5 only, as published by LFS)
ensure_lfs_lists() {
  mkdirp "$SRCDIR"
  cd "$SRCDIR"
  fetch "${LFS_STABLE_BASE}/wget-list" "wget-list"
  fetch "${LFS_STABLE_BASE}/md5sums" "md5sums"
}

# Download a tarball whose URL is present in wget-list and verify md5sums entry
download_pkg() {
  tarball="$1"
  ensure_lfs_lists
  cd "$SRCDIR"
  url="$(awk -v t="$tarball" '$0 ~ ("/" t "$") {print $0}' wget-list | head -n 1)"
  [ -n "$url" ] || die "tarball not found in LFS wget-list: $tarball"
  fetch "$url" "$tarball"
  expected="$(awk -v t="$tarball" '$2==t {print $1}' md5sums | head -n 1)"
  [ -n "$expected" ] || die "md5 not found in LFS md5sums for: $tarball"
  verify_md5 "$tarball" "$expected"
}

extract_clean() {
  tarball="$1"
  cd "$BUILDDIR/src"
  # Determine top-level dir name by listing archive
  top="$(tar -tf "$SRCDIR/$tarball" | awk -F/ 'NR==1{print $1}')"
  [ -n "$top" ] || die "cannot determine top dir for $tarball"
  rm -rf "$top"
  tar -xf "$SRCDIR/$tarball"
  printf '%s\n' "$BUILDDIR/src/$top"
}

# Basic environment checks (host side)
check_prereqs_tools_phase() {
  need_cmd sh
  need_cmd make
  need_cmd tar
  need_cmd awk
  need_cmd sed
  need_cmd install
  need_cmd ln
  need_cmd rm
  need_cmd mkdir
  need_cmd gcc
  need_cmd g++
  need_cmd bison
  need_cmd flex
  need_cmd perl
  need_cmd python3

  as_user_warning

  mkdirp "$ROOT" "$TOOLS" "$WORKDIR" "$SRCDIR" "$BUILDDIR" "$LOGDIR"
  mkdirp "$BUILDDIR/src"
  mkdirp "$TOOLS/bin" "$TOOLS/lib" "$TOOLS/include" "$TOOLS/share"

  [ -w "$ROOT" ] || die "ROOT not writable: $ROOT"
  [ -w "$TOOLS" ] || die "TOOLS not writable: $TOOLS"

  # Prefer the temporary toolchain binaries
  export PATH="${TOOLS}/bin:${PATH}"

  # Ensure cross toolchain exists (from your previous script)
  need_cmd "${TARGET}-gcc"
  need_cmd "${TARGET}-ld"
  need_cmd "${TARGET}-as"
}

# Configure triplet detection helper for packages
build_triple() {
  # Best-effort detection; keep POSIX
  if have sh; then
    uname -m 2>/dev/null || echo unknown
  else
    echo unknown
  fi
}

###############################################################################
# Package build functions (Chapter 6)
###############################################################################
build_m4() {
  tb="m4-${M4_VER}.tar.xz"
  download_pkg "$tb"
  src="$(extract_clean "$tb")"
  b="${BUILDDIR}/build-m4"
  rm -rf "$b"; mkdirp "$b"
  BUILD_TRIPLE="$( (cd "$src" && (./build-aux/config.guess 2>/dev/null || ./config.guess 2>/dev/null || true)) | head -n 1 )"
  [ -n "$BUILD_TRIPLE" ] || BUILD_TRIPLE="$(build_triple)"
  run_logged "m4-configure" sh -c "
    cd '$b' &&
    '$src/configure' --prefix='$TOOLS' --host='$TARGET' --build='$BUILD_TRIPLE'
  "
  run_logged "m4-make" sh -c "cd '$b' && make ${MAKEFLAGS}"
  run_logged "m4-install" sh -c "cd '$b' && make install"
  run_logged "m4-validate" sh -c "'$TOOLS/bin/m4' --version | head -n 1 | grep -qi 'm4'"
}

build_ncurses() {
  tb="ncurses-${NCURSES_VER}.tar.gz"
  download_pkg "$tb"
  src="$(extract_clean "$tb")"
  # ncurses uses its own config.guess
  run_logged "ncurses-configure" sh -c "
    cd '$src' &&
    ./configure \
      --prefix='$TOOLS' \
      --host='$TARGET' \
      --build=\$(./config.guess) \
      --mandir='$TOOLS/share/man' \
      --with-shared \
      --without-debug \
      --without-ada \
      --enable-widec
  "
  run_logged "ncurses-make" sh -c "cd '$src' && make ${MAKEFLAGS}"
  run_logged "ncurses-install" sh -c "cd '$src' && make install"
  # Many packages expect libncurses.so; create compatibility symlink if needed
  run_logged "ncurses-symlinks" sh -c "
    if [ -e '$TOOLS/lib/libncursesw.so' ] && [ ! -e '$TOOLS/lib/libncurses.so' ]; then
      ln -sf libncursesw.so '$TOOLS/lib/libncurses.so'
    fi
  "
  run_logged "ncurses-validate" sh -c "'$TOOLS/bin/ncursesw6-config' --version >/dev/null 2>&1 || true"
}

build_bash() {
  tb="bash-${BASH_VER}.tar.gz"
  download_pkg "$tb"
  src="$(extract_clean "$tb")"
  b="${BUILDDIR}/build-bash"
  rm -rf "$b"; mkdirp "$b"
  run_logged "bash-configure" sh -c "
    cd '$b' &&
    '$src/configure' \
      --prefix='$TOOLS' \
      --host='$TARGET' \
      --build=\$('$src/support/config.guess' 2>/dev/null || echo $(build_triple)) \
      --without-bash-malloc
  "
  run_logged "bash-make" sh -c "cd '$b' && make ${MAKEFLAGS}"
  run_logged "bash-install" sh -c "cd '$b' && make install"
  run_logged "bash-validate" sh -c "'$TOOLS/bin/bash' --version | head -n 1 | grep -q 'bash'"
}

build_coreutils() {
  tb="coreutils-${COREUTILS_VER}.tar.xz"
  download_pkg "$tb"
  src="$(extract_clean "$tb")"
  b="${BUILDDIR}/build-coreutils"
  rm -rf "$b"; mkdirp "$b"
  run_logged "coreutils-configure" sh -c "
    cd '$b' &&
    '$src/configure' \
      --prefix='$TOOLS' \
      --host='$TARGET' \
      --build=\$('$src/build-aux/config.guess' 2>/dev/null || echo $(build_triple)) \
      --enable-install-program=hostname \
      --enable-no-install-program=kill,uptime
  "
  run_logged "coreutils-make" sh -c "cd '$b' && make ${MAKEFLAGS}"
  run_logged "coreutils-install" sh -c "cd '$b' && make install"
  run_logged "coreutils-validate" sh -c "'$TOOLS/bin/ls' --version >/dev/null 2>&1"
}

build_diffutils() {
  tb="diffutils-${DIFFUTILS_VER}.tar.xz"
  download_pkg "$tb"
  src="$(extract_clean "$tb")"
  b="${BUILDDIR}/build-diffutils"
  rm -rf "$b"; mkdirp "$b"
  run_logged "diffutils-configure" sh -c "
    cd '$b' &&
    '$src/configure' --prefix='$TOOLS' --host='$TARGET' --build=\$('$src/build-aux/config.guess' 2>/dev/null || echo $(build_triple))
  "
  run_logged "diffutils-make" sh -c "cd '$b' && make ${MAKEFLAGS}"
  run_logged "diffutils-install" sh -c "cd '$b' && make install"
  run_logged "diffutils-validate" sh -c "'$TOOLS/bin/diff' --version >/dev/null 2>&1"
}

build_file() {
  tb="file-${FILE_VER}.tar.gz"
  download_pkg "$tb"
  src="$(extract_clean "$tb")"
  b="${BUILDDIR}/build-file"
  rm -rf "$b"; mkdirp "$b"
  run_logged "file-configure" sh -c "
    cd '$b' &&
    '$src/configure' --prefix='$TOOLS' --host='$TARGET' --build=\$('$src/config.guess' 2>/dev/null || echo $(build_triple))
  "
  run_logged "file-make" sh -c "cd '$b' && make ${MAKEFLAGS}"
  run_logged "file-install" sh -c "cd '$b' && make install"
  run_logged "file-validate" sh -c "'$TOOLS/bin/file' --version >/dev/null 2>&1"
}

build_findutils() {
  tb="findutils-${FINDUTILS_VER}.tar.xz"
  download_pkg "$tb"
  src="$(extract_clean "$tb")"
  b="${BUILDDIR}/build-findutils"
  rm -rf "$b"; mkdirp "$b"
  run_logged "findutils-configure" sh -c "
    cd '$b' &&
    '$src/configure' --prefix='$TOOLS' --host='$TARGET' --build=\$('$src/build-aux/config.guess' 2>/dev/null || echo $(build_triple))
  "
  run_logged "findutils-make" sh -c "cd '$b' && make ${MAKEFLAGS}"
  run_logged "findutils-install" sh -c "cd '$b' && make install"
  run_logged "findutils-validate" sh -c "'$TOOLS/bin/find' --version >/dev/null 2>&1"
}

build_gawk() {
  tb="gawk-${GAWK_VER}.tar.xz"
  download_pkg "$tb"
  src="$(extract_clean "$tb")"
  b="${BUILDDIR}/build-gawk"
  rm -rf "$b"; mkdirp "$b"
  run_logged "gawk-configure" sh -c "
    cd '$b' &&
    '$src/configure' --prefix='$TOOLS' --host='$TARGET' --build=\$('$src/config.guess' 2>/dev/null || echo $(build_triple))
  "
  run_logged "gawk-make" sh -c "cd '$b' && make ${MAKEFLAGS}"
  run_logged "gawk-install" sh -c "cd '$b' && make install"
  run_logged "gawk-validate" sh -c "printf 'x\n' | '$TOOLS/bin/gawk' '{print}' | grep -qx 'x'"
}

build_grep() {
  tb="grep-${GREP_VER}.tar.xz"
  download_pkg "$tb"
  src="$(extract_clean "$tb")"
  b="${BUILDDIR}/build-grep"
  rm -rf "$b"; mkdirp "$b"
  run_logged "grep-configure" sh -c "
    cd '$b' &&
    '$src/configure' --prefix='$TOOLS' --host='$TARGET' --build=\$('$src/build-aux/config.guess' 2>/dev/null || echo $(build_triple))
  "
  run_logged "grep-make" sh -c "cd '$b' && make ${MAKEFLAGS}"
  run_logged "grep-install" sh -c "cd '$b' && make install"
  run_logged "grep-validate" sh -c "printf 'abc\n' | '$TOOLS/bin/grep' -q 'ab'"
}

build_gzip() {
  tb="gzip-${GZIP_VER}.tar.xz"
  download_pkg "$tb"
  src="$(extract_clean "$tb")"
  b="${BUILDDIR}/build-gzip"
  rm -rf "$b"; mkdirp "$b"
  run_logged "gzip-configure" sh -c "
    cd '$b' &&
    '$src/configure' --prefix='$TOOLS' --host='$TARGET' --build=\$('$src/build-aux/config.guess' 2>/dev/null || echo $(build_triple))
  "
  run_logged "gzip-make" sh -c "cd '$b' && make ${MAKEFLAGS}"
  run_logged "gzip-install" sh -c "cd '$b' && make install"
  run_logged "gzip-validate" sh -c "printf 'hi' | '$TOOLS/bin/gzip' -c | '$TOOLS/bin/gzip' -d -c | grep -qx 'hi'"
}

build_make() {
  tb="make-${MAKE_VER}.tar.gz"
  download_pkg "$tb"
  src="$(extract_clean "$tb")"
  b="${BUILDDIR}/build-make"
  rm -rf "$b"; mkdirp "$b"
  run_logged "make-configure" sh -c "
    cd '$b' &&
    '$src/configure' --prefix='$TOOLS' --host='$TARGET' --build=\$('$src/build-aux/config.guess' 2>/dev/null || echo $(build_triple))
  "
  run_logged "make-make" sh -c "cd '$b' && make ${MAKEFLAGS}"
  run_logged "make-install" sh -c "cd '$b' && make install"
  run_logged "make-validate" sh -c "'$TOOLS/bin/make' --version | head -n 1 | grep -q 'Make'"
}

build_patch() {
  tb="patch-${PATCH_VER}.tar.xz"
  download_pkg "$tb"
  src="$(extract_clean "$tb")"
  b="${BUILDDIR}/build-patch"
  rm -rf "$b"; mkdirp "$b"
  run_logged "patch-configure" sh -c "
    cd '$b' &&
    '$src/configure' --prefix='$TOOLS' --host='$TARGET' --build=\$('$src/build-aux/config.guess' 2>/dev/null || echo $(build_triple))
  "
  run_logged "patch-make" sh -c "cd '$b' && make ${MAKEFLAGS}"
  run_logged "patch-install" sh -c "cd '$b' && make install"
  run_logged "patch-validate" sh -c "'$TOOLS/bin/patch' --version >/dev/null 2>&1"
}

build_sed() {
  tb="sed-${SED_VER}.tar.xz"
  download_pkg "$tb"
  src="$(extract_clean "$tb")"
  b="${BUILDDIR}/build-sed"
  rm -rf "$b"; mkdirp "$b"
  run_logged "sed-configure" sh -c "
    cd '$b' &&
    '$src/configure' --prefix='$TOOLS' --host='$TARGET' --build=\$('$src/build-aux/config.guess' 2>/dev/null || echo $(build_triple))
  "
  run_logged "sed-make" sh -c "cd '$b' && make ${MAKEFLAGS}"
  run_logged "sed-install" sh -c "cd '$b' && make install"
  run_logged "sed-validate" sh -c "printf 'a\n' | '$TOOLS/bin/sed' 's/a/b/' | grep -qx 'b'"
}

build_tar() {
  tb="tar-${TAR_VER}.tar.xz"
  download_pkg "$tb"
  src="$(extract_clean "$tb")"
  b="${BUILDDIR}/build-tar"
  rm -rf "$b"; mkdirp "$b"
  run_logged "tar-configure" sh -c "
    cd '$b' &&
    '$src/configure' --prefix='$TOOLS' --host='$TARGET' --build=\$('$src/build-aux/config.guess' 2>/dev/null || echo $(build_triple))
  "
  run_logged "tar-make" sh -c "cd '$b' && make ${MAKEFLAGS}"
  run_logged "tar-install" sh -c "cd '$b' && make install"
  run_logged "tar-validate" sh -c "'$TOOLS/bin/tar' --version | head -n 1 | grep -q 'tar'"
}

build_xz() {
  tb="xz-${XZ_VER}.tar.xz"
  download_pkg "$tb"
  src="$(extract_clean "$tb")"
  b="${BUILDDIR}/build-xz"
  rm -rf "$b"; mkdirp "$b"
  run_logged "xz-configure" sh -c "
    cd '$b' &&
    '$src/configure' --prefix='$TOOLS' --host='$TARGET' --build=\$('$src/build-aux/config.guess' 2>/dev/null || echo $(build_triple)) \
      --disable-static
  "
  run_logged "xz-make" sh -c "cd '$b' && make ${MAKEFLAGS}"
  run_logged "xz-install" sh -c "cd '$b' && make install"
  run_logged "xz-validate" sh -c "printf 'x' | '$TOOLS/bin/xz' -c | '$TOOLS/bin/xz' -d -c | grep -qx 'x'"
}

build_binutils_pass2() {
  tb="binutils-${BINUTILS_VER}.tar.xz"
  download_pkg "$tb"
  src="$(extract_clean "$tb")"
  b="${BUILDDIR}/build-binutils-pass2"
  rm -rf "$b"; mkdirp "$b"
  run_logged "binutils2-configure" sh -c "
    cd '$b' &&
    '$src/configure' \
      --prefix='$TOOLS' \
      --target='$TARGET' \
      --with-sysroot='$ROOT' \
      --disable-nls \
      --disable-werror
  "
  run_logged "binutils2-make" sh -c "cd '$b' && make ${MAKEFLAGS}"
  run_logged "binutils2-install" sh -c "cd '$b' && make install"
  run_logged "binutils2-validate" sh -c "'$TOOLS/bin/${TARGET}-ld' -v >/dev/null 2>&1"
}

build_gcc_pass2() {
  tb="gcc-${GCC_VER}.tar.xz"
  download_pkg "$tb"
  src="$(extract_clean "$tb")"
  # Ensure GCC prereqs are present (as in GCC release tree)
  run_logged "gcc2-prereqs" sh -c "cd '$src' && contrib/download_prerequisites"
  b="${BUILDDIR}/build-gcc-pass2"
  rm -rf "$b"; mkdirp "$b"
  run_logged "gcc2-configure" sh -c "
    cd '$b' &&
    '$src/configure' \
      --target='$TARGET' \
      --prefix='$TOOLS' \
      --with-sysroot='$ROOT' \
      --disable-nls \
      --disable-multilib \
      --enable-languages=c,c++
  "
  run_logged "gcc2-make" sh -c "cd '$b' && make ${MAKEFLAGS}"
  run_logged "gcc2-install" sh -c "cd '$b' && make install"
  # Validation: compile+link a trivial program using the toolchain sysroot already provided by your toolchain step
  t="${BUILDDIR}/gcc2-test"
  rm -rf "$t"; mkdirp "$t"
  cat > "$t/hello.c" <<'EOF'
int main(void){return 0;}
EOF
  run_logged "gcc2-validate" sh -c "
    cd '$t' &&
    '$TOOLS/bin/${TARGET}-gcc' --sysroot='$TOOLS/$TARGET' hello.c -o hello &&
    test -x hello
  "
}

###############################################################################
# Chapter 7 (inside chroot): extra temp tools
# We implement this as a separate code path to avoid accidental host contamination.
###############################################################################
chroot_cmd() {
  # Enter chroot with a clean environment
  chroot "$ROOT" /usr/bin/env -i \
    HOME=/root TERM="${TERM:-xterm}" PS1='(lfs chroot) \u:\w\$ ' \
    PATH=/usr/bin:/usr/sbin:/bin:/sbin:/tools/bin \
    /bin/sh -c "$1"
}

is_mounted() {
  mp="$1"
  if have mountpoint; then
    mountpoint -q "$mp" 2>/dev/null
  else
    # POSIX fallback: parse /proc/mounts if available
    [ -r /proc/mounts ] && awk -v m="$mp" '$2==m{found=1} END{exit(found?0:1)}' /proc/mounts
  fi
}

mount_vfs() {
  [ "$(id -u)" -eq 0 ] || die "PHASE=chroot requires root (for mounts + chroot)"
  if [ "${MOUNT_VFS}" != "1" ]; then
    return 0
  fi
  mkdirp "$ROOT/dev" "$ROOT/proc" "$ROOT/sys" "$ROOT/run"
  is_mounted "$ROOT/dev" || mount --bind /dev "$ROOT/dev"
  is_mounted "$ROOT/dev/pts" || { mkdirp "$ROOT/dev/pts"; mount -t devpts devpts "$ROOT/dev/pts"; }
  is_mounted "$ROOT/proc" || mount -t proc proc "$ROOT/proc"
  is_mounted "$ROOT/sys" || mount -t sysfs sysfs "$ROOT/sys"
  is_mounted "$ROOT/run" || mount -t tmpfs tmpfs "$ROOT/run"
}

umount_vfs() {
  if [ "${MOUNT_VFS}" != "1" ]; then
    return 0
  fi
  umount -l "$ROOT/dev/pts" 2>/dev/null || true
  umount -l "$ROOT/dev" 2>/dev/null || true
  umount -l "$ROOT/proc" 2>/dev/null || true
  umount -l "$ROOT/sys" 2>/dev/null || true
  umount -l "$ROOT/run" 2>/dev/null || true
}

# Minimal chroot-stage script. It downloads sources from SRCDIR (bind-mounted by virtue of being in ROOT),
# builds into /usr, and validates each installed command.
chroot_stage7() {
  # We expect /tools to exist inside chroot as the same prefix
  cat > "${ROOT}/.stage1-build/stage7.sh" <<'EOF'
set -eu
umask 022
export LC_ALL=C

say(){ printf '%s\n' "$*"; }
die(){ printf 'ERROR: %s\n' "$*" >&2; exit 1; }

ROOT="/"
TOOLS="/tools"
WORKDIR="/.stage1-build"
SRCDIR="${WORKDIR}/sources"
BUILDDIR="${WORKDIR}/build-chroot"
LOGDIR="${WORKDIR}/logs-chroot"
JOBS="$(getconf _NPROCESSORS_ONLN 2>/dev/null || echo 1)"
MAKEFLAGS="-j${JOBS}"

mkdir -p "$BUILDDIR/src" "$LOGDIR"

need(){ command -v "$1" >/dev/null 2>&1 || die "missing: $1"; }
need sh; need make; need tar; need awk; need sed; need install; need ln; need rm; need mkdir

run_logged(){
  name="$1"; shift
  logfile="${LOGDIR}/${name}.log"
  say "==> $name"
  ( "$@" ) >"$logfile" 2>&1 || die "$name failed; see $logfile"
}

extract_clean(){
  tarball="$1"
  cd "$BUILDDIR/src"
  top="$(tar -tf "$SRCDIR/$tarball" | awk -F/ 'NR==1{print $1}')"
  [ -n "$top" ] || die "cannot determine top dir for $tarball"
  rm -rf "$top"
  tar -xf "$SRCDIR/$tarball"
  printf '%s\n' "$BUILDDIR/src/$top"
}

# Versions (must match host script vars)
GETTEXT_VER="0.26"
BISON_VER="3.8.2"
PERL_VER="5.42.0"
PYTHON_VER="3.13.7"
TEXINFO_VER="7.2"
UTIL_LINUX_VER="2.41.1"

build_gettext(){
  tb="gettext-${GETTEXT_VER}.tar.xz"
  src="$(extract_clean "$tb")"
  b="${BUILDDIR}/build-gettext"; rm -rf "$b"; mkdir -p "$b"
  run_logged "gettext-configure" sh -c "cd '$b' && '$src/configure' --prefix=/usr --disable-shared"
  run_logged "gettext-make" sh -c "cd '$b' && make ${MAKEFLAGS}"
  run_logged "gettext-install" sh -c "cd '$b' && make install"
  run_logged "gettext-validate" sh -c "/usr/bin/msgfmt --version >/dev/null 2>&1"
}

build_bison(){
  tb="bison-${BISON_VER}.tar.xz"
  src="$(extract_clean "$tb")"
  b="${BUILDDIR}/build-bison"; rm -rf "$b"; mkdir -p "$b"
  run_logged "bison-configure" sh -c "cd '$b' && '$src/configure' --prefix=/usr"
  run_logged "bison-make" sh -c "cd '$b' && make ${MAKEFLAGS}"
  run_logged "bison-install" sh -c "cd '$b' && make install"
  run_logged "bison-validate" sh -c "/usr/bin/bison --version | head -n 1 | grep -qi bison"
}

build_perl(){
  tb="perl-${PERL_VER}.tar.xz"
  src="$(extract_clean "$tb")"
  run_logged "perl-configure" sh -c "cd '$src' && sh Configure -des -Dprefix=/usr -Dvendorprefix=/usr -Duseshrplib"
  run_logged "perl-make" sh -c "cd '$src' && make ${MAKEFLAGS}"
  run_logged "perl-install" sh -c "cd '$src' && make install"
  run_logged "perl-validate" sh -c "/usr/bin/perl -e 'print qq(ok\n)' | grep -qx ok"
}

build_python(){
  tb="Python-${PYTHON_VER}.tar.xz"
  src="$(extract_clean "$tb")"
  run_logged "python-configure" sh -c "cd '$src' && ./configure --prefix=/usr --enable-shared --without-ensurepip"
  run_logged "python-make" sh -c "cd '$src' && make ${MAKEFLAGS}"
  run_logged "python-install" sh -c "cd '$src' && make install"
  run_logged "python-validate" sh -c "/usr/bin/python3 -c 'print(\"ok\")' | grep -qx ok"
}

build_texinfo(){
  tb="texinfo-${TEXINFO_VER}.tar.xz"
  src="$(extract_clean "$tb")"
  b="${BUILDDIR}/build-texinfo"; rm -rf "$b"; mkdir -p "$b"
  run_logged "texinfo-configure" sh -c "cd '$b' && '$src/configure' --prefix=/usr"
  run_logged "texinfo-make" sh -c "cd '$b' && make ${MAKEFLAGS}"
  run_logged "texinfo-install" sh -c "cd '$b' && make install"
  run_logged "texinfo-validate" sh -c "/usr/bin/makeinfo --version >/dev/null 2>&1"
}

build_util_linux(){
  tb="util-linux-${UTIL_LINUX_VER}.tar.xz"
  src="$(extract_clean "$tb")"
  b="${BUILDDIR}/build-util-linux"; rm -rf "$b"; mkdir -p "$b"
  run_logged "util-linux-configure" sh -c "
    cd '$b' &&
    '$src/configure' \
      --prefix=/usr \
      --disable-chfn-chsh \
      --disable-login \
      --disable-nologin \
      --disable-su \
      --disable-setpriv \
      --disable-runuser \
      --disable-pylibmount \
      --disable-static
  "
  run_logged "util-linux-make" sh -c "cd '$b' && make ${MAKEFLAGS}"
  run_logged "util-linux-install" sh -c "cd '$b' && make install"
  run_logged "util-linux-validate" sh -c "/usr/bin/uuidgen --version >/dev/null 2>&1 || /usr/bin/uuidgen >/dev/null 2>&1"
}

say "==> Stage7 (chroot) starting"
build_gettext
build_bison
build_perl
build_python
build_texinfo
build_util_linux
say "==> Stage7 (chroot) complete"
EOF

  chmod 0755 "${ROOT}/.stage1-build/stage7.sh"
  chroot_cmd "/tools/bin/bash -c '/.stage1-build/stage7.sh'"
}

###############################################################################
# Main
###############################################################################
main_tools() {
  check_prereqs_tools_phase

  say "==> Stage1 tools (Chapter 6) starting"
  build_m4
  build_ncurses
  build_bash
  build_coreutils
  build_diffutils
  build_file
  build_findutils
  build_gawk
  build_grep
  build_gzip
  build_make
  build_patch
  build_sed
  build_tar
  build_xz
  build_binutils_pass2
  build_gcc_pass2

  say "==> Stage1 tools complete."
  say "Tools installed in: $TOOLS"
  say "Logs: $LOGDIR"

  if [ "${KEEP_WORKDIR}" != "1" ]; then
    rm -rf "$BUILDDIR/src"
  fi
}

main_chroot() {
  check_prereqs_tools_phase
  # Ensure tarballs for Chapter 7 are present and verified first (host side)
  for tb in \
    "gettext-${GETTEXT_VER}.tar.xz" \
    "bison-${BISON_VER}.tar.xz" \
    "perl-${PERL_VER}.tar.xz" \
    "Python-${PYTHON_VER}.tar.xz" \
    "texinfo-${TEXINFO_VER}.tar.xz" \
    "util-linux-${UTIL_LINUX_VER}.tar.xz"
  do
    download_pkg "$tb"
  done

  # Make sure /tools exists inside ROOT (as expected by LFS chroot stage)
  if [ ! -e "${ROOT}/tools" ]; then
    ln -sfn "${TOOLS}" "${ROOT}/tools" || true
  fi

  # Basic dirs expected inside chroot for stage7
  mkdirp "${ROOT}/usr" "${ROOT}/bin" "${ROOT}/lib" "${ROOT}/sbin" "${ROOT}/etc" "${ROOT}/var" "${ROOT}/tmp"
  chmod 1777 "${ROOT}/tmp" || true

  # Ensure /bin/sh exists inside chroot to run /usr/bin/env
  if [ ! -x "${ROOT}/bin/sh" ]; then
    # Use temporary bash as /bin/sh for the chroot stage
    mkdirp "${ROOT}/bin"
    ln -sf /tools/bin/bash "${ROOT}/bin/sh"
  fi

  trap umount_vfs EXIT INT TERM HUP
  mount_vfs
  chroot_stage7
  say "==> Stage1 chroot phase complete. Logs inside chroot: ${ROOT}/.stage1-build/logs-chroot"
}

case "$PHASE" in
  tools) main_tools ;;
  chroot) main_chroot ;;
  *) die "usage: $0 [tools|chroot]" ;;
esac

exit 0
