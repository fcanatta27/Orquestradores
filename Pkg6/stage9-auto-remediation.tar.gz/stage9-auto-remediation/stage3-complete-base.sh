#!/bin/sh
# stage3-complete-base.sh
# Stage 3: build the remaining "base system" packages inside chroot, to reach a complete,
# self-hosting userland (init + core admin + networking essentials), after Stage2.
#
# This script:
# - downloads verified source tarballs using the LFS stable wget-list + md5sums
# - mounts VFS, enters chroot, and builds/installs packages into /usr (and /etc where needed)
# - runs minimal post-install validations to ensure binaries execute and core features work
#
# POSIX sh only. All configuration variables are at the top.
#
# License: MIT (see LICENSE in this package)

###############################################################################
# User-configurable variables
###############################################################################
ROOT="/mnt/rootfs"
TOOLS="${ROOT}/tools"
LFS_STABLE_BASE="https://www.linuxfromscratch.org/lfs/downloads/stable"

WORKDIR="${ROOT}/.stage3-build"
SRCDIR="${WORKDIR}/sources"
LOGDIR="${WORKDIR}/logs"

JOBS="$(getconf _NPROCESSORS_ONLN 2>/dev/null || echo 1)"
MAKEFLAGS="-j${JOBS}"

ALLOW_ROOT="1"
MOUNT_VFS="1"
KEEP_WORKDIR="0"

# Package set (prefixes). We resolve concrete tarballs from LFS stable wget-list.
# This set is oriented to a SysV-init base userland and typical LFS "base system" remainder.
PKG_PREFIXES="
  man-pages-
  iana-etc-
  tzdata
  pkgconf-
  ncurses-
  libcap-
  shadow-
  util-linux-
  e2fsprogs-
  kbd-
  procps-ng-
  psmisc-
  sysklogd-
  sysvinit-
  iproute2-
  kmod-
  inetutils-
  less-
  vim-
"

###############################################################################
set -eu
umask 022
IFS="$(printf ' \t\n')"
export LC_ALL=C

say(){ printf '%s\n' "$*"; }
die(){ printf 'ERROR: %s\n' "$*" >&2; exit 1; }
have(){ command -v "$1" >/dev/null 2>&1; }
need(){ command -v "$1" >/dev/null 2>&1 || die "missing required command: $1"; }
mkdirp(){ [ -d "$1" ] || mkdir -p "$1"; }

as_root() {
  if [ "$(id -u)" -eq 0 ] && [ "${ALLOW_ROOT}" != "1" ]; then
    die "refusing to run as root (ALLOW_ROOT=0)"
  fi
  [ "$(id -u)" -eq 0 ] || die "stage3 requires root (mounts + chroot)"
}

fetch() {
  url="$1"; out="$2"
  [ -f "$out" ] && return 0
  if have curl; then
    curl -L --fail --retry 3 --retry-delay 2 -o "$out".tmp "$url"
  elif have wget; then
    wget -O "$out".tmp "$url"
  else
    die "need curl or wget"
  fi
  mv "$out".tmp "$out"
}

md5_file() {
  f="$1"
  if have md5sum; then md5sum "$f" | awk '{print $1}'
  elif have md5; then md5 -q "$f"
  else die "need md5sum (recommended) or md5"
  fi
}

verify_md5() {
  f="$1"; expected="$2"
  got="$(md5_file "$f")"
  [ "$got" = "$expected" ] || die "md5 mismatch for $(basename "$f"): expected $expected got $got"
}

ensure_lfs_lists() {
  mkdirp "$SRCDIR"
  cd "$SRCDIR"
  fetch "${LFS_STABLE_BASE}/wget-list" "wget-list"
  fetch "${LFS_STABLE_BASE}/md5sums" "md5sums"
}

resolve_tarball() {
  prefix="$1"
  # prefix may be "tzdata" without trailing hyphen; treat it as substring match
  ensure_lfs_lists
  cd "$SRCDIR"
  if printf '%s' "$prefix" | grep -q -- '-$'; then
    # Match "/prefix<something>.tar."
    tb="$(awk -v p="$prefix" '$0 ~ ("/" p) {sub(".*/","",$0); print $0}' wget-list | head -n 1)"
  else
    tb="$(awk -v p="$prefix" '$0 ~ ("/" p) {sub(".*/","",$0); print $0}' wget-list | head -n 1)"
  fi
  [ -n "$tb" ] || die "could not resolve tarball for prefix: $prefix"
  printf '%s\n' "$tb"
}

download_pkg() {
  tarball="$1"
  ensure_lfs_lists
  cd "$SRCDIR"
  url="$(awk -v t="$tarball" '$0 ~ ("/" t "$") {print $0}' wget-list | head -n 1)"
  [ -n "$url" ] || die "tarball not found in LFS wget-list: $tarball"
  fetch "$url" "$tarball"
  expected="$(awk -v t="$tarball" '$2==t {print $1}' md5sums | head -n 1)"
  [ -n "$expected" ] || die "md5 not found in LFS md5sums for: $tarball"
  verify_md5 "$tarball" "$expected"
}

is_mounted() {
  mp="$1"
  if have mountpoint; then
    mountpoint -q "$mp" 2>/dev/null
  else
    [ -r /proc/mounts ] && awk -v m="$mp" '$2==m{f=1} END{exit(f?0:1)}' /proc/mounts
  fi
}

mount_vfs() {
  [ "${MOUNT_VFS}" = "1" ] || return 0
  mkdirp "$ROOT/dev" "$ROOT/proc" "$ROOT/sys" "$ROOT/run"
  is_mounted "$ROOT/dev" || mount --bind /dev "$ROOT/dev"
  is_mounted "$ROOT/dev/pts" || { mkdirp "$ROOT/dev/pts"; mount -t devpts devpts "$ROOT/dev/pts"; }
  is_mounted "$ROOT/proc" || mount -t proc proc "$ROOT/proc"
  is_mounted "$ROOT/sys" || mount -t sysfs sysfs "$ROOT/sys"
  is_mounted "$ROOT/run" || mount -t tmpfs tmpfs "$ROOT/run"
}

umount_vfs() {
  [ "${MOUNT_VFS}" = "1" ] || return 0
  umount -l "$ROOT/dev/pts" 2>/dev/null || true
  umount -l "$ROOT/dev" 2>/dev/null || true
  umount -l "$ROOT/proc" 2>/dev/null || true
  umount -l "$ROOT/sys" 2>/dev/null || true
  umount -l "$ROOT/run" 2>/dev/null || true
}

write_chroot_script() {
  mkdirp "$WORKDIR" "$LOGDIR" "$SRCDIR"
  cat > "${ROOT}/.stage3-build/stage3-chroot.sh" <<'EOF'
set -eu
umask 022
export LC_ALL=C

say(){ printf '%s\n' "$*"; }
die(){ printf 'ERROR: %s\n' "$*" >&2; exit 1; }
need(){ command -v "$1" >/dev/null 2>&1 || die "missing: $1"; }

WORKDIR="/.stage3-build"
SRCDIR="${WORKDIR}/sources"
BUILDDIR="${WORKDIR}/build"
LOGDIR="${WORKDIR}/logs-chroot"
JOBS="$(getconf _NPROCESSORS_ONLN 2>/dev/null || echo 1)"
MAKEFLAGS="-j${JOBS}"

mkdir -p "$BUILDDIR/src" "$LOGDIR"

run_logged(){
  name="$1"; shift
  logfile="${LOGDIR}/${name}.log"
  say "==> $name"
  ( "$@" ) >"$logfile" 2>&1 || die "$name failed; see $logfile"
}

extract_clean(){
  tb="$1"
  cd "$BUILDDIR/src"
  top="$(tar -tf "$SRCDIR/$tb" | awk -F/ 'NR==1{print $1}')"
  [ -n "$top" ] || die "cannot determine top dir for $tb"
  rm -rf "$top"
  tar -xf "$SRCDIR/$tb"
  printf '%s\n' "$BUILDDIR/src/$top"
}

# Ensure base tools exist (from Stage2)
need sh; need make; need tar; need awk; need sed; need grep
need gcc; need ld; need ar

export PATH=/usr/bin:/usr/sbin:/bin:/sbin:/tools/bin

# ---------------- Packages ----------------

build_man_pages(){
  tb="$(ls "$SRCDIR"/man-pages-*.tar.* 2>/dev/null | head -n 1 | sed 's#.*/##')"
  [ -n "$tb" ] || return 0
  src="$(extract_clean "$tb")"
  run_logged "man-pages-install" sh -c "cd '$src' && make install"
  run_logged "man-pages-validate" sh -c "test -d /usr/share/man"
}

build_iana_etc(){
  tb="$(ls "$SRCDIR"/iana-etc-*.tar.* 2>/dev/null | head -n 1 | sed 's#.*/##')"
  [ -n "$tb" ] || return 0
  src="$(extract_clean "$tb")"
  run_logged "iana-etc-install" sh -c "cd '$src' && make install"
  run_logged "iana-etc-validate" sh -c "test -f /etc/services"
}

build_tzdata(){
  tb="$(ls "$SRCDIR"/tzdata*.tar.* 2>/dev/null | head -n 1 | sed 's#.*/##')"
  [ -n "$tb" ] || return 0
  srcdir="$BUILDDIR/src/tzdata"
  rm -rf "$srcdir"; mkdir -p "$srcdir"
  run_logged "tzdata-extract" sh -c "cd '$srcdir' && tar -xf '$SRCDIR/$tb'"
  run_logged "tzdata-install" sh -c "cd '$srcdir' && ZONEINFO=/usr/share/zoneinfo mkdir -p \$ZONEINFO && cp -r zoneinfo/* \$ZONEINFO/"
  run_logged "tzdata-validate" sh -c "test -d /usr/share/zoneinfo"
}

build_pkgconf(){
  tb="$(ls "$SRCDIR"/pkgconf-*.tar.* 2>/dev/null | head -n 1 | sed 's#.*/##')"
  [ -n "$tb" ] || return 0
  src="$(extract_clean "$tb")"
  b="${BUILDDIR}/build-pkgconf"; rm -rf "$b"; mkdir -p "$b"
  run_logged "pkgconf-configure" sh -c "cd '$b' && '$src/configure' --prefix=/usr --disable-static"
  run_logged "pkgconf-make" sh -c "cd '$b' && make ${MAKEFLAGS}"
  run_logged "pkgconf-install" sh -c "cd '$b' && make install"
  run_logged "pkgconf-validate" sh -c "/usr/bin/pkgconf --version >/dev/null 2>&1"
}

build_ncurses(){
  tb="$(ls "$SRCDIR"/ncurses-*.tar.* 2>/dev/null | head -n 1 | sed 's#.*/##')"
  [ -n "$tb" ] || return 0
  src="$(extract_clean "$tb")"
  run_logged "ncurses-configure" sh -c "cd '$src' && ./configure --prefix=/usr --mandir=/usr/share/man --with-shared --without-debug --enable-widec"
  run_logged "ncurses-make" sh -c "cd '$src' && make ${MAKEFLAGS}"
  run_logged "ncurses-install" sh -c "cd '$src' && make install"
  run_logged "ncurses-validate" sh -c "test -f /usr/lib/libncursesw.so || test -f /usr/lib64/libncursesw.so"
}

build_libcap(){
  tb="$(ls "$SRCDIR"/libcap-*.tar.* 2>/dev/null | head -n 1 | sed 's#.*/##')"
  [ -n "$tb" ] || return 0
  src="$(extract_clean "$tb")"
  run_logged "libcap-make" sh -c "cd '$src' && make ${MAKEFLAGS} prefix=/usr lib=lib"
  run_logged "libcap-install" sh -c "cd '$src' && make prefix=/usr lib=lib install"
  run_logged "libcap-validate" sh -c "/usr/sbin/getcap --version >/dev/null 2>&1 || true"
}

build_shadow(){
  tb="$(ls "$SRCDIR"/shadow-*.tar.* 2>/dev/null | head -n 1 | sed 's#.*/##')"
  [ -n "$tb" ] || return 0
  src="$(extract_clean "$tb")"
  b="${BUILDDIR}/build-shadow"; rm -rf "$b"; mkdir -p "$b"
  run_logged "shadow-configure" sh -c "cd '$b' && '$src/configure' --sysconfdir=/etc --prefix=/usr --disable-static --with-group-name-max-length=32"
  run_logged "shadow-make" sh -c "cd '$b' && make ${MAKEFLAGS}"
  run_logged "shadow-install" sh -c "cd '$b' && make install"
  run_logged "shadow-validate" sh -c "/usr/bin/passwd --help >/dev/null 2>&1"
}

build_util_linux(){
  tb="$(ls "$SRCDIR"/util-linux-*.tar.* 2>/dev/null | head -n 1 | sed 's#.*/##')"
  [ -n "$tb" ] || return 0
  src="$(extract_clean "$tb")"
  b="${BUILDDIR}/build-util-linux"; rm -rf "$b"; mkdir -p "$b"
  run_logged "util-linux-configure" sh -c "cd '$b' && '$src/configure' --prefix=/usr --disable-static --without-python"
  run_logged "util-linux-make" sh -c "cd '$b' && make ${MAKEFLAGS}"
  run_logged "util-linux-install" sh -c "cd '$b' && make install"
  run_logged "util-linux-validate" sh -c "/usr/bin/lsblk --version >/dev/null 2>&1"
}

build_e2fsprogs(){
  tb="$(ls "$SRCDIR"/e2fsprogs-*.tar.* 2>/dev/null | head -n 1 | sed 's#.*/##')"
  [ -n "$tb" ] || return 0
  src="$(extract_clean "$tb")"
  b="${BUILDDIR}/build-e2fsprogs"; rm -rf "$b"; mkdir -p "$b"
  run_logged "e2fsprogs-configure" sh -c "cd '$b' && '$src/configure' --prefix=/usr --sysconfdir=/etc --enable-elf-shlibs --disable-libblkid --disable-libuuid"
  run_logged "e2fsprogs-make" sh -c "cd '$b' && make ${MAKEFLAGS}"
  run_logged "e2fsprogs-install" sh -c "cd '$b' && make install"
  run_logged "e2fsprogs-validate" sh -c "/usr/sbin/mke2fs -V >/dev/null 2>&1"
}

build_kbd(){
  tb="$(ls "$SRCDIR"/kbd-*.tar.* 2>/dev/null | head -n 1 | sed 's#.*/##')"
  [ -n "$tb" ] || return 0
  src="$(extract_clean "$tb")"
  b="${BUILDDIR}/build-kbd"; rm -rf "$b"; mkdir -p "$b"
  run_logged "kbd-configure" sh -c "cd '$b' && '$src/configure' --prefix=/usr --disable-vlock"
  run_logged "kbd-make" sh -c "cd '$b' && make ${MAKEFLAGS}"
  run_logged "kbd-install" sh -c "cd '$b' && make install"
  run_logged "kbd-validate" sh -c "/usr/bin/loadkeys --help >/dev/null 2>&1"
}

build_procps(){
  tb="$(ls "$SRCDIR"/procps-ng-*.tar.* 2>/dev/null | head -n 1 | sed 's#.*/##')"
  [ -n "$tb" ] || return 0
  src="$(extract_clean "$tb")"
  run_logged "procps-configure" sh -c "cd '$src' && ./configure --prefix=/usr --disable-static"
  run_logged "procps-make" sh -c "cd '$src' && make ${MAKEFLAGS}"
  run_logged "procps-install" sh -c "cd '$src' && make install"
  run_logged "procps-validate" sh -c "/usr/bin/ps --version >/dev/null 2>&1 || /usr/bin/ps aux >/dev/null 2>&1"
}

build_psmisc(){
  tb="$(ls "$SRCDIR"/psmisc-*.tar.* 2>/dev/null | head -n 1 | sed 's#.*/##')"
  [ -n "$tb" ] || return 0
  src="$(extract_clean "$tb")"
  b="${BUILDDIR}/build-psmisc"; rm -rf "$b"; mkdir -p "$b"
  run_logged "psmisc-configure" sh -c "cd '$b' && '$src/configure' --prefix=/usr"
  run_logged "psmisc-make" sh -c "cd '$b' && make ${MAKEFLAGS}"
  run_logged "psmisc-install" sh -c "cd '$b' && make install"
  run_logged "psmisc-validate" sh -c "/usr/bin/killall --help >/dev/null 2>&1"
}

build_sysklogd(){
  tb="$(ls "$SRCDIR"/sysklogd-*.tar.* 2>/dev/null | head -n 1 | sed 's#.*/##')"
  [ -n "$tb" ] || return 0
  src="$(extract_clean "$tb")"
  run_logged "sysklogd-make" sh -c "cd '$src' && make ${MAKEFLAGS}"
  run_logged "sysklogd-install" sh -c "cd '$src' && make BINDIR=/sbin install"
  run_logged "sysklogd-validate" sh -c "/sbin/syslogd -v >/dev/null 2>&1 || true"
}

build_sysvinit(){
  tb="$(ls "$SRCDIR"/sysvinit-*.tar.* 2>/dev/null | head -n 1 | sed 's#.*/##')"
  [ -n "$tb" ] || return 0
  src="$(extract_clean "$tb")"
  run_logged "sysvinit-make" sh -c "cd '$src' && make ${MAKEFLAGS}"
  run_logged "sysvinit-install" sh -c "cd '$src' && make install"
  run_logged "sysvinit-validate" sh -c "/sbin/init --version >/dev/null 2>&1 || true"
}

build_iproute2(){
  tb="$(ls "$SRCDIR"/iproute2-*.tar.* 2>/dev/null | head -n 1 | sed 's#.*/##')"
  [ -n "$tb" ] || return 0
  src="$(extract_clean "$tb")"
  run_logged "iproute2-make" sh -c "cd '$src' && make ${MAKEFLAGS}"
  run_logged "iproute2-install" sh -c "cd '$src' && make SBINDIR=/usr/sbin install"
  run_logged "iproute2-validate" sh -c "/usr/sbin/ip -V >/dev/null 2>&1"
}

build_kmod(){
  tb="$(ls "$SRCDIR"/kmod-*.tar.* 2>/dev/null | head -n 1 | sed 's#.*/##')"
  [ -n "$tb" ] || return 0
  src="$(extract_clean "$tb")"
  b="${BUILDDIR}/build-kmod"; rm -rf "$b"; mkdir -p "$b"
  run_logged "kmod-configure" sh -c "cd '$b' && '$src/configure' --prefix=/usr --sysconfdir=/etc --disable-static"
  run_logged "kmod-make" sh -c "cd '$b' && make ${MAKEFLAGS}"
  run_logged "kmod-install" sh -c "cd '$b' && make install"
  run_logged "kmod-validate" sh -c "/usr/bin/kmod --version >/dev/null 2>&1"
}

build_inetutils(){
  tb="$(ls "$SRCDIR"/inetutils-*.tar.* 2>/dev/null | head -n 1 | sed 's#.*/##')"
  [ -n "$tb" ] || return 0
  src="$(extract_clean "$tb")"
  b="${BUILDDIR}/build-inetutils"; rm -rf "$b"; mkdir -p "$b"
  run_logged "inetutils-configure" sh -c "cd '$b' && '$src/configure' --prefix=/usr --disable-logger --disable-whois --disable-rcp --disable-rexec --disable-rlogin --disable-rsh"
  run_logged "inetutils-make" sh -c "cd '$b' && make ${MAKEFLAGS}"
  run_logged "inetutils-install" sh -c "cd '$b' && make install"
  run_logged "inetutils-validate" sh -c "/usr/bin/ping --version >/dev/null 2>&1 || true"
}

build_less(){
  tb="$(ls "$SRCDIR"/less-*.tar.* 2>/dev/null | head -n 1 | sed 's#.*/##')"
  [ -n "$tb" ] || return 0
  src="$(extract_clean "$tb")"
  run_logged "less-make" sh -c "cd '$src' && make ${MAKEFLAGS}"
  run_logged "less-install" sh -c "cd '$src' && make prefix=/usr install"
  run_logged "less-validate" sh -c "/usr/bin/less --version >/dev/null 2>&1"
}

build_vim(){
  tb="$(ls "$SRCDIR"/vim-*.tar.* 2>/dev/null | head -n 1 | sed 's#.*/##')"
  [ -n "$tb" ] || return 0
  src="$(extract_clean "$tb")"
  run_logged "vim-configure" sh -c "cd '$src' && ./configure --prefix=/usr"
  run_logged "vim-make" sh -c "cd '$src' && make ${MAKEFLAGS}"
  run_logged "vim-install" sh -c "cd '$src' && make install"
  run_logged "vim-validate" sh -c "/usr/bin/vim --version >/dev/null 2>&1"
}

final_sanity(){
  run_logged "sanity-shell" sh -c "/bin/sh -c 'echo stage3-ok' | grep -qx stage3-ok"
  run_logged "sanity-coreutils" sh -c "/usr/bin/printf '%s\n' ok | /usr/bin/head -n 1 | grep -qx ok"
  run_logged "sanity-network" sh -c "/usr/sbin/ip link >/dev/null 2>&1 || true"
}

say "==> Stage3 starting (remaining base packages)"

build_man_pages
build_iana_etc
build_tzdata
build_pkgconf
build_ncurses
build_libcap
build_shadow
build_util_linux
build_e2fsprogs
build_kbd
build_procps
build_psmisc
build_sysklogd
build_sysvinit
build_iproute2
build_kmod
build_inetutils
build_less
build_vim

final_sanity

say "==> Stage3 complete. Logs: $LOGDIR"
EOF
  chmod 0755 "${ROOT}/.stage3-build/stage3-chroot.sh"
}

run_stage3() {
  write_chroot_script
  chroot "$ROOT" /usr/bin/env -i \
    HOME=/root TERM="${TERM:-xterm}" PS1='(stage3) \u:\w\$ ' \
    PATH=/usr/bin:/usr/sbin:/bin:/sbin:/tools/bin \
    /bin/sh -c "/.stage3-build/stage3-chroot.sh"
}

###############################################################################
# Main
###############################################################################
need sh; need awk; need sed; need tar; need mount; need umount; need chroot

as_root

mkdirp "$WORKDIR" "$SRCDIR" "$LOGDIR"

# Ensure /tools is present inside ROOT, and /bin/sh exists for chroot
[ -e "$ROOT/tools" ] || ln -sfn "$TOOLS" "$ROOT/tools" 2>/dev/null || true
if [ ! -x "$ROOT/bin/sh" ]; then
  mkdirp "$ROOT/bin"
  ln -sf /tools/bin/bash "$ROOT/bin/sh"
fi

# Download all required tarballs before entering chroot.
for p in $PKG_PREFIXES; do
  tb="$(resolve_tarball "$p")"
  download_pkg "$tb"
done

trap umount_vfs EXIT INT TERM HUP
mount_vfs
run_stage3

say "==> SUCCESS: Stage3 finished."
say "Chroot logs: ${ROOT}/.stage3-build/logs-chroot"
