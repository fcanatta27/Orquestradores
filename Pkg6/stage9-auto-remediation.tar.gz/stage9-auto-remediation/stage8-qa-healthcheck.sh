#!/bin/sh
# stage8-qa-healthcheck.sh
#
# QA/Healthcheck "extreme" for the complete CLI system (SysVinit-based).
# Produces:
# - single READY/NOT-READY summary
# - detailed report listing all issues, missing deps, misconfigurations
# - exit code: 0 if ready; 1 if warnings only; 2 if critical issues
#
# Can run:
#  A) on the running target system (recommended)
#  B) from host using chroot into ROOT (set ROOT=/mnt/rootfs)
#
# POSIX sh only. License: MIT.

###############################################################################
# User-configurable variables
###############################################################################
ROOT=""                 # empty = run on current system; or set e.g. /mnt/rootfs to run via chroot
REPORT_DIR="/var/log"   # inside target system
REPORT_PREFIX="healthcheck"

# Network targets for validation
PING_TARGET="1.1.1.1"          # IP-only connectivity check (optional if ping exists)
DNS_TARGET="example.com"       # DNS resolution check (requires getent or nslookup)

# Wi-Fi checks (best-effort)
WIFI_IFACE=""                  # auto-detect if empty
WIFI_EXPECTED_SSID=""          # optional: if set, verify association name is visible in logs
WIFI_SERVICE_NAME="wifi"       # sv service name from Stage4/Stage5 stack

# Strictness
FAIL_ON_NO_NETWORK="0"         # 1 = treat no network as critical; 0 = warning
FAIL_ON_NO_WIFI="0"            # 1 = treat missing wifi as critical (only if wifi iface exists)

###############################################################################
set -eu
umask 022
IFS="$(printf ' \t\n')"
export LC_ALL=C

say(){ printf '%s\n' "$*"; }
have(){ command -v "$1" >/dev/null 2>&1; }

now_ts() { date +%Y%m%d-%H%M%S 2>/dev/null || echo now; }

# Severity counters
CRIT=0
WARN=0
INFO=0

add_crit(){ CRIT=$((CRIT+1)); printf '%s\n' "CRITICAL: $*" >>"$REPORT"; }
add_warn(){ WARN=$((WARN+1)); printf '%s\n' "WARNING:  $*" >>"$REPORT"; }
add_info(){ INFO=$((INFO+1)); printf '%s\n' "INFO:     $*" >>"$REPORT"; }

run_cmd() {
  # run_cmd "desc" cmd...
  desc="$1"; shift
  if "$@" >/dev/null 2>&1; then
    add_info "$desc: OK"
    return 0
  fi
  add_warn "$desc: failed"
  return 1
}

is_mounted() {
  mp="$1"
  if have mountpoint; then
    mountpoint -q "$mp" 2>/dev/null
  else
    [ -r /proc/mounts ] && awk -v m="$mp" '$2==m{f=1} END{exit(f?0:1)}' /proc/mounts
  fi
}

file_mode() {
  # prints numeric mode (e.g., 440) if possible
  f="$1"
  if have stat; then
    # GNU coreutils: %a; busybox stat differs, try both
    m="$(stat -c %a "$f" 2>/dev/null || stat -f %Lp "$f" 2>/dev/null || true)"
    [ -n "$m" ] && printf '%s\n' "$m" || printf '%s\n' ""
  else
    printf '%s\n' ""
  fi
}

is_running_procname() {
  name="$1"
  if have ps; then
    ps -eo comm 2>/dev/null | awk -v n="$name" '$1==n{f=1} END{exit(f?0:1)}'
  else
    return 1
  fi
}

detect_wifi_iface() {
  if [ -n "$WIFI_IFACE" ]; then
    printf '%s\n' "$WIFI_IFACE"
    return 0
  fi
  if have iw; then
    iw dev 2>/dev/null | awk '/Interface/{print $2; exit 0}'
    return 0
  fi
  # fallback: common patterns
  for d in /sys/class/net/*; do
    n="$(basename "$d")"
    case "$n" in
      wl*|wlan* ) printf '%s\n' "$n"; return 0 ;;
    esac
  done
  printf '%s\n' ""
}

net_has_default_route() {
  if have ip; then
    ip route 2>/dev/null | awk '$1=="default"{f=1} END{exit(f?0:1)}'
  elif have route; then
    route -n 2>/dev/null | awk '$1=="0.0.0.0"{f=1} END{exit(f?0:1)}'
  else
    return 1
  fi
}

dns_resolve() {
  host="$1"
  if have getent; then
    getent hosts "$host" >/dev/null 2>&1
  elif have nslookup; then
    nslookup "$host" >/dev/null 2>&1
  elif have host; then
    host "$host" >/dev/null 2>&1
  else
    return 2
  fi
}

ping_ip() {
  ipt="$1"
  if have ping; then
    ping -c 1 -W 1 "$ipt" >/dev/null 2>&1
  else
    return 2
  fi
}

check_boot_artifacts() {
  add_info "== Boot artifacts =="
  if [ -d /boot ]; then
    add_info "/boot exists"
  else
    add_crit "/boot missing"
    return
  fi

  # vmlinuz present?
  if [ -e /boot/vmlinuz ]; then
    add_info "/boot/vmlinuz present"
  else
    add_warn "/boot/vmlinuz missing (symlink expected); check Stage6 kernel install"
  fi

  if [ -e /boot/grub/grub.cfg ]; then
    add_info "/boot/grub/grub.cfg present"
  else
    add_crit "GRUB config missing: /boot/grub/grub.cfg"
  fi

  # init must exist
  if [ -x /sbin/init ]; then
    add_info "/sbin/init present"
  else
    add_crit "/sbin/init missing or not executable"
  fi
}

check_mounts() {
  add_info "== Mounts =="
  for mp in /proc /sys /dev /run; do
    if is_mounted "$mp"; then
      add_info "mounted: $mp"
    else
      add_crit "not mounted: $mp"
    fi
  done

  # /tmp permissions
  if [ -d /tmp ]; then
    m="$(file_mode /tmp)"
    if [ "$m" = "1777" ]; then add_info "/tmp mode 1777 OK"; else add_warn "/tmp mode is $m (expected 1777)"; fi
  else
    add_warn "/tmp missing"
  fi
}

check_core_configs() {
  add_info "== Core configs =="
  [ -f /etc/fstab ] && add_info "/etc/fstab present" || add_crit "/etc/fstab missing"
  [ -f /etc/hostname ] && add_info "/etc/hostname present" || add_warn "/etc/hostname missing"
  [ -f /etc/hosts ] && add_info "/etc/hosts present" || add_warn "/etc/hosts missing"

  # locale
  if [ -f /etc/profile.d/locale.sh ]; then
    add_info "/etc/profile.d/locale.sh present"
  else
    add_warn "locale defaults missing: /etc/profile.d/locale.sh"
  fi

  # resolv.conf (network)
  if [ -f /etc/resolv.conf ]; then
    add_info "/etc/resolv.conf present"
  else
    add_warn "/etc/resolv.conf missing (DNS may fail)"
  fi
}

check_permissions_security() {
  add_info "== Permissions/security =="
  if [ -f /etc/sudoers ]; then
    m="$(file_mode /etc/sudoers)"
    if [ "$m" = "440" ]; then
      add_info "/etc/sudoers mode 0440 OK"
    else
      add_warn "/etc/sudoers mode is $m (expected 440)"
    fi
  else
    add_warn "/etc/sudoers missing (sudo not configured/installed)"
  fi

  if [ -f /etc/shadow ]; then
    m="$(file_mode /etc/shadow)"
    # Commonly 000 or 600; accept both.
    if [ "$m" = "600" ] || [ "$m" = "000" ] || [ "$m" = "400" ]; then
      add_info "/etc/shadow mode $m OK"
    else
      add_warn "/etc/shadow mode is $m (expected 600/000)"
    fi
  else
    add_crit "/etc/shadow missing"
  fi

  if [ -d /var/lib/seedrng ]; then
    m="$(file_mode /var/lib/seedrng)"
    if [ "$m" = "700" ]; then add_info "/var/lib/seedrng mode 0700 OK"; else add_warn "/var/lib/seedrng mode is $m (expected 700)"; fi
  else
    add_info "/var/lib/seedrng not present (seedrng may be disabled)"
  fi
}

check_services_sysv() {
  add_info "== Services (SysV) =="
  # Required-ish processes depending on stages
  if is_running_procname "syslogd"; then add_info "syslogd running"; else add_warn "syslogd not running"; fi
  if is_running_procname "svscan"; then add_info "svscan running"; else add_warn "svscan not running (supervision layer inactive?)"; fi
  if is_running_procname "dhcpcd"; then add_info "dhcpcd running"; else add_info "dhcpcd not running (ok if static IP)"; fi

  # udevd may have different name
  if is_running_procname "udevd" || is_running_procname "systemd-udevd"; then
    add_info "udevd running"
  else
    add_warn "udevd not running (device hotplug may be broken)"
  fi

  # cron
  if is_running_procname "cron"; then add_info "cron running"; else add_info "cron not running (ok if disabled)"; fi
}

check_logs() {
  add_info "== Logs =="
  if [ -f /var/log/boot.log ]; then
    add_info "/var/log/boot.log present"
    # Look for obvious boot errors
    if grep -iE 'panic|segfault|failed|error' /var/log/boot.log >/dev/null 2>&1; then
      add_warn "boot.log contains error-like strings (review recommended)"
    else
      add_info "boot.log: no obvious error keywords"
    fi
  else
    add_warn "/var/log/boot.log missing"
  fi

  # syslog
  if [ -f /var/log/messages ] || [ -f /var/log/syslog ]; then
    add_info "syslog file present"
  else
    add_info "no /var/log/messages|syslog (may be configured differently)"
  fi

  if [ -d /var/log/sv ]; then
    add_info "/var/log/sv exists"
  else
    add_info "/var/log/sv not present (supervision logs absent)"
  fi
}

check_network() {
  add_info "== Network (dhcpcd + connectivity + DNS) =="
  if have ip; then
    if ip link show >/dev/null 2>&1; then add_info "iproute2 OK"; else add_warn "ip link failed"; fi
  else
    add_warn "ip command missing (iproute2 not installed?)"
  fi

  if net_has_default_route; then
    add_info "default route present"
  else
    msg="no default route"
    if [ "$FAIL_ON_NO_NETWORK" = "1" ]; then add_crit "$msg"; else add_warn "$msg"; fi
  fi

  prc=0
  ping_ip "$PING_TARGET" || prc=$?
  if [ "$prc" = "0" ]; then
    add_info "ping $PING_TARGET OK"
  elif [ "$prc" = "2" ]; then
    add_info "ping not available; skipping ping check"
  else
    msg="ping $PING_TARGET failed"
    if [ "$FAIL_ON_NO_NETWORK" = "1" ]; then add_crit "$msg"; else add_warn "$msg"; fi
  fi

  drc=0
  dns_resolve "$DNS_TARGET" || drc=$?
  if [ "$drc" = "0" ]; then
    add_info "DNS resolve $DNS_TARGET OK"
  elif [ "$drc" = "2" ]; then
    add_warn "no DNS tool (getent/nslookup/host); cannot validate DNS"
  else
    msg="DNS resolve $DNS_TARGET failed"
    if [ "$FAIL_ON_NO_NETWORK" = "1" ]; then add_crit "$msg"; else add_warn "$msg"; fi
  fi
}

check_wifi() {
  add_info "== Wi-Fi (best-effort) =="
  iface="$(detect_wifi_iface)"
  if [ -z "$iface" ]; then
    add_info "no Wi-Fi interface detected"
    return 0
  fi
  add_info "Wi-Fi iface: $iface"

  if ! have wpa_supplicant; then
    msg="wpa_supplicant not installed"
    if [ "$FAIL_ON_NO_WIFI" = "1" ]; then add_crit "$msg"; else add_warn "$msg"; fi
    return 0
  fi
  if ! have iw; then
    msg="iw not installed"
    if [ "$FAIL_ON_NO_WIFI" = "1" ]; then add_crit "$msg"; else add_warn "$msg"; fi
  fi

  # process check
  if is_running_procname "wpa_supplicant"; then
    add_info "wpa_supplicant running"
  else
    add_warn "wpa_supplicant not running (Wi-Fi may be down unless managed elsewhere)"
  fi

  # supervision check: svctl present?
  if have svctl; then
    if svctl "$WIFI_SERVICE_NAME" status >/dev/null 2>&1; then
      add_info "svctl $WIFI_SERVICE_NAME status OK"
    else
      add_info "svctl present but service '$WIFI_SERVICE_NAME' not configured/enabled"
    fi
  else
    add_info "svctl not present (supervision not installed/enabled)"
  fi

  # Optional SSID expectation (log-based)
  if [ -n "$WIFI_EXPECTED_SSID" ] && [ -f /var/log/sv/"$WIFI_SERVICE_NAME".log ]; then
    if grep -F "$WIFI_EXPECTED_SSID" /var/log/sv/"$WIFI_SERVICE_NAME".log >/dev/null 2>&1; then
      add_info "SSID '$WIFI_EXPECTED_SSID' seen in wifi log"
    else
      add_warn "SSID '$WIFI_EXPECTED_SSID' not seen in wifi log"
    fi
  fi
}

check_whole_system_smoke() {
  add_info "== Whole-system smoke tests =="
  # Minimal command availability
  for c in sh bash ls cat grep sed awk mount umount dmesg; do
    if have "$c"; then
      add_info "cmd: $c OK"
    else
      add_crit "missing command: $c"
    fi
  done

  # Ensure dynamic linker works
  if have /usr/bin/true; then
    /usr/bin/true >/dev/null 2>&1 && add_info "ELF runtime OK" || add_crit "ELF runtime failure"
  fi
}

write_summary() {
  add_info "== Summary =="
  if [ "$CRIT" -eq 0 ] && [ "$WARN" -eq 0 ]; then
    printf '%s\n' "READY: system appears functional." >>"$REPORT"
  elif [ "$CRIT" -eq 0 ]; then
    printf '%s\n' "NOT-READY (warnings): system works but needs attention." >>"$REPORT"
  else
    printf '%s\n' "NOT-READY (critical issues): system likely not functional." >>"$REPORT"
  fi
  printf '%s\n' "Counts: critical=$CRIT warning=$WARN info=$INFO" >>"$REPORT"
}

run_checks() {
  check_boot_artifacts
  check_mounts
  check_core_configs
  check_permissions_security
  check_services_sysv
  check_network
  check_wifi
  check_logs
  check_whole_system_smoke
  write_summary
}

run_on_current_system() {
  ts="$(now_ts)"
  REPORT="${REPORT_DIR}/${REPORT_PREFIX}-${ts}.txt"
  : > "$REPORT"
  add_info "Healthcheck report: $REPORT"
  add_info "Date: $(date 2>/dev/null || echo unknown)"
  add_info "Kernel: $(uname -r 2>/dev/null || echo unknown)"
  add_info "Hostname: $(hostname 2>/dev/null || echo unknown)"
  add_info "User: $(id 2>/dev/null || echo unknown)"
  run_checks

  # Print a short console summary
  say ""
  say "Report saved to: $REPORT"
  if [ "$CRIT" -eq 0 ] && [ "$WARN" -eq 0 ]; then
    say "READY"
    exit 0
  elif [ "$CRIT" -eq 0 ]; then
    say "NOT-READY (warnings)."
    exit 1
  else
    say "NOT-READY (critical issues)."
    exit 2
  fi
}

run_in_chroot() {
  # Copies itself into chroot and executes, writing report inside chroot.
  [ -n "$ROOT" ] || { say "ROOT not set"; exit 2; }
  [ -d "$ROOT" ] || { say "ROOT invalid: $ROOT"; exit 2; }

  # Ensure /bin/sh exists inside chroot
  if [ ! -x "$ROOT/bin/sh" ]; then
    mkdir -p "$ROOT/bin"
    ln -sf /tools/bin/bash "$ROOT/bin/sh" 2>/dev/null || true
  fi

  # Minimal VFS mounts best-effort
  for d in dev proc sys run; do [ -d "$ROOT/$d" ] || mkdir -p "$ROOT/$d"; done
  if have mount; then
    mountpoint -q "$ROOT/dev" 2>/dev/null || mount --bind /dev "$ROOT/dev" 2>/dev/null || true
    mountpoint -q "$ROOT/dev/pts" 2>/dev/null || { mkdir -p "$ROOT/dev/pts"; mount -t devpts devpts "$ROOT/dev/pts" 2>/dev/null || true; }
    mountpoint -q "$ROOT/proc" 2>/dev/null || mount -t proc proc "$ROOT/proc" 2>/dev/null || true
    mountpoint -q "$ROOT/sys" 2>/dev/null || mount -t sysfs sysfs "$ROOT/sys" 2>/dev/null || true
    mountpoint -q "$ROOT/run" 2>/dev/null || mount -t tmpfs tmpfs "$ROOT/run" 2>/dev/null || true
  fi

  # Copy script
  mkdir -p "$ROOT/.stage8"
  cp -f "$0" "$ROOT/.stage8/healthcheck.sh"
  chmod 0755 "$ROOT/.stage8/healthcheck.sh"

  chroot "$ROOT" /usr/bin/env -i HOME=/root TERM="${TERM:-xterm}" PATH=/usr/bin:/usr/sbin:/bin:/sbin:/tools/bin \
    /bin/sh -c "/.stage8/healthcheck.sh"
}

main() {
  if [ -n "$ROOT" ]; then
    run_in_chroot
  else
    run_on_current_system
  fi
}

main "$@"
