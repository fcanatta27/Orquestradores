# srcpkg — gerenciador simples de pacotes source (POSIX sh)

`srcpkg` é um gerenciador minimalista para sistemas no estilo LFS, pensado para:
- instalar programas a partir de **receitas** (`.rcp`)
- manter um **manifest** por pacote (lista de arquivos instalados)
- permitir **remoção** segura baseada no manifest
- logs completos e reprodutibilidade básica

Ele é propositalmente simples: não tenta resolver dependências automaticamente (mas permite declarar `DEPENDS` de forma informativa).

## Instalação do srcpkg
Copie `srcpkg` para um diretório no PATH:

```sh
install -m 0755 srcpkg /usr/sbin/srcpkg
```

ou:

```sh
cp -f srcpkg /usr/sbin/srcpkg
chmod 0755 /usr/sbin/srcpkg
```

## Inicializar o banco
```sh
srcpkg init
```

Estrutura padrão:
- `/var/lib/srcpkg/pkgs`  (metadados e manifests)
- `/var/lib/srcpkg/src`   (cache de tarballs)
- `/var/lib/srcpkg/build` (build trees e destdir)
- `/var/lib/srcpkg/logs`  (logs de build)

## Comandos

### `srcpkg install <recipe.rcp>`
Baixa, verifica hash, extrai, compila, instala e registra manifest.

### `srcpkg upgrade <recipe.rcp>`
Instala a versão nova (não remove automaticamente a antiga).

### `srcpkg remove <name-version>`
Remove arquivos instalados usando o manifest.

### `srcpkg list`
Lista pacotes instalados (`NAME-VERSION`).

### `srcpkg info <name-version>`
Mostra metadados (url, hash, depends, installed_at).

### `srcpkg clean <name-version>`
Remove apenas o diretório de build (`/var/lib/srcpkg/build/<name-version>`).

## Formato da receita (.rcp)

Receita é um arquivo de texto com linhas `KEY=VALUE`:

Obrigatórios:
- `NAME`
- `VERSION`
- `URL`
- `SHA256` (ou `SHA512`)

Opcionais:
- `ARCHIVE` (padrão: basename do URL)
- `DIR` (padrão: nome do diretório após extrair)
- `DEPENDS="foo bar"` (informativo)
- `PATCHES="/caminho/p1.patch /caminho/p2.patch"`
- `ENV="CC=clang CFLAGS=-O2"` (pares KEY=VAL separados por espaço)
- `CONFIGURE="..."` (default: `./configure --prefix=/usr` se existir `configure`)
- `BUILD="..."` (default: `make`)
- `INSTALL="..."` (default: `make install`)
- `CLEAN="..."` (opcional)

### Exemplo: zlib

```sh
NAME=zlib
VERSION=1.3.1
URL=https://zlib.net/zlib-1.3.1.tar.gz
SHA256=38ef96b8aa1c8d7d7b2f0dff78eaefdd8f3d93f0d0c78e5ef2e6e3b3b4c85d2e
CONFIGURE="./configure --prefix=/usr"
BUILD="make"
INSTALL="make install"
```

### Exemplo: pacote com patch
```sh
NAME=foo
VERSION=2.0
URL=https://example.org/foo-2.0.tar.xz
SHA256=<...>
PATCHES="/root/patches/foo-fix.patch"
```

## Modelo de instalação (DESTDIR)
O `srcpkg` usa um *staging* (`DESTDIR`) para capturar o manifest com segurança e depois copia para `/` preservando permissões/links via `tar | tar`.

## Segurança e limites (por design)
- Não modifica GRUB/partições/kernel.
- Não resolve dependências automaticamente.
- Receita é entrada confiável (é “código”, pois executa comandos). Use receitas próprias/curadas.

## Dicas para manter atualizado
- crie receitas novas para versões novas
- use `srcpkg upgrade nova-versao.rcp`
- rode testes e então remova a versão antiga com `srcpkg remove oldname-oldver`
