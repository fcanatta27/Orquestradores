# Análise técnica do srcpkg

## 1) Modelo de dados e reversibilidade
- Cada instalação gera `manifest.txt` a partir do DESTDIR staging.
- A remoção usa esse manifest e tenta remover diretórios vazios no final.
- Isso reduz o risco de “remover demais”, pois só remove o que foi instalado pelo pacote.

## 2) Segurança: decisões e mitigação
- `need_root` impede installs/removes sem root (configurável).
- `rm` ignora diretórios top-level críticos por regra (bin, lib, usr, etc).
- `DESTDIR` evita que `make install` escreva diretamente no sistema sem rastreamento.

## 3) Hash e integridade
- Suporta sha256/sha512 via `sha256sum/sha512sum` ou `openssl dgst`.
- Falha imediatamente em mismatch.

## 4) POSIX e portabilidade
- Script 100% sh POSIX (sem bashisms).
- Não depende de Python/Perl; usa ferramentas comuns (tar, awk, sed).
- `tac` não é POSIX; foi implementado fallback por `awk`.

## 5) Bugs reais evitados / corrigidos
- Remoção: evita apagar diretórios críticos no root.
- Manifest: inclui arquivos, links e dirs para permitir limpeza progressiva.
- Logs: toda execução de build é capturada em log por pacote.

## 6) Limitações inevitáveis
- Receitas executam comandos arbitrários: isso é inerente ao modelo source-based.
- Alguns pacotes não suportam DESTDIR corretamente; nesses casos, ajuste INSTALL na receita.
