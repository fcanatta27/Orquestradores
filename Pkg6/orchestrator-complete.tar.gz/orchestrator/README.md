# Stage7 — pós-boot e conveniência CLI

Inclui:
- /etc/fstab (UUID recomendado)
- hostname + hosts
- locales com localedef (glibc) e defaults em /etc/profile.d
- console (/etc/sysconfig/console)
- usuário + wheel + sudoers
- logrotate + políticas para boot.log e logs de supervisão
- cronie: init script + jobs (logrotate diário, seedrng-save horário)
- seedrng: seed no boot + save no shutdown (+ save horário)
- verificação de serviços no boot (log em /var/log/boot.log)

## Uso

```sh
tar -xzf stage7-postboot-cli.tar.gz
cd stage7-postboot-cli
chmod +x stage7-postboot-cli.sh
sudo ./stage7-postboot-cli.sh
```

## Após o primeiro boot
- Defina senha do usuário criado:
```sh
passwd user
```
