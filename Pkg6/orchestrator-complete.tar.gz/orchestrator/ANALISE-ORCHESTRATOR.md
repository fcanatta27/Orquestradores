# Análise (Orchestrator) — correção, retomada e performance

## 1) Retomada
- Implementada via arquivos `.done` por stage.
- Logs separados por stage (stdout/stderr/meta).

## 2) Paralelismo
- Implementado por `MAKEFLAGS=-jN`.
- N é auto-detectado por `nproc` e multiplicador conservador (cap em 32).
- Não altera flags internas dos pacotes; só fornece defaults.

## 3) Integridade e segurança
- Checks de espaço livre em ROOT e SOURCES_DIR.
- Executa como root (necessário para mount/chroot/install).
- Não executa ações perigosas diretamente (grub-install, partições); delega aos stages.

## 4) Compatibilidade POSIX
- Script em /bin/sh, sem bashisms, validado com `sh -n`.

## 5) Pontos que permanecem manuais por design
- Inputs específicos do seu disco/rede (UUIDs, GRUB_DISK etc.) continuam nos scripts de stage correspondentes.
- O orquestrador não tenta “adivinhar” essas variáveis para evitar destruição de disco.
