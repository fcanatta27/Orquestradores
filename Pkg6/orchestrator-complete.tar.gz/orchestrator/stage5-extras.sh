#!/bin/sh
# stage5-extras.sh
# Stage5: build missing "system completion" packages (device management, networking, admin tools)
# inside the chrooted system created by Stage2/Stage3.
#
# Focus:
# - eudev (udev)
# - dhcpcd (DHCP client)
# - wpa_supplicant + iw (Wi-Fi)
# - pciutils, usbutils
# - sudo, logrotate, cronie
# - lsof, strace, which
# - groff + libpipeline + gdbm + man-db (man infrastructure)
#
# This script downloads sources using the LFS stable wget-list + md5sums, verifies md5,
# mounts VFS, enters chroot and builds/install packages with per-step logs and validations.
#
# POSIX sh only. Variables at top.
#
# License: MIT (see LICENSE)

###############################################################################
# User-configurable variables
###############################################################################
ROOT="/mnt/rootfs"
TOOLS="${ROOT}/tools"

LFS_STABLE_BASE="https://www.linuxfromscratch.org/lfs/downloads/stable"

WORKDIR="${ROOT}/.stage5-build"
SRCDIR="${WORKDIR}/sources"
LOGDIR="${WORKDIR}/logs"

JOBS="$(getconf _NPROCESSORS_ONLN 2>/dev/null || echo 1)"
MAKEFLAGS="-j${JOBS}"

ALLOW_ROOT="1"
MOUNT_VFS="1"
KEEP_WORKDIR="0"

# Packages to fetch from LFS stable lists (prefix match).
# Note: some packages (e.g., wpa_supplicant, dhcpcd, eudev) are in BLFS for some versions.
# The script will try to resolve via wget-list; if not found, it will stop with a clear error.
PKG_PREFIXES="
  eudev-
  dhcpcd-
  openssl-
  libnl-
  wpa_supplicant-
  iw-
  pciutils-
  usbutils-
  libusb-
  sudo-
  logrotate-
  cronie-
  popt-
  groff-
  libpipeline-
  gdbm-
  man-db-
  lsof-
  strace-
  which-
"

###############################################################################
set -eu
umask 022
IFS="$(printf ' \t\n')"
export LC_ALL=C

say(){ printf '%s\n' "$*"; }
die(){ printf 'ERROR: %s\n' "$*" >&2; exit 1; }
have(){ command -v "$1" >/dev/null 2>&1; }
need(){ command -v "$1" >/dev/null 2>&1 || die "missing required command: $1"; }
mkdirp(){ [ -d "$1" ] || mkdir -p "$1"; }

as_root() {
  if [ "$(id -u)" -eq 0 ] && [ "${ALLOW_ROOT}" != "1" ]; then
    die "refusing to run as root (ALLOW_ROOT=0)"
  fi
  [ "$(id -u)" -eq 0 ] || die "stage5 requires root (mounts + chroot)"
}

fetch() {
  url="$1"; out="$2"
  [ -f "$out" ] && return 0
  if have curl; then
    curl -L --fail --retry 3 --retry-delay 2 -o "$out".tmp "$url"
  elif have wget; then
    wget -O "$out".tmp "$url"
  else
    die "need curl or wget"
  fi
  mv "$out".tmp "$out"
}

md5_file() {
  f="$1"
  if have md5sum; then md5sum "$f" | awk '{print $1}'
  elif have md5; then md5 -q "$f"
  else die "need md5sum (recommended) or md5"
  fi
}

verify_md5() {
  f="$1"; expected="$2"
  got="$(md5_file "$f")"
  [ "$got" = "$expected" ] || die "md5 mismatch for $(basename "$f"): expected $expected got $got"
}

ensure_lfs_lists() {
  mkdirp "$SRCDIR"
  cd "$SRCDIR"
  fetch "${LFS_STABLE_BASE}/wget-list" "wget-list"
  fetch "${LFS_STABLE_BASE}/md5sums" "md5sums"
}

resolve_tarball() {
  prefix="$1"
  ensure_lfs_lists
  cd "$SRCDIR"
  tb="$(awk -v p="$prefix" '$0 ~ ("/" p) {sub(".*/","",$0); print $0}' wget-list | head -n 1)"
  [ -n "$tb" ] || die "could not resolve tarball for prefix: $prefix (not in LFS stable wget-list)"
  printf '%s\n' "$tb"
}

download_pkg() {
  tarball="$1"
  ensure_lfs_lists
  cd "$SRCDIR"
  url="$(awk -v t="$tarball" '$0 ~ ("/" t "$") {print $0}' wget-list | head -n 1)"
  [ -n "$url" ] || die "tarball not found in LFS wget-list: $tarball"
  fetch "$url" "$tarball"
  expected="$(awk -v t="$tarball" '$2==t {print $1}' md5sums | head -n 1)"
  [ -n "$expected" ] || die "md5 not found in LFS md5sums for: $tarball"
  verify_md5 "$tarball" "$expected"
}

is_mounted() {
  mp="$1"
  if have mountpoint; then
    mountpoint -q "$mp" 2>/dev/null
  else
    [ -r /proc/mounts ] && awk -v m="$mp" '$2==m{f=1} END{exit(f?0:1)}' /proc/mounts
  fi
}

mount_vfs() {
  [ "${MOUNT_VFS}" = "1" ] || return 0
  mkdirp "$ROOT/dev" "$ROOT/proc" "$ROOT/sys" "$ROOT/run"
  is_mounted "$ROOT/dev" || mount --bind /dev "$ROOT/dev"
  is_mounted "$ROOT/dev/pts" || { mkdirp "$ROOT/dev/pts"; mount -t devpts devpts "$ROOT/dev/pts"; }
  is_mounted "$ROOT/proc" || mount -t proc proc "$ROOT/proc"
  is_mounted "$ROOT/sys" || mount -t sysfs sysfs "$ROOT/sys"
  is_mounted "$ROOT/run" || mount -t tmpfs tmpfs "$ROOT/run"
}

umount_vfs() {
  [ "${MOUNT_VFS}" = "1" ] || return 0
  umount -l "$ROOT/dev/pts" 2>/dev/null || true
  umount -l "$ROOT/dev" 2>/dev/null || true
  umount -l "$ROOT/proc" 2>/dev/null || true
  umount -l "$ROOT/sys" 2>/dev/null || true
  umount -l "$ROOT/run" 2>/dev/null || true
}

write_chroot_script() {
  mkdirp "$WORKDIR" "$LOGDIR" "$SRCDIR"
  cat > "${ROOT}/.stage5-build/stage5-chroot.sh" <<'EOF'
set -eu
umask 022
export LC_ALL=C

say(){ printf '%s\n' "$*"; }
die(){ printf 'ERROR: %s\n' "$*" >&2; exit 1; }
need(){ command -v "$1" >/dev/null 2>&1 || die "missing: $1"; }

WORKDIR="/.stage5-build"
SRCDIR="${WORKDIR}/sources"
BUILDDIR="${WORKDIR}/build"
LOGDIR="${WORKDIR}/logs-chroot"
JOBS="$(getconf _NPROCESSORS_ONLN 2>/dev/null || echo 1)"
MAKEFLAGS="-j${JOBS}"

mkdir -p "$BUILDDIR/src" "$LOGDIR"

run_logged(){
  name="$1"; shift
  logfile="${LOGDIR}/${name}.log"
  say "==> $name"
  ( "$@" ) >"$logfile" 2>&1 || die "$name failed; see $logfile"
}

extract_clean(){
  tb="$1"
  cd "$BUILDDIR/src"
  top="$(tar -tf "$SRCDIR/$tb" | awk -F/ 'NR==1{print $1}')"
  [ -n "$top" ] || die "cannot determine top dir for $tb"
  rm -rf "$top"
  tar -xf "$SRCDIR/$tb"
  printf '%s\n' "$BUILDDIR/src/$top"
}

export PATH=/usr/bin:/usr/sbin:/bin:/sbin:/tools/bin

need sh; need make; need tar; need awk; need sed; need grep
need gcc; need ld; need ar

# --------------- Dependencies first ---------------

build_openssl(){
  tb="$(ls "$SRCDIR"/openssl-*.tar.* 2>/dev/null | head -n 1 | sed 's#.*/##')"
  [ -n "$tb" ] || die "openssl tarball missing"
  src="$(extract_clean "$tb")"
  run_logged "openssl-configure" sh -c "cd '$src' && ./Configure --prefix=/usr --openssldir=/etc/ssl linux-x86_64"
  run_logged "openssl-make" sh -c "cd '$src' && make ${MAKEFLAGS}"
  run_logged "openssl-test" sh -c "cd '$src' && make test >/dev/null 2>&1 || true"
  run_logged "openssl-install" sh -c "cd '$src' && make install_sw install_ssldirs"
  run_logged "openssl-validate" sh -c "/usr/bin/openssl version >/dev/null 2>&1"
}

build_libnl(){
  tb="$(ls "$SRCDIR"/libnl-*.tar.* 2>/dev/null | head -n 1 | sed 's#.*/##')"
  [ -n "$tb" ] || die "libnl tarball missing"
  src="$(extract_clean "$tb")"
  b="${BUILDDIR}/build-libnl"; rm -rf "$b"; mkdir -p "$b"
  run_logged "libnl-configure" sh -c "cd '$b' && '$src/configure' --prefix=/usr --sysconfdir=/etc --disable-static"
  run_logged "libnl-make" sh -c "cd '$b' && make ${MAKEFLAGS}"
  run_logged "libnl-install" sh -c "cd '$b' && make install"
  run_logged "libnl-validate" sh -c "test -f /usr/lib/libnl-3.so || test -f /usr/lib64/libnl-3.so"
}

build_libusb(){
  tb="$(ls "$SRCDIR"/libusb-*.tar.* 2>/dev/null | head -n 1 | sed 's#.*/##')"
  [ -n "$tb" ] || die "libusb tarball missing"
  src="$(extract_clean "$tb")"
  b="${BUILDDIR}/build-libusb"; rm -rf "$b"; mkdir -p "$b"
  run_logged "libusb-configure" sh -c "cd '$b' && '$src/configure' --prefix=/usr --disable-static"
  run_logged "libusb-make" sh -c "cd '$b' && make ${MAKEFLAGS}"
  run_logged "libusb-install" sh -c "cd '$b' && make install"
  run_logged "libusb-validate" sh -c "test -f /usr/lib/libusb-1.0.so || test -f /usr/lib64/libusb-1.0.so"
}

build_popt(){
  tb="$(ls "$SRCDIR"/popt-*.tar.* 2>/dev/null | head -n 1 | sed 's#.*/##')"
  [ -n "$tb" ] || die "popt tarball missing"
  src="$(extract_clean "$tb")"
  b="${BUILDDIR}/build-popt"; rm -rf "$b"; mkdir -p "$b"
  run_logged "popt-configure" sh -c "cd '$b' && '$src/configure' --prefix=/usr --disable-static"
  run_logged "popt-make" sh -c "cd '$b' && make ${MAKEFLAGS}"
  run_logged "popt-install" sh -c "cd '$b' && make install"
  run_logged "popt-validate" sh -c "test -f /usr/lib/libpopt.so || test -f /usr/lib64/libpopt.so"
}

build_gdbm(){
  tb="$(ls "$SRCDIR"/gdbm-*.tar.* 2>/dev/null | head -n 1 | sed 's#.*/##')"
  [ -n "$tb" ] || die "gdbm tarball missing"
  src="$(extract_clean "$tb")"
  b="${BUILDDIR}/build-gdbm"; rm -rf "$b"; mkdir -p "$b"
  run_logged "gdbm-configure" sh -c "cd '$b' && '$src/configure' --prefix=/usr --disable-static"
  run_logged "gdbm-make" sh -c "cd '$b' && make ${MAKEFLAGS}"
  run_logged "gdbm-install" sh -c "cd '$b' && make install"
  run_logged "gdbm-validate" sh -c "test -f /usr/lib/libgdbm.so || test -f /usr/lib64/libgdbm.so"
}

build_libpipeline(){
  tb="$(ls "$SRCDIR"/libpipeline-*.tar.* 2>/dev/null | head -n 1 | sed 's#.*/##')"
  [ -n "$tb" ] || die "libpipeline tarball missing"
  src="$(extract_clean "$tb")"
  b="${BUILDDIR}/build-libpipeline"; rm -rf "$b"; mkdir -p "$b"
  run_logged "libpipeline-configure" sh -c "cd '$b' && '$src/configure' --prefix=/usr --disable-static"
  run_logged "libpipeline-make" sh -c "cd '$b' && make ${MAKEFLAGS}"
  run_logged "libpipeline-install" sh -c "cd '$b' && make install"
  run_logged "libpipeline-validate" sh -c "test -f /usr/lib/libpipeline.so || test -f /usr/lib64/libpipeline.so"
}

build_groff(){
  tb="$(ls "$SRCDIR"/groff-*.tar.* 2>/dev/null | head -n 1 | sed 's#.*/##')"
  [ -n "$tb" ] || die "groff tarball missing"
  src="$(extract_clean "$tb")"
  b="${BUILDDIR}/build-groff"; rm -rf "$b"; mkdir -p "$b"
  run_logged "groff-configure" sh -c "cd '$b' && '$src/configure' --prefix=/usr"
  run_logged "groff-make" sh -c "cd '$b' && make ${MAKEFLAGS}"
  run_logged "groff-install" sh -c "cd '$b' && make install"
  run_logged "groff-validate" sh -c "/usr/bin/groff --version >/dev/null 2>&1"
}

# --------------- Core requested packages ---------------

build_eudev(){
  tb="$(ls "$SRCDIR"/eudev-*.tar.* 2>/dev/null | head -n 1 | sed 's#.*/##')"
  [ -n "$tb" ] || die "eudev tarball missing"
  src="$(extract_clean "$tb")"
  b="${BUILDDIR}/build-eudev"; rm -rf "$b"; mkdir -p "$b"
  run_logged "eudev-configure" sh -c "cd '$b' && '$src/configure' --prefix=/usr --sysconfdir=/etc --sbindir=/usr/sbin --enable-manpages"
  run_logged "eudev-make" sh -c "cd '$b' && make ${MAKEFLAGS}"
  run_logged "eudev-install" sh -c "cd '$b' && make install"
  run_logged "eudev-validate" sh -c "command -v udevadm >/dev/null 2>&1"
}

build_dhcpcd(){
  tb="$(ls "$SRCDIR"/dhcpcd-*.tar.* 2>/dev/null | head -n 1 | sed 's#.*/##')"
  [ -n "$tb" ] || die "dhcpcd tarball missing"
  src="$(extract_clean "$tb")"
  run_logged "dhcpcd-configure" sh -c "cd '$src' && ./configure --prefix=/usr --sysconfdir=/etc"
  run_logged "dhcpcd-make" sh -c "cd '$src' && make ${MAKEFLAGS}"
  run_logged "dhcpcd-install" sh -c "cd '$src' && make install"
  run_logged "dhcpcd-validate" sh -c "/usr/sbin/dhcpcd --version >/dev/null 2>&1"
}

build_wpa_supplicant(){
  tb="$(ls "$SRCDIR"/wpa_supplicant-*.tar.* 2>/dev/null | head -n 1 | sed 's#.*/##')"
  [ -n "$tb" ] || die "wpa_supplicant tarball missing"
  src="$(extract_clean "$tb")"
  # Build with OpenSSL + nl80211
  run_logged "wpa-config" sh -c "cd '$src/wpa_supplicant' && cp -f defconfig .config && printf '%s\n' 'CONFIG_TLS=openssl' 'CONFIG_TLSV12=y' 'CONFIG_DRIVER_NL80211=y' 'CONFIG_LIBNL32=y' >>.config"
  run_logged "wpa-make" sh -c "cd '$src/wpa_supplicant' && make ${MAKEFLAGS} BINDIR=/usr/sbin"
  run_logged "wpa-install" sh -c "cd '$src/wpa_supplicant' && install -v -m755 wpa_supplicant /usr/sbin/ && install -v -m755 wpa_cli /usr/sbin/ || true"
  run_logged "wpa-validate" sh -c "/usr/sbin/wpa_supplicant -v >/dev/null 2>&1 || /usr/sbin/wpa_supplicant -h >/dev/null 2>&1"
}

build_iw(){
  tb="$(ls "$SRCDIR"/iw-*.tar.* 2>/dev/null | head -n 1 | sed 's#.*/##')"
  [ -n "$tb" ] || die "iw tarball missing"
  src="$(extract_clean "$tb")"
  run_logged "iw-make" sh -c "cd '$src' && make ${MAKEFLAGS}"
  run_logged "iw-install" sh -c "cd '$src' && make PREFIX=/usr install"
  run_logged "iw-validate" sh -c "/usr/sbin/iw --version >/dev/null 2>&1 || /usr/sbin/iw help >/dev/null 2>&1"
}

build_pciutils(){
  tb="$(ls "$SRCDIR"/pciutils-*.tar.* 2>/dev/null | head -n 1 | sed 's#.*/##')"
  [ -n "$tb" ] || die "pciutils tarball missing"
  src="$(extract_clean "$tb")"
  run_logged "pciutils-make" sh -c "cd '$src' && make ${MAKEFLAGS} PREFIX=/usr ZLIB=yes DNS=yes"
  run_logged "pciutils-install" sh -c "cd '$src' && make PREFIX=/usr install"
  run_logged "pciutils-validate" sh -c "/usr/sbin/lspci -v >/dev/null 2>&1 || true"
}

build_usbutils(){
  tb="$(ls "$SRCDIR"/usbutils-*.tar.* 2>/dev/null | head -n 1 | sed 's#.*/##')"
  [ -n "$tb" ] || die "usbutils tarball missing"
  src="$(extract_clean "$tb")"
  b="${BUILDDIR}/build-usbutils"; rm -rf "$b"; mkdir -p "$b"
  run_logged "usbutils-configure" sh -c "cd '$b' && '$src/configure' --prefix=/usr"
  run_logged "usbutils-make" sh -c "cd '$b' && make ${MAKEFLAGS}"
  run_logged "usbutils-install" sh -c "cd '$b' && make install"
  run_logged "usbutils-validate" sh -c "/usr/bin/lsusb --version >/dev/null 2>&1 || true"
}

build_sudo(){
  tb="$(ls "$SRCDIR"/sudo-*.tar.* 2>/dev/null | head -n 1 | sed 's#.*/##')"
  [ -n "$tb" ] || die "sudo tarball missing"
  src="$(extract_clean "$tb")"
  b="${BUILDDIR}/build-sudo"; rm -rf "$b"; mkdir -p "$b"
  run_logged "sudo-configure" sh -c "cd '$b' && '$src/configure' --prefix=/usr --sysconfdir=/etc --with-all-insults --without-pam --disable-static"
  run_logged "sudo-make" sh -c "cd '$b' && make ${MAKEFLAGS}"
  run_logged "sudo-install" sh -c "cd '$b' && make install"
  run_logged "sudo-validate" sh -c "/usr/bin/sudo -V >/dev/null 2>&1"
}

build_logrotate(){
  tb="$(ls "$SRCDIR"/logrotate-*.tar.* 2>/dev/null | head -n 1 | sed 's#.*/##')"
  [ -n "$tb" ] || die "logrotate tarball missing"
  src="$(extract_clean "$tb")"
  run_logged "logrotate-make" sh -c "cd '$src' && make ${MAKEFLAGS}"
  run_logged "logrotate-install" sh -c "cd '$src' && make PREFIX=/usr install"
  run_logged "logrotate-validate" sh -c "/usr/sbin/logrotate --version >/dev/null 2>&1"
}

build_cronie(){
  tb="$(ls "$SRCDIR"/cronie-*.tar.* 2>/dev/null | head -n 1 | sed 's#.*/##')"
  [ -n "$tb" ] || die "cronie tarball missing"
  src="$(extract_clean "$tb")"
  b="${BUILDDIR}/build-cronie"; rm -rf "$b"; mkdir -p "$b"
  run_logged "cronie-configure" sh -c "cd '$b' && '$src/configure' --prefix=/usr --sysconfdir=/etc --without-pam"
  run_logged "cronie-make" sh -c "cd '$b' && make ${MAKEFLAGS}"
  run_logged "cronie-install" sh -c "cd '$b' && make install"
  run_logged "cronie-validate" sh -c "/usr/sbin/cron -V >/dev/null 2>&1 || true"
}

build_man_db(){
  tb="$(ls "$SRCDIR"/man-db-*.tar.* 2>/dev/null | head -n 1 | sed 's#.*/##')"
  [ -n "$tb" ] || die "man-db tarball missing"
  src="$(extract_clean "$tb")"
  b="${BUILDDIR}/build-man-db"; rm -rf "$b"; mkdir -p "$b"
  run_logged "man-db-configure" sh -c "cd '$b' && '$src/configure' --prefix=/usr --sysconfdir=/etc --disable-setuid --with-browser=/usr/bin/less --with-vgrind=/usr/bin/vgrind --with-grap=/usr/bin/grap"
  run_logged "man-db-make" sh -c "cd '$b' && make ${MAKEFLAGS}"
  run_logged "man-db-install" sh -c "cd '$b' && make install"
  run_logged "man-db-validate" sh -c "/usr/bin/man --version >/dev/null 2>&1 || true"
}

build_lsof(){
  tb="$(ls "$SRCDIR"/lsof-*.tar.* 2>/dev/null | head -n 1 | sed 's#.*/##')"
  [ -n "$tb" ] || die "lsof tarball missing"
  src="$(extract_clean "$tb")"
  # lsof uses Configure script
  run_logged "lsof-build" sh -c "cd '$src' && ./Configure -n linux >/dev/null 2>&1 && make ${MAKEFLAGS}"
  run_logged "lsof-install" sh -c "cd '$src' && install -m755 lsof /usr/bin/lsof"
  run_logged "lsof-validate" sh -c "/usr/bin/lsof -v >/dev/null 2>&1 || true"
}

build_strace(){
  tb="$(ls "$SRCDIR"/strace-*.tar.* 2>/dev/null | head -n 1 | sed 's#.*/##')"
  [ -n "$tb" ] || die "strace tarball missing"
  src="$(extract_clean "$tb")"
  b="${BUILDDIR}/build-strace"; rm -rf "$b"; mkdir -p "$b"
  run_logged "strace-configure" sh -c "cd '$b' && '$src/configure' --prefix=/usr --disable-static"
  run_logged "strace-make" sh -c "cd '$b' && make ${MAKEFLAGS}"
  run_logged "strace-install" sh -c "cd '$b' && make install"
  run_logged "strace-validate" sh -c "/usr/bin/strace -V >/dev/null 2>&1"
}

build_which(){
  tb="$(ls "$SRCDIR"/which-*.tar.* 2>/dev/null | head -n 1 | sed 's#.*/##')"
  [ -n "$tb" ] || die "which tarball missing"
  src="$(extract_clean "$tb")"
  b="${BUILDDIR}/build-which"; rm -rf "$b"; mkdir -p "$b"
  run_logged "which-configure" sh -c "cd '$b' && '$src/configure' --prefix=/usr"
  run_logged "which-make" sh -c "cd '$b' && make ${MAKEFLAGS}"
  run_logged "which-install" sh -c "cd '$b' && make install"
  run_logged "which-validate" sh -c "/usr/bin/which --version >/dev/null 2>&1 || true"
}

final_sanity(){
  run_logged "sanity-udev" sh -c "command -v udevadm >/dev/null 2>&1"
  run_logged "sanity-dhcpcd" sh -c "/usr/sbin/dhcpcd --version >/dev/null 2>&1"
  run_logged "sanity-wifi-tools" sh -c "test -x /usr/sbin/wpa_supplicant && test -x /usr/sbin/iw || true"
  run_logged "sanity-sudo" sh -c "/usr/bin/sudo -V >/dev/null 2>&1"
}

say "==> Stage5 starting (extras)"

build_openssl
build_libnl
build_libusb
build_popt
build_gdbm
build_libpipeline
build_groff

build_eudev
build_dhcpcd
build_wpa_supplicant
build_iw
build_pciutils
build_usbutils
build_sudo
build_logrotate
build_cronie
build_man_db
build_lsof
build_strace
build_which

final_sanity

say "==> Stage5 complete. Logs: $LOGDIR"
EOF
  chmod 0755 "${ROOT}/.stage5-build/stage5-chroot.sh"
}

run_stage5() {
  write_chroot_script
  chroot "$ROOT" /usr/bin/env -i \
    HOME=/root TERM="${TERM:-xterm}" PS1='(stage5) \u:\w\$ ' \
    PATH=/usr/bin:/usr/sbin:/bin:/sbin:/tools/bin \
    /bin/sh -c "/.stage5-build/stage5-chroot.sh"
}

###############################################################################
# Main
###############################################################################
need sh; need awk; need sed; need tar; need mount; need umount; need chroot

as_root

mkdirp "$WORKDIR" "$SRCDIR" "$LOGDIR"

# Ensure /tools is visible inside ROOT, and /bin/sh exists for chroot
[ -e "$ROOT/tools" ] || ln -sfn "$TOOLS" "$ROOT/tools" 2>/dev/null || true
if [ ! -x "$ROOT/bin/sh" ]; then
  mkdirp "$ROOT/bin"
  ln -sf /tools/bin/bash "$ROOT/bin/sh"
fi

# Download all required tarballs before entering chroot.
for p in $PKG_PREFIXES; do
  tb="$(resolve_tarball "$p")"
  download_pkg "$tb"
done

trap umount_vfs EXIT INT TERM HUP
mount_vfs
run_stage5

say "==> SUCCESS: Stage5 finished."
say "Chroot logs: ${ROOT}/.stage5-build/logs-chroot"
