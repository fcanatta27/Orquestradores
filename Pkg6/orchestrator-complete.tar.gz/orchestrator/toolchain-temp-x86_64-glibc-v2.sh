#!/bin/sh
# toolchain-temp-x86_64-glibc.sh
# POSIX shell script to build a temporary x86_64 toolchain (binutils+gcc+glibc+libstdc++)
# into a dedicated prefix (TOOLS) under a rootfs tree (ROOT).
#
# This follows the well-known staged approach used by Linux From Scratch (LFS)-style builds:
# 1) cross binutils
# 2) minimal cross gcc (C only)
# 3) linux headers into $ROOT/usr/include
# 4) glibc into $TOOLS/$TARGET
# 5) libstdc++ into $TOOLS/$TARGET
#
# License: MIT (see LICENSE file in the package).

###############################################################################
# User-configurable variables (edit here only)
###############################################################################
ROOT="/mnt/rootfs"
TOOLS="${ROOT}/tools"
TARGET="x86_64-lfs-linux-gnu"

# Build workspace (will be created). Keep it OUTSIDE of ROOT/TOOLS.
WORKDIR="${ROOT}/.toolchain-build"
SRCDIR="${WORKDIR}/sources"
BUILDDIR="${WORKDIR}/build"
LOGDIR="${WORKDIR}/logs"

# Versions (as of 2026-01-02; update together with checksums below)
BINUTILS_VER="2.45.1"
GCC_VER="15.2.0"
GLIBC_VER="2.42"
LINUX_VER="6.18.3"

# Download base URLs (official mirrors where possible)
GNU_MIRROR="https://ftpmirror.gnu.org/gnu"
KERNEL_MIRROR="https://cdn.kernel.org/pub/linux/kernel"

# Tarballs
BINUTILS_TARBALL="binutils-${BINUTILS_VER}.tar.xz"
GCC_TARBALL="gcc-${GCC_VER}.tar.xz"
GLIBC_TARBALL="glibc-${GLIBC_VER}.tar.xz"
LINUX_TARBALL="linux-${LINUX_VER}.tar.xz"

BINUTILS_URL="${GNU_MIRROR}/binutils/${BINUTILS_TARBALL}"
GCC_URL="${GNU_MIRROR}/gcc/gcc-${GCC_VER}/${GCC_TARBALL}"
GLIBC_URL="${GNU_MIRROR}/libc/${GLIBC_TARBALL}"
# Kernel tarballs are in v6.x for 6.18.y
LINUX_URL="${KERNEL_MIRROR}/v6.x/${LINUX_TARBALL}"

# SHA-256 checksums for tarballs (defense-in-depth).
# Note: these values must match the exact files downloaded above.
BINUTILS_SHA256="5fe101e6fe9d18fdec95962d81ed670fdee5f37e3f48f0bef87bddf862513aa5"
GCC_SHA256="438fd996826b0c82485a29da03a72d71d6e3541a83ec702df4271f6fe025d24e"
GLIBC_SHA256="d1775e32e4628e64ef930f435b67bb63af7599acb6be2b335b9f19f16509f17f"
# Linux sha256 varies per point release; we fetch and verify against kernel.org sha256 list.
# If you prefer pinning, set LINUX_SHA256 to the expected value and set VERIFY_LINUX_SHA256LIST=0.
LINUX_SHA256=""
VERIFY_LINUX_SHA256LIST="1"  # uses kernel.org sha256sums.asc (signed list; we verify the hash lines)

# Build parallelism (POSIX-safe)
JOBS="$(getconf _NPROCESSORS_ONLN 2>/dev/null || echo 1)"

# Toolchain build tuning (keep conservative)
MAKEFLAGS="-j${JOBS}"
# Recommended glibc baseline kernel for runtime compatibility; must be <= your target system kernel.
# 4.19 is a common conservative baseline for x86_64; adjust if you need older/newer.
GLIBC_ENABLE_KERNEL="4.19"

# Safety toggles
KEEP_WORKDIR="0"     # 1 = do not delete build trees after success
ALLOW_ROOT="1"       # 0 = refuse to run as root (recommended to build as unprivileged user)
###############################################################################

set -eu

# Hardened defaults
umask 022
IFS="$(printf ' \t\n')"

###############################################################################
# Helpers
###############################################################################
say() { printf '%s\n' "$*"; }
die() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }

need_cmd() {
  command -v "$1" >/dev/null 2>&1 || die "missing required command: $1"
}

as_user_warning() {
  if [ "$(id -u)" -eq 0 ] && [ "${ALLOW_ROOT}" != "1" ]; then
    die "refusing to run as root (ALLOW_ROOT=0). Run as an unprivileged build user with write access to ${ROOT}."
  fi
  if [ "$(id -u)" -eq 0 ]; then
    say "WARNING: running as root. For best isolation, prefer an unprivileged build user."
  fi
}

mkdirp() { [ -d "$1" ] || mkdir -p "$1"; }

cleanup_on_fail() {
  code=$?
  if [ $code -ne 0 ]; then
    say "Build failed. Logs (if any) are in: ${LOGDIR}"
    say "Workspace kept at: ${WORKDIR}"
  fi
  exit $code
}

trap cleanup_on_fail INT TERM HUP

have() { command -v "$1" >/dev/null 2>&1; }

fetch() {
  url="$1"
  out="$2"
  if [ -f "$out" ]; then
    return 0
  fi
  if have curl; then
    curl -L --fail --retry 3 --retry-delay 2 -o "$out".tmp "$url"
  elif have wget; then
    wget -O "$out".tmp "$url"
  else
    die "need curl or wget to download sources"
  fi
  mv "$out".tmp "$out"
}

sha256_file() {
  f="$1"
  if have sha256sum; then
    sha256sum "$f" | awk '{print $1}'
  elif have shasum; then
    shasum -a 256 "$f" | awk '{print $1}'
  else
    die "need sha256sum or shasum for checksum verification"
  fi
}

verify_sha256() {
  f="$1"
  expected="$2"
  [ -n "$expected" ] || die "internal: expected checksum empty for $f"
  got="$(sha256_file "$f")"
  if [ "$got" != "$expected" ]; then
    die "checksum mismatch for $(basename "$f"): expected $expected, got $got"
  fi
}

extract() {
  tarball="$1"
  destdir="$2"
  mkdirp "$destdir"
  # Extract safely into destdir (no clobber outside)
  tar -xf "$tarball" -C "$destdir"
}

run_logged() {
  name="$1"; shift
  logfile="${LOGDIR}/${name}.log"
  say "==> $name"
  # shellcheck disable=SC2094
  ( "$@" ) >"$logfile" 2>&1 || die "$name failed; see $logfile"
}

###############################################################################
# Sanity checks
###############################################################################
need_cmd sh
need_cmd make
need_cmd tar
need_cmd awk
need_cmd sed
need_cmd mkdir
need_cmd rm
need_cmd ln
need_cmd install
need_cmd gcc
need_cmd g++
need_cmd bison
need_cmd flex
need_cmd perl
need_cmd python3
need_cmd gawk

as_user_warning

# Writable checks
mkdirp "$ROOT"
mkdirp "$TOOLS"
[ -w "$ROOT" ] || die "ROOT not writable: $ROOT"
[ -w "$TOOLS" ] || die "TOOLS not writable: $TOOLS"

# Basic directory layout
mkdirp "$WORKDIR" "$SRCDIR" "$BUILDDIR" "$LOGDIR"
mkdirp "$TOOLS/bin" "$TOOLS/lib" "$TOOLS/include" "$TOOLS/share"
mkdirp "$TOOLS/$TARGET"

# Ensure our tools are preferred
export PATH="${TOOLS}/bin:${PATH}"

# Create a deterministic build locale to reduce surprises
export LC_ALL=C

###############################################################################
# Download + verify sources
###############################################################################
say "==> Downloading sources into ${SRCDIR}"
cd "$SRCDIR"

fetch "$BINUTILS_URL" "$BINUTILS_TARBALL"
verify_sha256 "$BINUTILS_TARBALL" "$BINUTILS_SHA256"

fetch "$GCC_URL" "$GCC_TARBALL"
verify_sha256 "$GCC_TARBALL" "$GCC_SHA256"

fetch "$GLIBC_URL" "$GLIBC_TARBALL"
verify_sha256 "$GLIBC_TARBALL" "$GLIBC_SHA256"

fetch "$LINUX_URL" "$LINUX_TARBALL"

if [ "${VERIFY_LINUX_SHA256LIST}" = "1" ]; then
  # Verify linux tarball using kernel.org sha256sums.asc for v6.x (point-release list).
  sha_list="sha256sums.asc"
  fetch "${KERNEL_MIRROR}/v6.x/${sha_list}" "$sha_list"
  expected="$(awk -v f="$LINUX_TARBALL" '$2==f {print $1}' "$sha_list" | head -n 1)"
  [ -n "$expected" ] || die "could not find ${LINUX_TARBALL} in ${sha_list}"
  verify_sha256 "$LINUX_TARBALL" "$expected"
else
  if [ -n "${LINUX_SHA256}" ]; then
    verify_sha256 "$LINUX_TARBALL" "$LINUX_SHA256"
  fi
fi

###############################################################################
# Extract sources (fresh each run for correctness)
###############################################################################
say "==> Extracting sources"
rm -rf "${BUILDDIR}/src"
mkdirp "${BUILDDIR}/src"

extract "${SRCDIR}/${BINUTILS_TARBALL}" "${BUILDDIR}/src"
extract "${SRCDIR}/${GCC_TARBALL}" "${BUILDDIR}/src"
extract "${SRCDIR}/${GLIBC_TARBALL}" "${BUILDDIR}/src"
extract "${SRCDIR}/${LINUX_TARBALL}" "${BUILDDIR}/src"

BINUTILS_SRC="${BUILDDIR}/src/binutils-${BINUTILS_VER}"
GCC_SRC="${BUILDDIR}/src/gcc-${GCC_VER}"
GLIBC_SRC="${BUILDDIR}/src/glibc-${GLIBC_VER}"
LINUX_SRC="${BUILDDIR}/src/linux-${LINUX_VER}"

[ -d "$BINUTILS_SRC" ] || die "binutils source dir not found"
[ -d "$GCC_SRC" ] || die "gcc source dir not found"
[ -d "$GLIBC_SRC" ] || die "glibc source dir not found"
[ -d "$LINUX_SRC" ] || die "linux source dir not found"

###############################################################################
# Build 1: Binutils (pass 1)
###############################################################################
BINUTILS_BUILD="${BUILDDIR}/build-binutils"
rm -rf "$BINUTILS_BUILD"
mkdirp "$BINUTILS_BUILD"
run_logged "binutils-configure" sh -c "
  cd '$BINUTILS_BUILD' &&
  '$BINUTILS_SRC/configure' \
    --prefix='$TOOLS' \
    --target='$TARGET' \
    --with-sysroot='$ROOT' \
    --disable-nls \
    --disable-werror
"
run_logged "binutils-make" sh -c "cd '$BINUTILS_BUILD' && make ${MAKEFLAGS}"
run_logged "binutils-install" sh -c "cd '$BINUTILS_BUILD' && make install"

###############################################################################
# Build 2: GCC (pass 1) - minimal C compiler + libgcc
###############################################################################
# Download GCC prerequisites to ensure a self-contained build tree.
# This fetches the dependency versions that the GCC release is tested with.
run_logged "gcc-prereqs" sh -c "cd '$GCC_SRC' && contrib/download_prerequisites"

GCC_BUILD1="${BUILDDIR}/build-gcc-pass1"
rm -rf "$GCC_BUILD1"
mkdirp "$GCC_BUILD1"

# GCC uses a non-POSIX configure test that may pick up /usr/include;
# --with-sysroot + --without-headers and --with-newlib are standard for pass1.
run_logged "gcc1-configure" sh -c "
  cd '$GCC_BUILD1' &&
  '$GCC_SRC/configure' \
    --target='$TARGET' \
    --prefix='$TOOLS' \
    --with-sysroot='$ROOT' \
    --with-newlib \
    --without-headers \
    --disable-nls \
    --disable-shared \
    --disable-multilib \
    --disable-threads \
    --disable-libatomic \
    --disable-libgomp \
    --disable-libquadmath \
    --disable-libssp \
    --disable-libvtv \
    --disable-libstdcxx \
    --enable-languages=c
"
run_logged "gcc1-make" sh -c "cd '$GCC_BUILD1' && make ${MAKEFLAGS} all-gcc all-target-libgcc"
run_logged "gcc1-install" sh -c "cd '$GCC_BUILD1' && make install-gcc install-target-libgcc"

###############################################################################
# Build 3: Linux API headers -> $ROOT/usr/include
###############################################################################
# These headers describe the kernel ABI to glibc and user space.
mkdirp "${ROOT}/usr/include"
run_logged "linux-headers" sh -c "
  cd '$LINUX_SRC' &&
  make mrproper &&
  make headers ${MAKEFLAGS} &&
  find usr/include -type f ! -name '*.h' -delete &&
  cp -r usr/include/* '$ROOT/usr/include/'
"

###############################################################################
# Build 4: glibc into $TOOLS/$TARGET (cross, minimal)
###############################################################################
GLIBC_BUILD="${BUILDDIR}/build-glibc"
rm -rf "$GLIBC_BUILD"
mkdirp "$GLIBC_BUILD"

# Some glibc builds require -fno-omit-frame-pointer for certain debug configs.
# We keep it default. For a toolchain, we do not enable debug variants.
run_logged "glibc-configure" sh -c "
  cd '$GLIBC_BUILD' &&
  BUILD_TRIPLE=\$('$GLIBC_SRC/scripts/config.guess') &&
  '$GLIBC_SRC/configure' \
    --prefix=/usr \
    --host='$TARGET' \
    --build=\$BUILD_TRIPLE \
    --with-headers='$ROOT/usr/include' \
    --enable-kernel='${GLIBC_ENABLE_KERNEL}' \
    --disable-werror
"

run_logged "glibc-make" sh -c "cd '$GLIBC_BUILD' && make ${MAKEFLAGS}"

# Install into $TOOLS/$TARGET with DESTDIR. This yields:
#   $TOOLS/usr/...
# We then relocate into $TOOLS/$TARGET by moving under $TOOLS/$TARGET.
# This avoids contaminating $ROOT at this stage.
GLIBC_DEST="${BUILDDIR}/glibc-dest"
rm -rf "$GLIBC_DEST"
mkdirp "$GLIBC_DEST"

run_logged "glibc-install" sh -c "cd '$GLIBC_BUILD' && make install DESTDIR='$GLIBC_DEST'"

# Relocate into toolchain sysroot
# Layout will be: $TOOLS/$TARGET/{usr,lib,lib64,include,...}
run_logged "glibc-relocate" sh -c "
  rm -rf '$TOOLS/$TARGET' &&
  mkdir -p '$TOOLS/$TARGET' &&
  cp -a '$GLIBC_DEST'/* '$TOOLS/$TARGET'/
"

# Fix dynamic linker convenience symlinks (common expectation for x86_64)
# Keep both lib and lib64 present if glibc created them.
if [ -d "$TOOLS/$TARGET/lib64" ] && [ ! -e "$TOOLS/$TARGET/lib/ld-linux-x86-64.so.2" ]; then
  mkdirp "$TOOLS/$TARGET/lib"
  if [ -e "$TOOLS/$TARGET/lib64/ld-linux-x86-64.so.2" ]; then
    ln -sf ../lib64/ld-linux-x86-64.so.2 "$TOOLS/$TARGET/lib/ld-linux-x86-64.so.2"
  fi
fi

###############################################################################
# Build 5: libstdc++ (from GCC) against the just-installed glibc
###############################################################################
GCC_BUILD2="${BUILDDIR}/build-gcc-libstdcxx"
rm -rf "$GCC_BUILD2"
mkdirp "$GCC_BUILD2"

run_logged "libstdcxx-configure" sh -c "
  cd '$GCC_BUILD2' &&
  '$GCC_SRC/libstdc++-v3/configure' \
    --host='$TARGET' \
    --build=\$('$GCC_SRC/config.guess') \
    --prefix=/usr \
    --disable-multilib \
    --disable-nls \
    --disable-libstdcxx-pch \
    --with-gxx-include-dir='/usr/include/c++/${GCC_VER}'
"

run_logged "libstdcxx-make" sh -c "cd '$GCC_BUILD2' && make ${MAKEFLAGS}"
run_logged "libstdcxx-install" sh -c "cd '$GCC_BUILD2' && make install DESTDIR='$TOOLS/$TARGET'"

###############################################################################
# Toolchain validation (compile + link + run via loader)
###############################################################################
say "==> Validating toolchain"

# Ensure key binaries exist
need_cmd "${TARGET}-gcc"
need_cmd "${TARGET}-ld"
need_cmd "${TARGET}-as"

# Validate headers are visible
[ -f "${ROOT}/usr/include/limits.h" ] || say "NOTE: limits.h not found in ROOT headers; this may be expected depending on host. Kernel headers are installed."

# Build and run a hello-world using the cross compiler and the toolchain sysroot.
TESTDIR="${BUILDDIR}/test"
rm -rf "$TESTDIR"
mkdirp "$TESTDIR"
cat > "${TESTDIR}/hello.c" <<'EOF'
#include <stdio.h>
int main(void) {
  puts("toolchain-ok");
  return 0;
}
EOF

# Compile: point compiler to the toolchain sysroot (glibc in $TOOLS/$TARGET)
# Force dynamic linker and rpath to locate libc under the toolchain sysroot.
LOADER="${TOOLS}/${TARGET}/lib64/ld-linux-x86-64.so.2"
if [ ! -x "$LOADER" ]; then
  LOADER="${TOOLS}/${TARGET}/lib/ld-linux-x86-64.so.2"
fi
[ -x "$LOADER" ] || die "dynamic loader not found under ${TOOLS}/${TARGET}/lib{,64}"

run_logged "test-compile" sh -c "
  cd '$TESTDIR' &&
  '${TOOLS}/bin/${TARGET}-gcc' \
    --sysroot='${TOOLS}/${TARGET}' \
    -Wl,--dynamic-linker='${LOADER}' \
    -Wl,-rpath,'${TOOLS}/${TARGET}/lib' \
    -Wl,-rpath,'${TOOLS}/${TARGET}/lib64' \
    hello.c -o hello
"

# Run using the toolchain loader to ensure we're using the toolchain libc, not host libc.
run_logged "test-run" sh -c "
  cd '$TESTDIR' &&
  '${LOADER}' --library-path '${TOOLS}/${TARGET}/lib:${TOOLS}/${TARGET}/lib64' ./hello | grep -qx 'toolchain-ok'
"

say "==> SUCCESS: temporary toolchain is built and validated."
say "Tools prefix: ${TOOLS}"
say "Toolchain sysroot: ${TOOLS}/${TARGET}"
say "Logs: ${LOGDIR}"

if [ "${KEEP_WORKDIR}" != "1" ]; then
  # Keep sources but remove build dirs to save space
  rm -rf "${BUILDDIR}/build-binutils" "${BUILDDIR}/build-gcc-pass1" "${BUILDDIR}/build-glibc" \
         "${BUILDDIR}/glibc-dest" "${BUILDDIR}/build-gcc-libstdcxx" "${BUILDDIR}/test" "${BUILDDIR}/src"
fi

exit 0
