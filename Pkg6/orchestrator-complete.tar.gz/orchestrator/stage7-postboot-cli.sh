#!/bin/sh
# stage7-postboot-cli.sh
# Post-boot hardening and CLI convenience (SysVinit-based):
# - fstab, hostname/hosts, locale, console
# - users + sudoers (wheel)
# - logrotate policies + cron jobs
# - seedrng entropy seeding (boot + shutdown + periodic save)
# - automatic service verification at boot
#
# POSIX sh only. Variables at top. License: MIT.

###############################################################################
# User-configurable variables
###############################################################################
ROOT="/mnt/rootfs"
TOOLS="${ROOT}/tools"

HOSTNAME="lfs"
DOMAIN="localdomain"

ROOT_FS_TYPE="ext4"
ROOT_UUID=""
ROOT_DEVICE=""

BOOT_UUID=""
BOOT_DEVICE=""
BOOT_FS_TYPE="ext4"

SWAP_UUID=""
SWAP_DEVICE=""

LOCALES="en_US.UTF-8"
DEFAULT_LANG="en_US.UTF-8"
DEFAULT_LC_ALL=""

KEYMAP="br-abnt2"
CONSOLE_FONT=""

CREATE_USER="1"
NEW_USER="user"
NEW_USER_SHELL="/bin/bash"
NEW_USER_GROUPS="wheel,audio,video"

ENABLE_SUDO="1"
SUDO_WHEEL_NOPASSWD="0"

ENABLE_LOGROTATE="1"
ENABLE_CRON="1"

ENABLE_SEEDRNG="1"
SEEDRNG_INSTALL_PATH="/usr/sbin/seedrng"

ENABLE_SERVICE_CHECK="1"

ALLOW_ROOT="1"
MOUNT_VFS="1"
BACKUP_ETC="1"

###############################################################################
set -eu
umask 022
IFS="$(printf ' \t\n')"
export LC_ALL=C

say(){ printf '%s\n' "$*"; }
die(){ printf 'ERROR: %s\n' "$*" >&2; exit 1; }
have(){ command -v "$1" >/dev/null 2>&1; }
need(){ command -v "$1" >/dev/null 2>&1 || die "missing required command: $1"; }
mkdirp(){ [ -d "$1" ] || mkdir -p "$1"; }

as_root() {
  if [ "$(id -u)" -eq 0 ] && [ "${ALLOW_ROOT}" != "1" ]; then
    die "refusing to run as root (ALLOW_ROOT=0)"
  fi
  [ "$(id -u)" -eq 0 ] || die "stage7 requires root (mounts + chroot)"
}

is_mounted() {
  mp="$1"
  if have mountpoint; then
    mountpoint -q "$mp" 2>/dev/null
  else
    [ -r /proc/mounts ] && awk -v m="$mp" '$2==m{f=1} END{exit(f?0:1)}' /proc/mounts
  fi
}

mount_vfs() {
  [ "${MOUNT_VFS}" = "1" ] || return 0
  mkdirp "$ROOT/dev" "$ROOT/proc" "$ROOT/sys" "$ROOT/run"
  is_mounted "$ROOT/dev" || mount --bind /dev "$ROOT/dev"
  is_mounted "$ROOT/dev/pts" || { mkdirp "$ROOT/dev/pts"; mount -t devpts devpts "$ROOT/dev/pts"; }
  is_mounted "$ROOT/proc" || mount -t proc proc "$ROOT/proc"
  is_mounted "$ROOT/sys" || mount -t sysfs sysfs "$ROOT/sys"
  is_mounted "$ROOT/run" || mount -t tmpfs tmpfs "$ROOT/run"
}

umount_vfs() {
  [ "${MOUNT_VFS}" = "1" ] || return 0
  umount -l "$ROOT/dev/pts" 2>/dev/null || true
  umount -l "$ROOT/dev" 2>/dev/null || true
  umount -l "$ROOT/proc" 2>/dev/null || true
  umount -l "$ROOT/sys" 2>/dev/null || true
  umount -l "$ROOT/run" 2>/dev/null || true
}

write_chroot_payload() {
  mkdirp "$ROOT/.stage7"
  [ -f "./seedrng.c" ] && cp -f "./seedrng.c" "$ROOT/.stage7/seedrng.c"

  cat > "$ROOT/.stage7/apply.sh" <<EOF
set -eu
umask 022
export LC_ALL=C

HOSTNAME='${HOSTNAME}'
DOMAIN='${DOMAIN}'

ROOT_FS_TYPE='${ROOT_FS_TYPE}'
ROOT_UUID='${ROOT_UUID}'
ROOT_DEVICE='${ROOT_DEVICE}'
BOOT_FS_TYPE='${BOOT_FS_TYPE}'
BOOT_UUID='${BOOT_UUID}'
BOOT_DEVICE='${BOOT_DEVICE}'
SWAP_UUID='${SWAP_UUID}'
SWAP_DEVICE='${SWAP_DEVICE}'

LOCALES='${LOCALES}'
DEFAULT_LANG='${DEFAULT_LANG}'
DEFAULT_LC_ALL='${DEFAULT_LC_ALL}'

KEYMAP='${KEYMAP}'
CONSOLE_FONT='${CONSOLE_FONT}'

CREATE_USER='${CREATE_USER}'
NEW_USER='${NEW_USER}'
NEW_USER_SHELL='${NEW_USER_SHELL}'
NEW_USER_GROUPS='${NEW_USER_GROUPS}'

ENABLE_SUDO='${ENABLE_SUDO}'
SUDO_WHEEL_NOPASSWD='${SUDO_WHEEL_NOPASSWD}'

ENABLE_LOGROTATE='${ENABLE_LOGROTATE}'
ENABLE_CRON='${ENABLE_CRON}'

ENABLE_SEEDRNG='${ENABLE_SEEDRNG}'
SEEDRNG_INSTALL_PATH='${SEEDRNG_INSTALL_PATH}'

ENABLE_SERVICE_CHECK='${ENABLE_SERVICE_CHECK}'
BACKUP_ETC='${BACKUP_ETC}'

say(){ printf '%s\n' "\$*"; }
die(){ printf 'ERROR: %s\n' "\$*" >&2; exit 1; }
mkdirp(){ [ -d "\$1" ] || mkdir -p "\$1"; }

backup_etc_file() {
  f="\$1"
  [ "\$BACKUP_ETC" = "1" ] || return 0
  ts="\$(date +%Y%m%d-%H%M%S 2>/dev/null || echo now)"
  bdir="/etc/.backup-\$ts"
  mkdirp "\$bdir"
  [ -e "\$f" ] && { mkdirp "\$(dirname "\$bdir\${f}")"; cp -a "\$f" "\$bdir\${f}" 2>/dev/null || cp "\$f" "\$bdir\${f}" 2>/dev/null || true; }
}

write_file() {
  path="\$1"; mode="\$2"
  tmp="\${path}.tmp"
  backup_etc_file "\$path"
  mkdirp "\$(dirname "\$path")"
  cat > "\$tmp"
  chmod "\$mode" "\$tmp"
  mv "\$tmp" "\$path"
}

append_unique_line() {
  file="\$1"; line="\$2"
  touch "\$file"
  if ! grep -Fqx "\$line" "\$file" 2>/dev/null; then
    printf '%s\n' "\$line" >> "\$file"
  fi
}

configure_hostname_hosts() {
  write_file /etc/hostname 0644 <<EOH
\${HOSTNAME}
EOH
  write_file /etc/hosts 0644 <<EOHOSTS
127.0.0.1\tlocalhost
127.0.1.1\t\${HOSTNAME}.\${DOMAIN}\t\${HOSTNAME}
::1\tlocalhost ip6-localhost ip6-loopback
EOHOSTS
}

configure_fstab() {
  [ -n "\$ROOT_UUID" ] || [ -n "\$ROOT_DEVICE" ] || die "set ROOT_UUID or ROOT_DEVICE for fstab"
  if [ -n "\$ROOT_UUID" ]; then root_spec="UUID=\$ROOT_UUID"; else root_spec="\$ROOT_DEVICE"; fi

  boot_line=""
  if [ -n "\$BOOT_UUID" ] || [ -n "\$BOOT_DEVICE" ]; then
    if [ -n "\$BOOT_UUID" ]; then boot_spec="UUID=\$BOOT_UUID"; else boot_spec="\$BOOT_DEVICE"; fi
    boot_line="\${boot_spec}\t/boot\t\${BOOT_FS_TYPE}\tdefaults\t1 2"
  fi

  swap_line=""
  if [ -n "\$SWAP_UUID" ] || [ -n "\$SWAP_DEVICE" ]; then
    if [ -n "\$SWAP_UUID" ]; then swap_spec="UUID=\$SWAP_UUID"; else swap_spec="\$SWAP_DEVICE"; fi
    swap_line="\${swap_spec}\tswap\tswap\tpri=1\t0 0"
  fi

  write_file /etc/fstab 0644 <<EOFST
# /etc/fstab (generated by stage7)
\${root_spec}\t/\t\${ROOT_FS_TYPE}\tdefaults\t1 1
\${boot_line}
\${swap_line}
proc\t/proc\tproc\tnosuid,noexec,nodev\t0 0
sysfs\t/sys\tsysfs\tnosuid,noexec,nodev\t0 0
devpts\t/dev/pts\tdevpts\tgid=5,mode=620\t0 0
tmpfs\t/run\ttmpfs\tmode=0755\t0 0
tmpfs\t/tmp\ttmpfs\tmode=1777\t0 0
EOFST
}

configure_locale() {
  command -v localedef >/dev/null 2>&1 || { say "localedef not found; skipping"; return 0; }
  for loc in \$LOCALES; do
    lang="\${loc%.*}"
    enc="\${loc#*.}"
    say "Generating locale: \$loc"
    localedef -i "\$lang" -f "\$enc" "\$loc" >/dev/null 2>&1 || true
  done
  mkdirp /etc/profile.d
  write_file /etc/profile.d/locale.sh 0644 <<EOFLOC
# Generated by stage7
export LANG="\${DEFAULT_LANG}"
EOFLOC
  [ -n "\$DEFAULT_LC_ALL" ] && append_unique_line /etc/profile.d/locale.sh "export LC_ALL=\"\${DEFAULT_LC_ALL}\""
}

configure_console() {
  mkdirp /etc/sysconfig
  write_file /etc/sysconfig/console 0644 <<EOCON
KEYMAP="\${KEYMAP}"
FONT="\${CONSOLE_FONT}"
EOCON
}

ensure_groups() {
  if ! grep -q '^wheel:' /etc/group 2>/dev/null; then
    groupadd -f wheel 2>/dev/null || true
  fi
}

create_user() {
  [ "\$CREATE_USER" = "1" ] || return 0
  command -v useradd >/dev/null 2>&1 || { say "useradd missing; skipping"; return 0; }
  ensure_groups
  id "\$NEW_USER" >/dev/null 2>&1 && { say "User exists: \$NEW_USER"; return 0; }
  useradd -m -s "\$NEW_USER_SHELL" -G "\$NEW_USER_GROUPS" "\$NEW_USER" || die "useradd failed"
  passwd -l "\$NEW_USER" >/dev/null 2>&1 || true
  say "User created: \$NEW_USER (run: passwd \$NEW_USER)"
}

configure_sudoers() {
  [ "\$ENABLE_SUDO" = "1" ] || return 0
  command -v sudo >/dev/null 2>&1 || { say "sudo not installed; skipping"; return 0; }
  ensure_groups
  write_file /etc/sudoers 0440 <<'EOSUD'
Defaults        secure_path="/usr/sbin:/usr/bin:/sbin:/bin"
Defaults        env_reset
root            ALL=(ALL:ALL) ALL
@includedir /etc/sudoers.d
EOSUD
  mkdirp /etc/sudoers.d
  if [ "\$SUDO_WHEEL_NOPASSWD" = "1" ]; then
    write_file /etc/sudoers.d/00-wheel 0440 <<'EOW'
%wheel ALL=(ALL:ALL) NOPASSWD: ALL
EOW
  else
    write_file /etc/sudoers.d/00-wheel 0440 <<'EOW'
%wheel ALL=(ALL:ALL) ALL
EOW
  fi
}

configure_logrotate() {
  [ "\$ENABLE_LOGROTATE" = "1" ] || return 0
  command -v logrotate >/dev/null 2>&1 || { say "logrotate missing; skipping"; return 0; }
  mkdirp /etc/logrotate.d /var/lib/logrotate
  write_file /etc/logrotate.conf 0644 <<'EOLR'
weekly
rotate 4
create
compress
delaycompress
missingok
notifempty
include /etc/logrotate.d
EOLR
  write_file /etc/logrotate.d/boot-and-sv 0644 <<'EOLRS'
/var/log/boot.log /var/log/sv/*.log /var/log/sv/*.wpa.log {
    weekly
    rotate 8
    compress
    delaycompress
    missingok
    notifempty
    create 0640 root root
}
EOLRS
}

install_seedrng() {
  [ "\$ENABLE_SEEDRNG" = "1" ] || return 0
  command -v cc >/dev/null 2>&1 || { say "cc missing; skipping seedrng"; return 0; }
  [ -f "/.stage7/seedrng.c" ] || { say "seedrng.c missing; skipping"; return 0; }
  mkdirp /var/lib/seedrng
  chmod 0700 /var/lib/seedrng
  cc -O2 -Wall -Wextra -o "\$SEEDRNG_INSTALL_PATH" "/.stage7/seedrng.c"
  chmod 0755 "\$SEEDRNG_INSTALL_PATH"
}

install_seedrng_init() {
  [ "\$ENABLE_SEEDRNG" = "1" ] || return 0
  [ -x "\$SEEDRNG_INSTALL_PATH" ] || return 0
  mkdirp /etc/rc.d/init.d /etc/rc.d/rcS.d /etc/rc.d/rc0.d /etc/rc.d/rc6.d
  cat > /etc/rc.d/init.d/seedrng <<EOFSE
#!/bin/sh
set -eu
SEEDRNG="\$SEEDRNG_INSTALL_PATH"
case "\${1:-}" in
  start) [ -x "\$SEEDRNG" ] && "\$SEEDRNG" seed >/dev/null 2>&1 || true ;;
  stop)  [ -x "\$SEEDRNG" ] && "\$SEEDRNG" save >/dev/null 2>&1 || true ;;
  restart) "\$0" stop || true; "\$0" start || true ;;
  *) exit 0 ;;
esac
exit 0
EOFSE
  chmod 0755 /etc/rc.d/init.d/seedrng
  ln -sfn ../init.d/seedrng /etc/rc.d/rcS.d/S02seedrng 2>/dev/null || true
  ln -sfn ../init.d/seedrng /etc/rc.d/rc0.d/K02seedrng 2>/dev/null || true
  ln -sfn ../init.d/seedrng /etc/rc.d/rc6.d/K02seedrng 2>/dev/null || true
}

configure_cron_jobs() {
  [ "\$ENABLE_CRON" = "1" ] || return 0
  command -v crontab >/dev/null 2>&1 || { say "cron tools missing; skipping"; return 0; }
  mkdirp /etc/cron.daily /etc/cron.weekly /etc/cron.hourly
  if command -v logrotate >/dev/null 2>&1; then
    write_file /etc/cron.daily/logrotate 0755 <<'EOCRL'
#!/bin/sh
exec /usr/sbin/logrotate /etc/logrotate.conf
EOCRL
  fi
  if [ "\$ENABLE_SEEDRNG" = "1" ] && [ -x "\$SEEDRNG_INSTALL_PATH" ]; then
    write_file /etc/cron.hourly/seedrng-save 0755 <<EOFCRS
#!/bin/sh
exec "\$SEEDRNG_INSTALL_PATH" save >/dev/null 2>&1 || true
EOFCRS
  fi
}

install_cron_init() {
  [ "\$ENABLE_CRON" = "1" ] || return 0
  command -v cron >/dev/null 2>&1 || { say "cron daemon missing; skipping"; return 0; }
  mkdirp /etc/rc.d/init.d /etc/rc.d/rcS.d
  cat > /etc/rc.d/init.d/crond <<'EOCRD'
#!/bin/sh
set -eu
. /etc/rc.d/init.d/functions
PIDFILE=/run/crond.pid
case "${1:-}" in
  start)
    command -v cron >/dev/null 2>&1 || exit 0
    start_daemon "cron" "$PIDFILE" cron
    ;;
  stop)
    stop_daemon "cron" "$PIDFILE" || true
    ;;
  restart)
    "$0" stop || true
    "$0" start || true
    ;;
  *)
    exit 0
    ;;
esac
exit 0
EOCRD
  chmod 0755 /etc/rc.d/init.d/crond
  ln -sfn ../init.d/crond /etc/rc.d/rcS.d/S25crond 2>/dev/null || true
}

install_service_check() {
  [ "\$ENABLE_SERVICE_CHECK" = "1" ] || return 0
  mkdirp /etc/rc.d/init.d /etc/rc.d/rcS.d
  cat > /etc/rc.d/init.d/checkservices <<'EOCS'
#!/bin/sh
set -eu
. /etc/rc.d/init.d/functions
is_running() {
  name="$1"
  ps -eo comm 2>/dev/null | awk -v n="$name" '$1==n{f=1} END{exit(f?0:1)}'
}
case "${1:-}" in
  start)
    log "service-check begin"
    for p in udevd systemd-udevd syslogd svscan dhcpcd; do
      if is_running "$p"; then
        log "service-check: OK $p"
      else
        log "service-check: MISSING $p"
      fi
    done
    log "service-check end"
    ;;
  *) exit 0 ;;
esac
exit 0
EOCS
  chmod 0755 /etc/rc.d/init.d/checkservices
  ln -sfn ../init.d/checkservices /etc/rc.d/rcS.d/S98checkservices 2>/dev/null || true
}

final_validation() {
  test -f /etc/fstab
  if [ "\$ENABLE_SUDO" = "1" ] && [ -f /etc/sudoers ]; then chmod 0440 /etc/sudoers 2>/dev/null || true; fi
}

say "==> Stage7 applying..."
configure_hostname_hosts
configure_fstab
configure_locale
configure_console
create_user
configure_sudoers
configure_logrotate
install_seedrng
install_seedrng_init
configure_cron_jobs
install_cron_init
install_service_check
final_validation
say "==> Stage7 applied. Run 'passwd \$NEW_USER' after boot."
EOF
  chmod 0755 "$ROOT/.stage7/apply.sh"
}

run_in_chroot() {
  [ -x "$ROOT/bin/sh" ] || { mkdirp "$ROOT/bin"; ln -sf /tools/bin/bash "$ROOT/bin/sh"; }
  chroot "$ROOT" /usr/bin/env -i HOME=/root TERM="${TERM:-xterm}" PATH=/usr/bin:/usr/sbin:/bin:/sbin:/tools/bin \
    /bin/sh -c "/.stage7/apply.sh"
}

need sh; need awk; need sed; need mount; need umount; need chroot
as_root
write_chroot_payload
trap umount_vfs EXIT INT TERM HUP
mount_vfs
run_in_chroot
say "==> SUCCESS: Stage7 completed."
