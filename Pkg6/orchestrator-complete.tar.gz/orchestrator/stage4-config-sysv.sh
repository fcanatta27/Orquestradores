#!/bin/sh
# stage4-config-sysv.sh (v2)
# Post-build configuration for a SysVinit-based base system:
# - /etc core configuration for packages built in Stage1-Stage3
# - SysVinit boot framework (/etc/inittab, rcS, rc, init.d)
# - Optional service supervision using SysVinit "respawn" + lightweight supervisor
# - Networking: loopback + wired (DHCP if client exists) + Wi-Fi (if wpa_supplicant + DHCP client exist)
#
# Runs from host, mounts VFS, enters chroot, and applies configuration inside $ROOT.
#
# POSIX sh only. Variables at top.
#
# License: MIT (see LICENSE)

###############################################################################
# User-configurable variables
###############################################################################
ROOT="/mnt/rootfs"
TOOLS="${ROOT}/tools"

# System identity
HOSTNAME="lfs"
DOMAIN="localdomain"
TIMEZONE="Etc/UTC"                  # example: "America/Sao_Paulo"
KEYMAP="br-abnt2"                   # example; requires kbd keymaps installed
CONSOLE_FONT=""                     # optional (kbd console fonts)

# Locale:
# For a minimal base, keep C. If you later generate locales, set LANG accordingly.
LANG_DEFAULT="C"
LC_ALL_DEFAULT="C"

# DNS / network defaults
DNS_SERVERS="1.1.1.1 8.8.8.8"
DEFAULT_IFACE="eth0"                # wired default interface
WIFI_IFACE="wlan0"                  # wifi interface name (adjust as needed)
WIFI_COUNTRY="BR"                   # used by wpa_supplicant if available
WIFI_SSID=""                        # set to enable Wi-Fi config template
WIFI_PSK=""                         # set to enable Wi-Fi config template (plaintext; consider wpa_passphrase)

# SysVinit defaults
DEFAULT_RUNLEVEL="3"                # 3=text multi-user
TTY_SPEED="38400"
NUM_TTYS="6"

# Service supervision (optional but recommended)
SUPERVISION_ENABLE="1"
SV_BASE="/etc/sv"
SV_RUN="/run/sv"
SV_LOG="/var/log/sv"
SV_RESTART_DELAY="2"

# Safety toggles
ALLOW_ROOT="1"
MOUNT_VFS="1"
BACKUP_ETC="1"                      # backups into /etc/.backup-<timestamp>

###############################################################################
set -eu
umask 022
IFS="$(printf ' \t\n')"
export LC_ALL=C

say(){ printf '%s\n' "$*"; }
die(){ printf 'ERROR: %s\n' "$*" >&2; exit 1; }
have(){ command -v "$1" >/dev/null 2>&1; }
need(){ command -v "$1" >/dev/null 2>&1 || die "missing required command: $1"; }
mkdirp(){ [ -d "$1" ] || mkdir -p "$1"; }

as_root() {
  if [ "$(id -u)" -eq 0 ] && [ "${ALLOW_ROOT}" != "1" ]; then
    die "refusing to run as root (ALLOW_ROOT=0)"
  fi
  [ "$(id -u)" -eq 0 ] || die "this script requires root (mounts + chroot)"
}

is_mounted() {
  mp="$1"
  if have mountpoint; then
    mountpoint -q "$mp" 2>/dev/null
  else
    [ -r /proc/mounts ] && awk -v m="$mp" '$2==m{f=1} END{exit(f?0:1)}' /proc/mounts
  fi
}

mount_vfs() {
  [ "${MOUNT_VFS}" = "1" ] || return 0
  mkdirp "$ROOT/dev" "$ROOT/proc" "$ROOT/sys" "$ROOT/run"
  is_mounted "$ROOT/dev" || mount --bind /dev "$ROOT/dev"
  is_mounted "$ROOT/dev/pts" || { mkdirp "$ROOT/dev/pts"; mount -t devpts devpts "$ROOT/dev/pts"; }
  is_mounted "$ROOT/proc" || mount -t proc proc "$ROOT/proc"
  is_mounted "$ROOT/sys" || mount -t sysfs sysfs "$ROOT/sys"
  is_mounted "$ROOT/run" || mount -t tmpfs tmpfs "$ROOT/run"
}

umount_vfs() {
  [ "${MOUNT_VFS}" = "1" ] || return 0
  umount -l "$ROOT/dev/pts" 2>/dev/null || true
  umount -l "$ROOT/dev" 2>/dev/null || true
  umount -l "$ROOT/proc" 2>/dev/null || true
  umount -l "$ROOT/sys" 2>/dev/null || true
  umount -l "$ROOT/run" 2>/dev/null || true
}

write_chroot_configurator() {
  mkdirp "$ROOT/.stage4-config"
  cat > "$ROOT/.stage4-config/apply.sh" <<EOF
set -eu
umask 022
export LC_ALL=C

HOSTNAME='${HOSTNAME}'
DOMAIN='${DOMAIN}'
TIMEZONE='${TIMEZONE}'
KEYMAP='${KEYMAP}'
CONSOLE_FONT='${CONSOLE_FONT}'
LANG_DEFAULT='${LANG_DEFAULT}'
LC_ALL_DEFAULT='${LC_ALL_DEFAULT}'

DNS_SERVERS='${DNS_SERVERS}'
DEFAULT_IFACE='${DEFAULT_IFACE}'
WIFI_IFACE='${WIFI_IFACE}'
WIFI_COUNTRY='${WIFI_COUNTRY}'
WIFI_SSID='${WIFI_SSID}'
WIFI_PSK='${WIFI_PSK}'

DEFAULT_RUNLEVEL='${DEFAULT_RUNLEVEL}'
TTY_SPEED='${TTY_SPEED}'
NUM_TTYS='${NUM_TTYS}'

SUPERVISION_ENABLE='${SUPERVISION_ENABLE}'
SV_BASE='${SV_BASE}'
SV_RUN='${SV_RUN}'
SV_LOG='${SV_LOG}'
SV_RESTART_DELAY='${SV_RESTART_DELAY}'

BACKUP_ETC='${BACKUP_ETC}'

say(){ printf '%s\n' "\$*"; }
die(){ printf 'ERROR: %s\n' "\$*" >&2; exit 1; }
mkdirp(){ [ -d "\$1" ] || mkdir -p "\$1"; }

backup_etc_file() {
  f="\$1"
  [ "\$BACKUP_ETC" = "1" ] || return 0
  ts="\$(date +%Y%m%d-%H%M%S 2>/dev/null || echo now)"
  bdir="/etc/.backup-\$ts"
  mkdirp "\$bdir"
  if [ -e "\$f" ]; then
    mkdirp "\$(dirname "\$bdir\${f}")"
    cp -a "\$f" "\$bdir\${f}" 2>/dev/null || cp "\$f" "\$bdir\${f}" 2>/dev/null || true
  fi
}

write_file() {
  path="\$1"; mode="\$2"
  tmp="\${path}.tmp"
  backup_etc_file "\$path"
  mkdirp "\$(dirname "\$path")"
  cat > "\$tmp"
  chmod "\$mode" "\$tmp"
  mv "\$tmp" "\$path"
}

append_unique_line() {
  file="\$1"; line="\$2"
  touch "\$file"
  if ! grep -Fqx "\$line" "\$file" 2>/dev/null; then
    printf '%s\n' "\$line" >> "\$file"
  fi
}

# ---------------------------------------------------------------------------
# Base account databases (shadow may later manage these)
# ---------------------------------------------------------------------------
ensure_minimal_accounts() {
  if [ ! -f /etc/passwd ]; then
    write_file /etc/passwd 0644 <<'EOP'
root:x:0:0:root:/root:/bin/bash
bin:x:1:1:bin:/dev/null:/bin/false
daemon:x:6:6:daemon:/dev/null:/bin/false
nobody:x:99:99:nobody:/dev/null:/bin/false
EOP
  fi
  if [ ! -f /etc/group ]; then
    write_file /etc/group 0644 <<'EOG'
root:x:0:
bin:x:1:
sys:x:2:
kmem:x:3:
tty:x:5:
daemon:x:6:
disk:x:8:
lp:x:9:
wheel:x:10:
users:x:100:
nogroup:x:99:
EOG
  fi
  if [ ! -f /etc/shadow ]; then
    write_file /etc/shadow 0600 <<'EOS'
root:!:19376:0:99999:7:::
EOS
  fi
  if [ ! -f /etc/gshadow ]; then
    write_file /etc/gshadow 0600 <<'EOGS'
root:!::
EOGS
  fi
}

# ---------------------------------------------------------------------------
# /etc core configuration for packages in Stage1-3
# ---------------------------------------------------------------------------
configure_identity() {
  write_file /etc/hostname 0644 <<EOH
\${HOSTNAME}
EOH

  write_file /etc/hosts 0644 <<EOHOSTS
127.0.0.1\tlocalhost
127.0.1.1\t\${HOSTNAME}.\${DOMAIN}\t\${HOSTNAME}
::1\tlocalhost ip6-localhost ip6-loopback
EOHOSTS

  write_file /etc/issue 0644 <<'EOISS'
Linux From Scratch (custom)
Kernel \r on an \m
EOISS
}

configure_fstab_template() {
  if [ ! -f /etc/fstab ]; then
    write_file /etc/fstab 0644 <<'EOFS'
# <fs>      <mountpoint>  <type>  <opts>                   <dump/pass>
# /dev/sdXn  /            ext4    defaults                 1 1
# /dev/sdXn  /boot        ext4    defaults                 1 2
proc        /proc        proc    nosuid,noexec,nodev       0 0
sysfs       /sys         sysfs   nosuid,noexec,nodev       0 0
devpts      /dev/pts     devpts  gid=5,mode=620            0 0
tmpfs       /run         tmpfs   mode=0755                 0 0
tmpfs       /tmp         tmpfs   mode=1777                 0 0
EOFS
  fi
}

configure_shell_environment() {
  write_file /etc/profile 0644 <<EOFPRO
# /etc/profile
export LANG="\${LANG_DEFAULT}"
export LC_ALL="\${LC_ALL_DEFAULT}"
umask 022
if [ -d /etc/profile.d ]; then
  for f in /etc/profile.d/*.sh; do
    [ -r "\$f" ] && . "\$f"
  done
fi
EOFPRO

  mkdirp /etc/profile.d
  write_file /etc/profile.d/path.sh 0644 <<'EOPATH'
PATH=/usr/bin:/usr/sbin:/bin:/sbin
[ -d /tools/bin ] && PATH="$PATH:/tools/bin"
export PATH
EOPATH

  write_file /etc/inputrc 0644 <<'EOIN'
set bell-style none
set editing-mode vi
"\e[1~": beginning-of-line
"\e[4~": end-of-line
EOIN

  write_file /etc/shells 0644 <<'EOSH'
/bin/sh
/bin/bash
EOSH
}

configure_timezone_console() {
  if [ -d /usr/share/zoneinfo ] && [ -f "/usr/share/zoneinfo/\${TIMEZONE}" ]; then
    backup_etc_file /etc/localtime
    ln -sfn "/usr/share/zoneinfo/\${TIMEZONE}" /etc/localtime
  fi
  mkdirp /etc/sysconfig
  write_file /etc/sysconfig/clock 0644 <<EOCLK
UTC=1
ZONE="\${TIMEZONE}"
EOCLK

  write_file /etc/sysconfig/console 0644 <<EOCON
KEYMAP="\${KEYMAP}"
FONT="\${CONSOLE_FONT}"
EOCON
}

configure_networking_base() {
  # resolv.conf
  write_file /etc/resolv.conf 0644 <<EORES
# Generated by stage4-config-sysv
EORES
  for ns in \$DNS_SERVERS; do
    append_unique_line /etc/resolv.conf "nameserver \$ns"
  done

  # nsswitch.conf (basic)
  write_file /etc/nsswitch.conf 0644 <<'EONSS'
passwd: files
group:  files
shadow: files

hosts:  files dns
networks: files

protocols: files
services:  files
ethers: files
rpc: files
EONSS

  # host.conf (glibc resolver)
  write_file /etc/host.conf 0644 <<'EOHC'
multi on
order hosts,bind
EOHC

  # sysctl baseline
  write_file /etc/sysctl.conf 0644 <<'EOSYS'
# /etc/sysctl.conf
kernel.printk = 4 4 1 7
net.ipv4.icmp_echo_ignore_broadcasts = 1
net.ipv4.conf.all.rp_filter = 1
net.ipv4.conf.default.rp_filter = 1
EOSYS
}

configure_shadow_defaults() {
  # Only create if missing; shadow package may ship defaults.
  if [ ! -f /etc/login.defs ]; then
    write_file /etc/login.defs 0644 <<'EOLOG'
# /etc/login.defs (minimal)
PASS_MAX_DAYS   99999
PASS_MIN_DAYS   0
PASS_WARN_AGE   7
UID_MIN         1000
GID_MIN         1000
CREATE_HOME     yes
UMASK           022
ENCRYPT_METHOD  SHA512
EOLOG
  fi
  if [ ! -f /etc/securetty ]; then
    write_file /etc/securetty 0644 <<'EOSEC'
tty1
tty2
tty3
tty4
tty5
tty6
EOSEC
  fi
}

# ---------------------------------------------------------------------------
# SysVinit framework (more complete than v1)
# ---------------------------------------------------------------------------
is_mounted() {
  mp="\$1"
  if [ -r /proc/mounts ]; then
    awk -v m="\$mp" '\$2==m{f=1} END{exit(f?0:1)}' /proc/mounts
  else
    return 1
  fi
}

install_sysv_layout() {
  mkdirp /etc/rc.d /etc/rc.d/init.d
  mkdirp /etc/rc.d/rc0.d /etc/rc.d/rc1.d /etc/rc.d/rc2.d /etc/rc.d/rc3.d /etc/rc.d/rc4.d /etc/rc.d/rc5.d /etc/rc.d/rc6.d
  mkdirp /etc/rc.d/rcS.d
  mkdirp /var/log /run

  # Logging target
  touch /var/log/boot.log 2>/dev/null || true

  # init.d helper functions (POSIX, no fractional sleep)
  write_file /etc/rc.d/init.d/functions 0755 <<'EOFUN'
#!/bin/sh
umask 022

log() {
  # best-effort boot log
  ts="$(date +%Y-%m-%dT%H:%M:%S 2>/dev/null || echo time)"
  printf '%s %s\n' "$ts" "$*" >>/var/log/boot.log 2>/dev/null || true
}

start_daemon() {
  name="$1"; pidfile="$2"; shift 2
  if [ -n "$pidfile" ] && [ -r "$pidfile" ]; then
    pid="$(cat "$pidfile" 2>/dev/null || true)"
    if [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null; then
      log "$name already running pid=$pid"
      echo "$name already running"
      return 0
    fi
  fi
  "$@" &
  pid="$!"
  if [ -n "$pidfile" ]; then
    mkdir -p "$(dirname "$pidfile")"
    printf '%s\n' "$pid" >"$pidfile" 2>/dev/null || true
  fi
  log "started $name pid=$pid"
  echo "started $name"
}

stop_daemon() {
  name="$1"; pidfile="$2"
  pid=""
  if [ -n "$pidfile" ] && [ -r "$pidfile" ]; then
    pid="$(cat "$pidfile" 2>/dev/null || true)"
  fi
  if [ -z "$pid" ]; then
    log "stop $name: no pidfile"
    echo "no pidfile for $name"
    return 0
  fi
  if kill -0 "$pid" 2>/dev/null; then
    kill "$pid" 2>/dev/null || true
    i=0
    while [ $i -lt 5 ]; do
      kill -0 "$pid" 2>/dev/null || break
      i=$((i+1))
      sleep 1
    done
    kill -0 "$pid" 2>/dev/null && kill -9 "$pid" 2>/dev/null || true
  fi
  rm -f "$pidfile" 2>/dev/null || true
  log "stopped $name"
  echo "stopped $name"
}
EOFUN

  # rc dispatcher (stop K first, then start S)
  write_file /etc/rc.d/rc 0755 <<'EO_RC'
#!/bin/sh
set -eu
RL="${1:-}"
[ -n "$RL" ] || exit 0
DIR="/etc/rc.d/rc${RL}.d"
[ -d "$DIR" ] || exit 0

# Stop first
for k in "$DIR"/K*; do
  [ -x "$k" ] || continue
  /bin/sh "$k" stop || true
done
# Start
for s in "$DIR"/S*; do
  [ -x "$s" ] || continue
  /bin/sh "$s" start || true
done
exit 0
EO_RC

  # rcS (sysinit)
  write_file /etc/rc.d/rcS 0755 <<'EO_RCS'
#!/bin/sh
set -eu
. /etc/rc.d/init.d/functions

log "rcS begin"

mkdir -p /proc /sys /run /dev/pts /tmp

if [ -r /proc/mounts ]; then
  awk '$2=="/proc"{f=1} END{exit(f?0:1)}' /proc/mounts || mount -t proc proc /proc 2>/dev/null || true
  awk '$2=="/sys"{f=1} END{exit(f?0:1)}' /proc/mounts || mount -t sysfs sysfs /sys 2>/dev/null || true
  awk '$2=="/run"{f=1} END{exit(f?0:1)}' /proc/mounts || mount -t tmpfs tmpfs /run 2>/dev/null || true
fi

chmod 1777 /tmp 2>/dev/null || true

# Load keymap if available
if [ -f /etc/sysconfig/console ] && command -v loadkeys >/dev/null 2>&1; then
  . /etc/sysconfig/console || true
  [ -n "${KEYMAP:-}" ] && loadkeys "$KEYMAP" >/dev/null 2>&1 || true
fi

# Bring loopback up
if command -v ip >/dev/null 2>&1; then
  ip link set lo up 2>/dev/null || true
fi

# Start core services enabled in rcS.d
for s in /etc/rc.d/rcS.d/S*; do
  [ -x "$s" ] || continue
  /bin/sh "$s" start || true
done

log "rcS end"
exit 0
EO_RCS

  # rc.local (optional user hook)
  write_file /etc/rc.d/rc.local 0755 <<'EOLOC'
#!/bin/sh
# /etc/rc.d/rc.local - local startup hook
exit 0
EOLOC

  # /etc/inittab
  # - includes a dedicated supervisor line when enabled
  write_file /etc/inittab 0644 <<EOFIT
# /etc/inittab - SysVinit

id:\${DEFAULT_RUNLEVEL}:initdefault:
si::sysinit:/etc/rc.d/rcS

l0:0:wait:/etc/rc.d/rc 0
l1:1:wait:/etc/rc.d/rc 1
l2:2:wait:/etc/rc.d/rc 2
l3:3:wait:/etc/rc.d/rc 3
l4:4:wait:/etc/rc.d/rc 4
l5:5:wait:/etc/rc.d/rc 5
l6:6:wait:/etc/rc.d/rc 6

# Virtual consoles
EOFIT

  i=1
  while [ $i -le "$NUM_TTYS" ]; do
    printf '%s\n' "${i}:2345:respawn:/sbin/agetty ${TTY_SPEED} tty${i}" >>/etc/inittab
    i=$((i+1))
  done

  cat >>/etc/inittab <<'EOFIT2'

ca:12345:ctrlaltdel:/sbin/shutdown -t1 -a -r now
# Local startup hook (run once at boot)
rc::once:/etc/rc.d/rc.local
EOFIT2

  # Add supervisor line placeholder; enabled later if configured
  if [ "${SUPERVISION_ENABLE}" = "1" ]; then
    printf '%s\n' "" >>/etc/inittab
    printf '%s\n' "# Lightweight supervision (respawn)" >>/etc/inittab
    printf '%s\n' "sv:2345:respawn:/usr/bin/env SV_RESTART_DELAY=${SV_RESTART_DELAY} /usr/sbin/svscan" >>/etc/inittab
  fi
}

install_initd_services() {
  # sysklogd init script (if syslogd exists)
  write_file /etc/rc.d/init.d/sysklogd 0755 <<'EOSYS'
#!/bin/sh
set -eu
. /etc/rc.d/init.d/functions
PIDFILE=/run/syslogd.pid

case "${1:-}" in
  start)
    command -v syslogd >/dev/null 2>&1 || exit 0
    start_daemon "syslogd" "$PIDFILE" syslogd
    ;;
  stop)
    stop_daemon "syslogd" "$PIDFILE"
    ;;
  restart)
    "$0" stop || true
    "$0" start || true
    ;;
  *)
    echo "usage: $0 {start|stop|restart}"
    exit 1
    ;;
esac
exit 0
EOSYS


  # udev (eudev/udev) init script
  write_file /etc/rc.d/init.d/udev 0755 <<'EOUDEV'
#!/bin/sh
set -eu
. /etc/rc.d/init.d/functions

case "${1:-}" in
  start)
    # eudev uses udevd; some systems use systemd-udevd. Support both names.
    if command -v udevd >/dev/null 2>&1; then
      start_daemon "udevd" "/run/udevd.pid" udevd --daemon --pidfile=/run/udevd.pid
    elif command -v systemd-udevd >/dev/null 2>&1; then
      start_daemon "systemd-udevd" "/run/udevd.pid" systemd-udevd --daemon --pidfile=/run/udevd.pid
    else
      exit 0
    fi
    # trigger device events
    if command -v udevadm >/dev/null 2>&1; then
      udevadm trigger --action=add >/dev/null 2>&1 || true
      udevadm settle >/dev/null 2>&1 || true
    fi
    ;;
  stop)
    stop_daemon "udevd" "/run/udevd.pid" || true
    ;;
  restart)
    "$0" stop || true
    "$0" start || true
    ;;
  *)
    echo "usage: $0 {start|stop|restart}"
    exit 1
    ;;
esac
exit 0
EOUDEV

  # network init script (wired + optional DHCP)
  write_file /etc/rc.d/init.d/network 0755 <<'EONET'
#!/bin/sh
set -eu
. /etc/rc.d/init.d/functions

IFACE="${DEFAULT_IFACE:-eth0}"

dhcp_start() {
  if command -v dhcpcd >/dev/null 2>&1; then
    dhcpcd "$IFACE" >/dev/null 2>&1 || true
    log "dhcpcd started on $IFACE"
    return 0
  fi
  if command -v dhcpcd >/dev/null 2>&1; then
      dhcpcd "$IFACE" >/dev/null 2>&1 || true
    elif command -v udhcpc >/dev/null 2>&1; then
      dhcpcd "$IFACE" >/dev/null 2>&1 || true
    fi
    ;;
  stop)
    if command -v dhcpcd >/dev/null 2>&1; then
      dhcpcd -k "$IFACE" >/dev/null 2>&1 || true
    fi
    if [ -r "/run/udhcpc.$IFACE.pid" ]; then
      stop_daemon "udhcpc-$IFACE" "/run/udhcpc.$IFACE.pid"
    fi
    if command -v dhcpcd >/dev/null 2>&1; then
      dhcpcd -k "$IFACE" >/dev/null 2>&1 || true
    fi
    if [ -r "/run/wpa_supplicant.$IFACE.pid" ]; then
      stop_daemon "wpa_supplicant-$IFACE" "/run/wpa_supplicant.$IFACE.pid"
    fi
    command -v ip >/dev/null 2>&1 || exit 0
    ip link set "$IFACE" down 2>/dev/null || true
    ;;
  restart)
    "$0" stop || true
    "$0" start || true
    ;;
  *)
    echo "usage: $0 {start|stop|restart}"
    exit 1
    ;;
esac
exit 0
EOWIFI

  # Enable core services in rcS
  ln -sfn ../init.d/udev     /etc/rc.d/rcS.d/S05udev     2>/dev/null || true
  ln -sfn ../init.d/sysklogd /etc/rc.d/rcS.d/S20sysklogd 2>/dev/null || true
  ln -sfn ../init.d/network  /etc/rc.d/rcS.d/S10network  2>/dev/null || true

  # Wi-Fi is not enabled by default; user enables if desired.
}

configure_wifi_templates() {
  # Provide template config files; safe even if tools not installed yet.
  if [ ! -f /etc/wpa_supplicant.conf ]; then
    write_file /etc/wpa_supplicant.conf 0600 <<EOFWS
# /etc/wpa_supplicant.conf
# You can generate a secure PSK using:
#   wpa_passphrase "SSID" "passphrase"
#
country=\${WIFI_COUNTRY}
ctrl_interface=/run/wpa_supplicant
update_config=0

network={
    ssid="\${WIFI_SSID}"
    psk="\${WIFI_PSK}"
}
EOFWS
  fi

  mkdirp /etc/sysconfig
  if [ ! -f /etc/sysconfig/network ]; then
    write_file /etc/sysconfig/network 0644 <<EOFNET
# /etc/sysconfig/network
DEFAULT_IFACE="\${DEFAULT_IFACE}"
WIFI_IFACE="\${WIFI_IFACE}"
EOFNET
  fi
}

# ---------------------------------------------------------------------------
# Lightweight supervision (SysVinit respawn) - evolved
# - svscan supervises per-service supervisors in /etc/sv/services/<name>
# - Each service may have:
#     run       (required, must stay foreground)
#     log/run   (optional, foreground; if present, stdout/stderr piped into it)
# - Control via svctl (enable/disable/status/log)
# ---------------------------------------------------------------------------
install_supervision() {
  [ "\${SUPERVISION_ENABLE}" = "1" ] || return 0

  mkdirp "\${SV_BASE}/services" "\${SV_RUN}" "\${SV_LOG}"

  write_file /usr/sbin/svscan 0755 <<'EOSCAN'
#!/bin/sh
set -eu

SVBASE="/etc/sv/services"
RUNDIR="/run/sv"
LOGDIR="/var/log/sv"
DELAY="${SV_RESTART_DELAY:-2}"

mkdir -p "$RUNDIR" "$LOGDIR"

is_enabled() { [ -f "$SVBASE/$1/enabled" ]; }
down_flag() { [ -f "$RUNDIR/$1.down" ]; }

start_one() {
  name="$1"
  sup="$RUNDIR/$name.supervise"
  pidf="$RUNDIR/$name.pid"

  # avoid multiple supervisors
  if [ -r "$sup" ]; then
    spid="$(cat "$sup" 2>/dev/null || true)"
    [ -n "$spid" ] && kill -0 "$spid" 2>/dev/null && return 0
  fi

  (
    # per-service supervisor loop
    run="$SVBASE/$name/run"
    logrun="$SVBASE/$name/log/run"
    logfile="$LOGDIR/$name.log"

    [ -x "$run" ] || exit 0

    while :; do
      if down_flag "$name"; then
        sleep 1
        continue
      fi

      ts="$(date +%Y-%m-%dT%H:%M:%S 2>/dev/null || echo time)"
      printf '%s starting\n' "$ts" >>"$logfile" 2>/dev/null || true

      if [ -x "$logrun" ]; then
        # pipe service output to log service
        ( sh "$run" 2>&1; echo "rc=$?" ) | sh "$logrun" >>"$logfile" 2>/dev/null || true
      else
        sh "$run" >>"$logfile" 2>&1 || true
      fi

      ts="$(date +%Y-%m-%dT%H:%M:%S 2>/dev/null || echo time)"
      printf '%s exited; restart in %s\n' "$ts" "$DELAY" >>"$logfile" 2>/dev/null || true
      sleep "$DELAY"
    done
  ) &
  spid="$!"
  printf '%s\n' "$spid" >"$sup" 2>/dev/null || true
}

# main scan loop
while :; do
  if [ -d "$SVBASE" ]; then
    for d in "$SVBASE"/*; do
      [ -d "$d" ] || continue
      name="$(basename "$d")"
      is_enabled "$name" || continue
      start_one "$name" || true
    done
  fi
  sleep 2
done
EOSCAN

  write_file /usr/sbin/svctl 0755 <<'EOCTL'
#!/bin/sh
set -eu
NAME="${1:-}"; CMD="${2:-}"
[ -n "$NAME" ] && [ -n "$CMD" ] || { echo "usage: svctl <name> {enable|disable|up|down|status|log}" >&2; exit 1; }

SVBASE="/etc/sv/services"
RUNDIR="/run/sv"
LOGDIR="/var/log/sv"

case "$CMD" in
  enable)
    mkdir -p "$SVBASE/$NAME"
    : >"$SVBASE/$NAME/enabled"
    echo "enabled: $NAME"
    ;;
  disable)
    rm -f "$SVBASE/$NAME/enabled" 2>/dev/null || true
    : >"$RUNDIR/$NAME.down" 2>/dev/null || true
    echo "disabled: $NAME"
    ;;
  up)
    rm -f "$RUNDIR/$NAME.down" 2>/dev/null || true
    echo "up requested: $NAME"
    ;;
  down)
    : >"$RUNDIR/$NAME.down"
    echo "down requested: $NAME"
    ;;
  status)
    if [ -f "$RUNDIR/$NAME.down" ]; then
      echo "$NAME: down (flag)"
      exit 0
    fi
    sup="$RUNDIR/$NAME.supervise"
    if [ -r "$sup" ]; then
      spid="$(cat "$sup" 2>/dev/null || true)"
      if [ -n "$spid" ] && kill -0 "$spid" 2>/dev/null; then
        echo "$NAME: supervised (svscan pid $spid)"
        exit 0
      fi
    fi
    echo "$NAME: not supervised"
    ;;
  log)
    f="$LOGDIR/$NAME.log"
    if [ -r "$f" ]; then
      tail -n 200 "$f"
    else
      echo "no log: $f"
    fi
    ;;
  *)
    echo "unknown command: $CMD" >&2
    exit 1
    ;;
esac
exit 0
EOCTL

  # Provide example services, disabled by default.
  mkdirp "\${SV_BASE}/services/bootlog"
  write_file "\${SV_BASE}/services/bootlog/run" 0755 <<'EOBOOT'
#!/bin/sh
# Keeps a timestamp heartbeat in /var/log/sv/bootlog.log
exec /bin/sh -c 'while :; do date; sleep 30; done'
EOBOOT

  mkdirp "\${SV_BASE}/services/wifi"
  write_file "\${SV_BASE}/services/wifi/run" 0755 <<'EOWSR'
#!/bin/sh
# Foreground Wi-Fi manager:
# - starts wpa_supplicant in foreground if available
# - does DHCP if udhcpc or dhcpcd exists
# Requires: wpa_supplicant + (udhcpc or dhcpcd)
set -eu
IFACE="${WIFI_IFACE:-wlan0}"
CONF="/etc/wpa_supplicant.conf"

command -v ip >/dev/null 2>&1 || exit 0
ip link set "$IFACE" up 2>/dev/null || true

if command -v wpa_supplicant >/dev/null 2>&1 && [ -f "$CONF" ]; then
  # Start wpa_supplicant in foreground in background subshell so we can also do DHCP;
  # keep this script in foreground by waiting on the wpa process.
  wpa_supplicant -i "$IFACE" -c "$CONF" -f "/var/log/sv/wifi.wpa.log" &
  wpapid="$!"
else
  wpapid=""
fi

# DHCP (best-effort)
if command -v dhcpcd >/dev/null 2>&1; then
      dhcpcd "$IFACE" >/dev/null 2>&1 || true
    elif command -v udhcpc >/dev/null 2>&1; then
  dhcpcd "$IFACE" >/dev/null 2>&1 || true
fi

# Keep running if wpa is running; otherwise sleep loop.
if [ -n "$wpapid" ]; then
  wait "$wpapid" || true
else
  while :; do sleep 60; done
fi
EOWSR

  # Disabled by default; user enables with svctl wifi enable
}

final_validation() {
  # ensure essential files exist
  test -f /etc/inittab
  test -x /etc/rc.d/rcS
  test -x /etc/rc.d/rc
  # tools exist
  /bin/sh -c 'echo stage4-ok' >/dev/null 2>&1
  # sysvinit presence
  [ -x /sbin/init ] || [ -x /usr/sbin/init ] || true
}

say "==> Applying configuration (v2)"

ensure_minimal_accounts
configure_identity
configure_fstab_template
configure_shell_environment
configure_timezone_console
configure_networking_base
configure_shadow_defaults
configure_wifi_templates
install_sysv_layout
install_initd_services
install_supervision
final_validation

say "==> Configuration applied."
say "Important next steps:"
say " - Review /etc/fstab and set your real root device"
say " - If you want Wi-Fi supervision: install wpa_supplicant + dhcp client, set WIFI_SSID/WIFI_PSK, then: svctl wifi enable"
say " - After editing /etc/inittab: run 'telinit q' (on a running system)"
EOF
  chmod 0755 "$ROOT/.stage4-config/apply.sh"
}

run_in_chroot() {
  if [ ! -x "$ROOT/bin/sh" ]; then
    mkdirp "$ROOT/bin"
    ln -sf /tools/bin/bash "$ROOT/bin/sh"
  fi
  chroot "$ROOT" /usr/bin/env -i \
    HOME=/root TERM="${TERM:-xterm}" PS1='(config) \u:\w\$ ' \
    PATH=/usr/bin:/usr/sbin:/bin:/sbin:/tools/bin \
    /bin/sh -c "/.stage4-config/apply.sh"
}

###############################################################################
# Main
###############################################################################
need sh; need awk; need sed; need mount; need umount; need chroot
as_root

write_chroot_configurator

trap umount_vfs EXIT INT TERM HUP
mount_vfs
run_in_chroot

say "==> SUCCESS: configuration completed (v2)."
