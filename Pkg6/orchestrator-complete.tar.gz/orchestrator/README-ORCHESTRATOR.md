# Orchestrator — build completo em um comando (com retomada e paralelismo)

Este pacote adiciona o `orchestrate-build.sh`, que orquestra todos os stages em ordem correta:

1. toolchain
2. stage1
3. stage2
4. stage3
5. stage4
6. stage5
7. stage6 (kernel+initramfs+grub)
8. stage7 (pós-boot)
9. stage8 (QA/healthcheck)
10. stage9 (auto-remediation: plano por padrão)

## Execução (um comando)

```sh
chmod +x orchestrate-build.sh
sudo ./orchestrate-build.sh all
```

## Retomada (resume)
O orquestrador cria marcadores em:
- `${ROOT}/.orchestrator/<stage>.done`

Se o sistema cair no meio, basta reexecutar:
```sh
sudo ./orchestrate-build.sh all
```
Ele vai pular tudo o que já estiver marcado como concluído.

Para forçar rebuild:
```sh
sudo FORCE_REBUILD=1 ./orchestrate-build.sh all
```

## Paralelismo e desempenho
O orquestrador exporta:
- `MAKEFLAGS=-jN` (N = auto ou `JOBS=...`)
- `CFLAGS=-O2 -pipe` (default seguro)

Exemplos:
```sh
sudo JOBS=8 ./orchestrate-build.sh all
sudo LOAD_AVG_MULT=1 ./orchestrate-build.sh all
```

## Logs
Cada stage gera:
- `${ROOT}/.orchestrator/logs/<stage>.out`
- `${ROOT}/.orchestrator/logs/<stage>.err`
- `${ROOT}/.orchestrator/logs/<stage>.meta`

## Comandos úteis
- Ver status:
```sh
sudo ./orchestrate-build.sh status
```
- Recomeçar de um stage:
```sh
sudo ./orchestrate-build.sh from stage5
```

## Notas de segurança
O orquestrador não altera GRUB/partições por conta própria; ele apenas chama seus stages existentes.
