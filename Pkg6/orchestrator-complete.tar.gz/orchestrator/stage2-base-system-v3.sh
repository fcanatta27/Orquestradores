#!/bin/sh
# stage2-base-system.sh
# Build the base system inside $ROOT using chroot (Stage 2).
#
# Scope:
# - Installs the "base system" packages typically built after temporary tools,
#   into /usr, /bin, /lib, /sbin within the chroot.
# - Excludes kernel, bootloader, and distro-specific init integration.
#
# Design goals:
# - POSIX sh only
# - Variables at the top
# - Deterministic, logged, fail-fast
# - Integrity verification via LFS stable md5sums list (optionally replace with SHA256/PGP)
# - Post-install validations (version checks + minimal runtime tests)
#
# Usage:
#   ./stage2-base-system.sh          (runs host-side, mounts VFS, enters chroot, builds)
#
# License: MIT (see LICENSE)

###############################################################################
# User-configurable variables
###############################################################################
ROOT="/mnt/rootfs"
TOOLS="${ROOT}/tools"
LFS_STABLE_BASE="https://www.linuxfromscratch.org/lfs/downloads/stable"

# Workspace (inside ROOT so it is available inside chroot)
WORKDIR="${ROOT}/.stage2-build"
SRCDIR="${WORKDIR}/sources"
LOGDIR="${WORKDIR}/logs"

# Parallelism
JOBS="$(getconf _NPROCESSORS_ONLN 2>/dev/null || echo 1)"
MAKEFLAGS="-j${JOBS}"

# Safety toggles
ALLOW_ROOT="1"        # 0 = refuse to run as root
MOUNT_VFS="1"         # mount /dev /proc /sys /run
KEEP_WORKDIR="0"      # keep build trees inside chroot

###############################################################################
set -eu
umask 022
IFS="$(printf ' \t\n')"
export LC_ALL=C

say(){ printf '%s\n' "$*"; }
die(){ printf 'ERROR: %s\n' "$*" >&2; exit 1; }
have(){ command -v "$1" >/dev/null 2>&1; }
need(){ command -v "$1" >/dev/null 2>&1 || die "missing required command: $1"; }

as_user_warning() {
  if [ "$(id -u)" -eq 0 ] && [ "${ALLOW_ROOT}" != "1" ]; then
    die "refusing to run as root (ALLOW_ROOT=0)"
  fi
  [ "$(id -u)" -eq 0 ] || die "stage2 requires root (mounts + chroot)"
}

mkdirp(){ [ -d "$1" ] || mkdir -p "$1"; }

fetch() {
  url="$1"; out="$2"
  if [ -f "$out" ]; then return 0; fi
  if have curl; then
    curl -L --fail --retry 3 --retry-delay 2 -o "$out".tmp "$url"
  elif have wget; then
    wget -O "$out".tmp "$url"
  else
    die "need curl or wget"
  fi
  mv "$out".tmp "$out"
}

md5_file() {
  f="$1"
  if have md5sum; then md5sum "$f" | awk '{print $1}'
  elif have md5; then md5 -q "$f"
  else die "need md5sum (recommended) or md5"
  fi
}

verify_md5() {
  f="$1"; expected="$2"
  got="$(md5_file "$f")"
  [ "$got" = "$expected" ] || die "md5 mismatch for $(basename "$f"): expected $expected got $got"
}

ensure_lfs_lists() {
  mkdirp "$SRCDIR"
  cd "$SRCDIR"
  fetch "${LFS_STABLE_BASE}/wget-list" "wget-list"
  fetch "${LFS_STABLE_BASE}/md5sums" "md5sums"
}

download_pkg() {
  tarball="$1"
  ensure_lfs_lists
  cd "$SRCDIR"
  url="$(awk -v t="$tarball" '$0 ~ ("/" t "$") {print $0}' wget-list | head -n 1)"
  [ -n "$url" ] || die "tarball not found in LFS wget-list: $tarball"
  fetch "$url" "$tarball"
  expected="$(awk -v t="$tarball" '$2==t {print $1}' md5sums | head -n 1)"
  [ -n "$expected" ] || die "md5 not found in LFS md5sums for: $tarball"
  verify_md5 "$tarball" "$expected"
}

is_mounted() {
  mp="$1"
  if have mountpoint; then
    mountpoint -q "$mp" 2>/dev/null
  else
    [ -r /proc/mounts ] && awk -v m="$mp" '$2==m{f=1} END{exit(f?0:1)}' /proc/mounts
  fi
}

mount_vfs() {
  [ "${MOUNT_VFS}" = "1" ] || return 0
  mkdirp "$ROOT/dev" "$ROOT/proc" "$ROOT/sys" "$ROOT/run"
  is_mounted "$ROOT/dev" || mount --bind /dev "$ROOT/dev"
  is_mounted "$ROOT/dev/pts" || { mkdirp "$ROOT/dev/pts"; mount -t devpts devpts "$ROOT/dev/pts"; }
  is_mounted "$ROOT/proc" || mount -t proc proc "$ROOT/proc"
  is_mounted "$ROOT/sys" || mount -t sysfs sysfs "$ROOT/sys"
  is_mounted "$ROOT/run" || mount -t tmpfs tmpfs "$ROOT/run"
}

umount_vfs() {
  [ "${MOUNT_VFS}" = "1" ] || return 0
  umount -l "$ROOT/dev/pts" 2>/dev/null || true
  umount -l "$ROOT/dev" 2>/dev/null || true
  umount -l "$ROOT/proc" 2>/dev/null || true
  umount -l "$ROOT/sys" 2>/dev/null || true
  umount -l "$ROOT/run" 2>/dev/null || true
}

# Prepare minimal filesystem hierarchy and essential symlinks for a base system build.
prepare_rootfs() {
  # Create minimal directory hierarchy without relying on non-POSIX brace expansion.
  mkdirp "$ROOT/etc" "$ROOT/var" "$ROOT/usr" "$ROOT/usr/bin" "$ROOT/usr/lib" "$ROOT/usr/sbin"
  mkdirp "$ROOT/bin" "$ROOT/sbin" "$ROOT/lib" "$ROOT/root" "$ROOT/tmp" "$ROOT/run" "$ROOT/dev" "$ROOT/proc" "$ROOT/sys"

  chmod 1777 "$ROOT/tmp" 2>/dev/null || true

  # Optional "usr merge" symlinks:
  # If you want /bin -> /usr/bin etc., we do it only when it is safe.
  ensure_root_link() {
    link="$1" target="$2"
    if [ -L "$ROOT/$link" ]; then
      # Already a symlink; normalize it.
      ln -sfn "$target" "$ROOT/$link"
      return 0
    fi
    if [ -e "$ROOT/$link" ]; then
      # If it's a directory and empty, we can replace; otherwise leave it.
      if [ -d "$ROOT/$link" ] && [ -z "$(ls -A "$ROOT/$link" 2>/dev/null || true)" ]; then
        rmdir "$ROOT/$link" 2>/dev/null || true
      else
        return 0
      fi
    fi
    ln -sfn "$target" "$ROOT/$link"
  }

  # Enable usr-merge only if /bin,/sbin,/lib are empty or missing
  ensure_root_link "bin" "usr/bin"
  ensure_root_link "sbin" "usr/sbin"
  ensure_root_link "lib" "usr/lib"

  # Ensure /tools is visible inside chroot
  [ -e "$ROOT/tools" ] || ln -sfn "$TOOLS" "$ROOT/tools" 2>/dev/null || true

  # Ensure /bin/sh exists inside chroot (use temporary bash)
  if [ ! -x "$ROOT/bin/sh" ]; then
    mkdirp "$ROOT/bin"
    ln -sf /tools/bin/bash "$ROOT/bin/sh"
  fi
}

# Write chroot build script into ROOT and execute it
write_and_run_chroot_builder() {
  mkdirp "$WORKDIR" "$SRCDIR" "$LOGDIR"

  cat > "${ROOT}/.stage2-build/stage2-chroot.sh" <<'EOF'
set -eu
umask 022
export LC_ALL=C

say(){ printf '%s\n' "$*"; }
die(){ printf 'ERROR: %s\n' "$*" >&2; exit 1; }
have(){ command -v "$1" >/dev/null 2>&1; }
need(){ command -v "$1" >/dev/null 2>&1 || die "missing: $1"; }

WORKDIR="/.stage2-build"
SRCDIR="${WORKDIR}/sources"
BUILDDIR="${WORKDIR}/build"
LOGDIR="${WORKDIR}/logs-chroot"

JOBS="$(getconf _NPROCESSORS_ONLN 2>/dev/null || echo 1)"
MAKEFLAGS="-j${JOBS}"

mkdir -p "$BUILDDIR/src" "$LOGDIR"

run_logged(){
  name="$1"; shift
  logfile="${LOGDIR}/${name}.log"
  say "==> $name"
  ( "$@" ) >"$logfile" 2>&1 || die "$name failed; see $logfile"
}

extract_clean(){
  tb="$1"
  cd "$BUILDDIR/src"
  top="$(tar -tf "$SRCDIR/$tb" | awk -F/ 'NR==1{print $1}')"
  [ -n "$top" ] || die "cannot determine top dir for $tb"
  rm -rf "$top"
  tar -xf "$SRCDIR/$tb"
  printf '%s\n' "$BUILDDIR/src/$top"
}

# ===== Package build helpers =====
# NOTE: To keep this script "stage2" manageable, we implement the core base-system set.
# Kernel/bootloader are intentionally excluded.

build_zlib(){
  tb="$(ls "$SRCDIR"/zlib-*.tar.* | sed 's#.*/##' | head -n 1)"
  [ -n "$tb" ] || die "missing zlib tarball in $SRCDIR"
  src="$(extract_clean "$tb")"
  run_logged "zlib-configure" sh -c "cd '$src' && ./configure --prefix=/usr"
  run_logged "zlib-make" sh -c "cd '$src' && make ${MAKEFLAGS}"
  run_logged "zlib-install" sh -c "cd '$src' && make install"
  run_logged "zlib-validate" sh -c "test -f /usr/lib/libz.so || test -f /usr/lib64/libz.so"
}

build_bzip2(){
  tb="$(ls "$SRCDIR"/bzip2-*.tar.* | sed 's#.*/##' | head -n 1)"
  [ -n "$tb" ] || die "missing bzip2 tarball"
  src="$(extract_clean "$tb")"
  run_logged "bzip2-make" sh -c "cd '$src' && make ${MAKEFLAGS} -f Makefile-libbz2_so && make ${MAKEFLAGS}"
  run_logged "bzip2-install" sh -c "cd '$src' && make PREFIX=/usr install"
  run_logged "bzip2-validate" sh -c "printf 'x' | bzip2 -c | bzip2 -d -c | grep -qx 'x'"
}

build_xz(){
  tb="$(ls "$SRCDIR"/xz-*.tar.* | sed 's#.*/##' | head -n 1)"
  [ -n "$tb" ] || die "missing xz tarball"
  src="$(extract_clean "$tb")"
  b="${BUILDDIR}/build-xz"; rm -rf "$b"; mkdir -p "$b"
  run_logged "xz-configure" sh -c "cd '$b' && '$src/configure' --prefix=/usr --disable-static"
  run_logged "xz-make" sh -c "cd '$b' && make ${MAKEFLAGS}"
  run_logged "xz-install" sh -c "cd '$b' && make install"
  run_logged "xz-validate" sh -c "printf 'y' | xz -c | xz -d -c | grep -qx 'y'"
}

build_zstd(){
  tb="$(ls "$SRCDIR"/zstd-*.tar.* 2>/dev/null | sed 's#.*/##' | head -n 1 || true)"
  [ -n "$tb" ] || return 0
  src="$(extract_clean "$tb")"
  run_logged "zstd-make" sh -c "cd '$src' && make ${MAKEFLAGS}"
  run_logged "zstd-install" sh -c "cd '$src' && make prefix=/usr install"
  run_logged "zstd-validate" sh -c "zstd --version >/dev/null 2>&1"
}

build_file(){
  tb="$(ls "$SRCDIR"/file-*.tar.* | sed 's#.*/##' | head -n 1)"
  src="$(extract_clean "$tb")"
  b="${BUILDDIR}/build-file"; rm -rf "$b"; mkdir -p "$b"
  run_logged "file-configure" sh -c "cd '$b' && '$src/configure' --prefix=/usr"
  run_logged "file-make" sh -c "cd '$b' && make ${MAKEFLAGS}"
  run_logged "file-install" sh -c "cd '$b' && make install"
  run_logged "file-validate" sh -c "file --version >/dev/null 2>&1"
}

build_readline(){
  tb="$(ls "$SRCDIR"/readline-*.tar.* | sed 's#.*/##' | head -n 1)"
  src="$(extract_clean "$tb")"
  run_logged "readline-configure" sh -c "cd '$src' && ./configure --prefix=/usr --disable-static"
  run_logged "readline-make" sh -c "cd '$src' && make ${MAKEFLAGS}"
  run_logged "readline-install" sh -c "cd '$src' && make install"
  run_logged "readline-validate" sh -c "test -f /usr/lib/libreadline.so || test -f /usr/lib64/libreadline.so"
}

build_m4(){
  tb="$(ls "$SRCDIR"/m4-*.tar.* | sed 's#.*/##' | head -n 1)"
  src="$(extract_clean "$tb")"
  b="${BUILDDIR}/build-m4"; rm -rf "$b"; mkdir -p "$b"
  run_logged "m4-configure" sh -c "cd '$b' && '$src/configure' --prefix=/usr"
  run_logged "m4-make" sh -c "cd '$b' && make ${MAKEFLAGS}"
  run_logged "m4-install" sh -c "cd '$b' && make install"
  run_logged "m4-validate" sh -c "m4 --version | head -n 1 | grep -qi m4"
}

build_gmp_mpfr_mpc(){
  # gmp
  tb="$(ls "$SRCDIR"/gmp-*.tar.* | sed 's#.*/##' | head -n 1)"
  src="$(extract_clean "$tb")"
  b="${BUILDDIR}/build-gmp"; rm -rf "$b"; mkdir -p "$b"
  run_logged "gmp-configure" sh -c "cd '$b' && '$src/configure' --prefix=/usr --enable-cxx --disable-static"
  run_logged "gmp-make" sh -c "cd '$b' && make ${MAKEFLAGS}"
  run_logged "gmp-install" sh -c "cd '$b' && make install"
  # mpfr
  tb="$(ls "$SRCDIR"/mpfr-*.tar.* | sed 's#.*/##' | head -n 1)"
  src="$(extract_clean "$tb")"
  b="${BUILDDIR}/build-mpfr"; rm -rf "$b"; mkdir -p "$b"
  run_logged "mpfr-configure" sh -c "cd '$b' && '$src/configure' --prefix=/usr --disable-static --with-gmp=/usr"
  run_logged "mpfr-make" sh -c "cd '$b' && make ${MAKEFLAGS}"
  run_logged "mpfr-install" sh -c "cd '$b' && make install"
  # mpc
  tb="$(ls "$SRCDIR"/mpc-*.tar.* | sed 's#.*/##' | head -n 1)"
  src="$(extract_clean "$tb")"
  b="${BUILDDIR}/build-mpc"; rm -rf "$b"; mkdir -p "$b"
  run_logged "mpc-configure" sh -c "cd '$b' && '$src/configure' --prefix=/usr --disable-static --with-gmp=/usr --with-mpfr=/usr"
  run_logged "mpc-make" sh -c "cd '$b' && make ${MAKEFLAGS}"
  run_logged "mpc-install" sh -c "cd '$b' && make install"
  run_logged "gmpstack-validate" sh -c "printf 'int main(){return 0;}\n' | gcc -x c - -o /tmp/t && /tmp/t"
}

build_binutils(){
  tb="$(ls "$SRCDIR"/binutils-*.tar.* | sed 's#.*/##' | head -n 1)"
  src="$(extract_clean "$tb")"
  b="${BUILDDIR}/build-binutils"; rm -rf "$b"; mkdir -p "$b"
  run_logged "binutils-configure" sh -c "cd '$b' && '$src/configure' --prefix=/usr --disable-nls --enable-shared --disable-werror"
  run_logged "binutils-make" sh -c "cd '$b' && make ${MAKEFLAGS}"
  run_logged "binutils-install" sh -c "cd '$b' && make install"
  run_logged "binutils-validate" sh -c "ld -v >/dev/null 2>&1"
}

build_gcc(){
  tb="$(ls "$SRCDIR"/gcc-*.tar.* | sed 's#.*/##' | head -n 1)"
  src="$(extract_clean "$tb")"
  # Ensure prereqs if GCC ships helper
  run_logged "gcc-prereqs" sh -c "cd '$src' && (contrib/download_prerequisites >/dev/null 2>&1 || true)"
  b="${BUILDDIR}/build-gcc"; rm -rf "$b"; mkdir -p "$b"
  run_logged "gcc-configure" sh -c "cd '$b' && '$src/configure' --prefix=/usr --disable-multilib --enable-languages=c,c++"
  run_logged "gcc-make" sh -c "cd '$b' && make ${MAKEFLAGS}"
  run_logged "gcc-install" sh -c "cd '$b' && make install"
  # Minimal validation: compile and run
  run_logged "gcc-validate" sh -c "printf 'int main(){return 0;}\n' | gcc -x c - -o /tmp/ccok && /tmp/ccok"
}

build_glibc(){
  tb="$(ls "$SRCDIR"/glibc-*.tar.* | sed 's#.*/##' | head -n 1)"
  src="$(extract_clean "$tb")"
  b="${BUILDDIR}/build-glibc"; rm -rf "$b"; mkdir -p "$b"
  run_logged "glibc-configure" sh -c "cd '$b' && '$src/configure' --prefix=/usr --disable-werror"
  run_logged "glibc-make" sh -c "cd '$b' && make ${MAKEFLAGS}"
  run_logged "glibc-install" sh -c "cd '$b' && make install"
  run_logged "glibc-validate" sh -c "/usr/bin/ldd --version >/dev/null 2>&1 || true"
}

build_coreutils(){
  tb="$(ls "$SRCDIR"/coreutils-*.tar.* | sed 's#.*/##' | head -n 1)"
  src="$(extract_clean "$tb")"
  b="${BUILDDIR}/build-coreutils"; rm -rf "$b"; mkdir -p "$b"
  run_logged "coreutils-configure" sh -c "cd '$b' && '$src/configure' --prefix=/usr --enable-install-program=hostname"
  run_logged "coreutils-make" sh -c "cd '$b' && make ${MAKEFLAGS}"
  run_logged "coreutils-install" sh -c "cd '$b' && make install"
  run_logged "coreutils-validate" sh -c "/usr/bin/ls --version >/dev/null 2>&1"
}

build_bash(){
  tb="$(ls "$SRCDIR"/bash-*.tar.* | sed 's#.*/##' | head -n 1)"
  src="$(extract_clean "$tb")"
  b="${BUILDDIR}/build-bash"; rm -rf "$b"; mkdir -p "$b"
  run_logged "bash-configure" sh -c "cd '$b' && '$src/configure' --prefix=/usr --without-bash-malloc"
  run_logged "bash-make" sh -c "cd '$b' && make ${MAKEFLAGS}"
  run_logged "bash-install" sh -c "cd '$b' && make install"
  ln -sf bash /bin/sh
  run_logged "bash-validate" sh -c "/bin/sh -c 'echo ok' | grep -qx ok"
}

build_grep_sed_gawk(){
  # grep
  tb="$(ls "$SRCDIR"/grep-*.tar.* | sed 's#.*/##' | head -n 1)"
  src="$(extract_clean "$tb")"
  b="${BUILDDIR}/build-grep"; rm -rf "$b"; mkdir -p "$b"
  run_logged "grep-configure" sh -c "cd '$b' && '$src/configure' --prefix=/usr"
  run_logged "grep-make" sh -c "cd '$b' && make ${MAKEFLAGS}"
  run_logged "grep-install" sh -c "cd '$b' && make install"
  run_logged "grep-validate" sh -c "printf 'abc\n' | /usr/bin/grep -q ab"
  # sed
  tb="$(ls "$SRCDIR"/sed-*.tar.* | sed 's#.*/##' | head -n 1)"
  src="$(extract_clean "$tb")"
  b="${BUILDDIR}/build-sed"; rm -rf "$b"; mkdir -p "$b"
  run_logged "sed-configure" sh -c "cd '$b' && '$src/configure' --prefix=/usr"
  run_logged "sed-make" sh -c "cd '$b' && make ${MAKEFLAGS}"
  run_logged "sed-install" sh -c "cd '$b' && make install"
  run_logged "sed-validate" sh -c "printf 'a\n' | /usr/bin/sed 's/a/b/' | grep -qx b"
  # gawk
  tb="$(ls "$SRCDIR"/gawk-*.tar.* | sed 's#.*/##' | head -n 1)"
  src="$(extract_clean "$tb")"
  b="${BUILDDIR}/build-gawk"; rm -rf "$b"; mkdir -p "$b"
  run_logged "gawk-configure" sh -c "cd '$b' && '$src/configure' --prefix=/usr"
  run_logged "gawk-make" sh -c "cd '$b' && make ${MAKEFLAGS}"
  run_logged "gawk-install" sh -c "cd '$b' && make install"
  run_logged "gawk-validate" sh -c "printf 'x\n' | /usr/bin/gawk '{print}' | grep -qx x"
}

build_make(){
  tb="$(ls "$SRCDIR"/make-*.tar.* | sed 's#.*/##' | head -n 1)"
  src="$(extract_clean "$tb")"
  b="${BUILDDIR}/build-make"; rm -rf "$b"; mkdir -p "$b"
  run_logged "make-configure" sh -c "cd '$b' && '$src/configure' --prefix=/usr"
  run_logged "make-make" sh -c "cd '$b' && make ${MAKEFLAGS}"
  run_logged "make-install" sh -c "cd '$b' && make install"
  run_logged "make-validate" sh -c "make --version | head -n 1 | grep -q Make"
}

final_sanity(){
  run_logged "sanity-compiler" sh -c "printf 'int main(){return 0;}\n' | gcc -x c - -o /tmp/a && /tmp/a"
  run_logged "sanity-shell" sh -c "/bin/sh -c 'echo stage2-ok' | grep -qx stage2-ok"
  run_logged "sanity-coreutils" sh -c "/usr/bin/printf '%s\n' ok | /usr/bin/head -n 1 | grep -qx ok"
}

say "==> Stage2 (base system) starting"

# Minimal required tools in chroot
need sh; need make; need tar; need awk; need sed; need grep
need /tools/bin/bash

# Ensure PATH favors /usr first, but keep /tools for bootstrap
export PATH=/usr/bin:/usr/sbin:/bin:/sbin:/tools/bin

# Build order (bootstrap-friendly)
build_zlib
build_bzip2
build_xz
build_zstd
build_file
build_readline
build_m4
build_glibc
build_gmp_mpfr_mpc
build_binutils
build_gcc
build_coreutils
build_bash
build_grep_sed_gawk
build_make

final_sanity

say "==> Stage2 complete. Logs: $LOGDIR"

EOF

  chmod 0755 "${ROOT}/.stage2-build/stage2-chroot.sh"

  chroot "$ROOT" /usr/bin/env -i \
    HOME=/root TERM="${TERM:-xterm}" PS1='(stage2) \u:\w\$ ' \
    PATH=/usr/bin:/usr/sbin:/bin:/sbin:/tools/bin \
    /bin/sh -c "/.stage2-build/stage2-chroot.sh"
}

###############################################################################
# Main
###############################################################################
need sh
need tar
need awk
need sed
need chroot
need mount
need umount

as_user_warning

mkdirp "$WORKDIR" "$SRCDIR" "$LOGDIR"

# Ensure required tarballs are present (download + md5 verify)
# Note: This is the minimal "base system" set implemented in stage2-chroot.sh.
# If you want a full LFS Chapter 8 coverage, extend this list following the same pattern.
for tb in \
  zlib-*.tar.* \
  bzip2-*.tar.* \
  xz-*.tar.* \
  zstd-*.tar.* \
  file-*.tar.* \
  readline-*.tar.* \
  m4-*.tar.* \
  glibc-*.tar.* \
  gmp-*.tar.* \
  mpfr-*.tar.* \
  mpc-*.tar.* \
  binutils-*.tar.* \
  gcc-*.tar.* \
  coreutils-*.tar.* \
  bash-*.tar.* \
  grep-*.tar.* \
  sed-*.tar.* \
  gawk-*.tar.* \
  make-*.tar.*
do
  # If pattern already matches files in SRCDIR, skip downloads.
  set +e
  ls "$SRCDIR"/$tb >/dev/null 2>&1
  have_it=$?
  set -e
  if [ $have_it -ne 0 ]; then
    # Choose a concrete tarball name from wget-list based on the pattern prefix.
    prefix="$(printf '%s' "$tb" | sed 's/\*.*//')"
    ensure_lfs_lists
    cd "$SRCDIR"
    real="$(awk -v p="$prefix" '$0 ~ ("/" p) {sub(".*/","",$0); print $0}' wget-list | head -n 1)"
    [ -n "$real" ] || die "could not resolve tarball for pattern: $tb"
    download_pkg "$real"
  fi
done

prepare_rootfs

trap umount_vfs EXIT INT TERM HUP
mount_vfs
write_and_run_chroot_builder

say "==> SUCCESS: Stage2 base system built."
say "Chroot logs: ${ROOT}/.stage2-build/logs-chroot"
