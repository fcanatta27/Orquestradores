#!/bin/sh
# stage6-kernel-initramfs-grub.sh
# Build and install: Linux kernel + initramfs + GRUB (BIOS by default)
# plus any remaining CLI "completion" packages needed for a bootable system.
#
# Strategy:
# - Use LFS stable wget-list + md5sums for versions known to work with the book. citeturn0search11turn1search1
# - Download sources on host, verify md5, build inside chroot.
# - Kernel: defconfig + minimal required options, install modules + vmlinuz + config + System.map.
# - Initramfs: generate minimal initramfs that mounts the real root and switch_root to /sbin/init.
# - GRUB: build + install (BIOS) and generate /boot/grub/grub.cfg.
#
# POSIX sh only. Variables at top.
#
# License: MIT (see LICENSE)

###############################################################################
# User-configurable variables
###############################################################################
ROOT="/mnt/rootfs"
TOOLS="${ROOT}/tools"

LFS_STABLE_BASE="https://www.linuxfromscratch.org/lfs/downloads/stable"

WORKDIR="${ROOT}/.stage6-build"
SRCDIR="${WORKDIR}/sources"
LOGDIR="${WORKDIR}/logs"

JOBS="$(getconf _NPROCESSORS_ONLN 2>/dev/null || echo 1)"
MAKEFLAGS="-j${JOBS}"

# Boot / target
BOOTDIR="/boot"

# Root filesystem identification for initramfs (choose one):
# 1) ROOT_DEVICE="/dev/sda2"   OR
# 2) ROOT_UUID="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
ROOT_DEVICE=""
ROOT_UUID=""

# GRUB install target disk for BIOS install (e.g., /dev/sda). REQUIRED for grub-install.
GRUB_DISK="/dev/sda"

# Kernel config choices
KERNEL_LOCALVERSION="-custom"
KERNEL_DEFCONFIG="defconfig"        # usually "defconfig" is fine for x86_64
KERNEL_ENABLE_DEVTMPFS="1"
KERNEL_ENABLE_INITRD="1"

# Initramfs name
INITRAMFS_NAME="initramfs.img"

# Safety
ALLOW_ROOT="1"
MOUNT_VFS="1"
KEEP_WORKDIR="0"

###############################################################################
set -eu
umask 022
IFS="$(printf ' \t\n')"
export LC_ALL=C

say(){ printf '%s\n' "$*"; }
die(){ printf 'ERROR: %s\n' "$*" >&2; exit 1; }
have(){ command -v "$1" >/dev/null 2>&1; }
need(){ command -v "$1" >/dev/null 2>&1 || die "missing required command: $1"; }
mkdirp(){ [ -d "$1" ] || mkdir -p "$1"; }

as_root() {
  if [ "$(id -u)" -eq 0 ] && [ "${ALLOW_ROOT}" != "1" ]; then
    die "refusing to run as root (ALLOW_ROOT=0)"
  fi
  [ "$(id -u)" -eq 0 ] || die "stage6 requires root (mounts + chroot)"
}

fetch() {
  url="$1"; out="$2"
  [ -f "$out" ] && return 0
  if have curl; then
    curl -L --fail --retry 3 --retry-delay 2 -o "$out".tmp "$url"
  elif have wget; then
    wget -O "$out".tmp "$url"
  else
    die "need curl or wget"
  fi
  mv "$out".tmp "$out"
}

md5_file() {
  f="$1"
  if have md5sum; then md5sum "$f" | awk '{print $1}'
  elif have md5; then md5 -q "$f"
  else die "need md5sum (recommended) or md5"
  fi
}

verify_md5() {
  f="$1"; expected="$2"
  got="$(md5_file "$f")"
  [ "$got" = "$expected" ] || die "md5 mismatch for $(basename "$f"): expected $expected got $got"
}

ensure_lfs_lists() {
  mkdirp "$SRCDIR"
  cd "$SRCDIR"
  fetch "${LFS_STABLE_BASE}/wget-list" "wget-list"
  fetch "${LFS_STABLE_BASE}/md5sums" "md5sums"
}

resolve_tarball() {
  prefix="$1"
  ensure_lfs_lists
  cd "$SRCDIR"
  tb="$(awk -v p="$prefix" '$0 ~ ("/" p) {sub(".*/","",$0); print $0}' wget-list | head -n 1)"
  [ -n "$tb" ] || die "could not resolve tarball for prefix: $prefix (not in LFS stable wget-list)"
  printf '%s\n' "$tb"
}

download_pkg() {
  tarball="$1"
  ensure_lfs_lists
  cd "$SRCDIR"
  url="$(awk -v t="$tarball" '$0 ~ ("/" t "$") {print $0}' wget-list | head -n 1)"
  [ -n "$url" ] || die "tarball not found in LFS wget-list: $tarball"
  fetch "$url" "$tarball"
  expected="$(awk -v t="$tarball" '$2==t {print $1}' md5sums | head -n 1)"
  [ -n "$expected" ] || die "md5 not found in LFS md5sums for: $tarball"
  verify_md5 "$tarball" "$expected"
}

is_mounted() {
  mp="$1"
  if have mountpoint; then
    mountpoint -q "$mp" 2>/dev/null
  else
    [ -r /proc/mounts ] && awk -v m="$mp" '$2==m{f=1} END{exit(f?0:1)}' /proc/mounts
  fi
}

mount_vfs() {
  [ "${MOUNT_VFS}" = "1" ] || return 0
  mkdirp "$ROOT/dev" "$ROOT/proc" "$ROOT/sys" "$ROOT/run"
  is_mounted "$ROOT/dev" || mount --bind /dev "$ROOT/dev"
  is_mounted "$ROOT/dev/pts" || { mkdirp "$ROOT/dev/pts"; mount -t devpts devpts "$ROOT/dev/pts"; }
  is_mounted "$ROOT/proc" || mount -t proc proc "$ROOT/proc"
  is_mounted "$ROOT/sys" || mount -t sysfs sysfs "$ROOT/sys"
  is_mounted "$ROOT/run" || mount -t tmpfs tmpfs "$ROOT/run"
}

umount_vfs() {
  [ "${MOUNT_VFS}" = "1" ] || return 0
  umount -l "$ROOT/dev/pts" 2>/dev/null || true
  umount -l "$ROOT/dev" 2>/dev/null || true
  umount -l "$ROOT/proc" 2>/dev/null || true
  umount -l "$ROOT/sys" 2>/dev/null || true
  umount -l "$ROOT/run" 2>/dev/null || true
}

write_chroot_script() {
  mkdirp "$WORKDIR" "$SRCDIR" "$LOGDIR"
  cat > "${ROOT}/.stage6-build/stage6-chroot.sh" <<EOF
set -eu
umask 022
export LC_ALL=C

say(){ printf '%s\n' "\$*"; }
die(){ printf 'ERROR: %s\n' "\$*" >&2; exit 1; }
need(){ command -v "\$1" >/dev/null 2>&1 || die "missing: \$1"; }

WORKDIR="/.stage6-build"
SRCDIR="\${WORKDIR}/sources"
BUILDDIR="\${WORKDIR}/build"
LOGDIR="\${WORKDIR}/logs-chroot"
JOBS="\$(getconf _NPROCESSORS_ONLN 2>/dev/null || echo 1)"
MAKEFLAGS="-j\${JOBS}"

BOOTDIR='${BOOTDIR}'
ROOT_DEVICE='${ROOT_DEVICE}'
ROOT_UUID='${ROOT_UUID}'
GRUB_DISK='${GRUB_DISK}'
KERNEL_LOCALVERSION='${KERNEL_LOCALVERSION}'
KERNEL_DEFCONFIG='${KERNEL_DEFCONFIG}'
KERNEL_ENABLE_DEVTMPFS='${KERNEL_ENABLE_DEVTMPFS}'
KERNEL_ENABLE_INITRD='${KERNEL_ENABLE_INITRD}'
INITRAMFS_NAME='${INITRAMFS_NAME}'

mkdir -p "\$BUILDDIR/src" "\$LOGDIR"

run_logged(){
  name="\$1"; shift
  logfile="\${LOGDIR}/\${name}.log"
  say "==> \$name"
  ( "\$@" ) >"\$logfile" 2>&1 || die "\$name failed; see \$logfile"
}

extract_clean(){
  tb="\$1"
  cd "\$BUILDDIR/src"
  top="\$(tar -tf "\$SRCDIR/\$tb" | awk -F/ 'NR==1{print \$1}')"
  [ -n "\$top" ] || die "cannot determine top dir for \$tb"
  rm -rf "\$top"
  tar -xf "\$SRCDIR/\$tb"
  printf '%s\n' "\$BUILDDIR/src/\$top"
}

export PATH=/usr/bin:/usr/sbin:/bin:/sbin:/tools/bin

need sh; need make; need tar; need awk; need sed; need grep
need gcc; need ld; need ar

# Ensure build helpers exist for kernel/grub
ensure_bc_bison_flex(){
  if ! command -v bc >/dev/null 2>&1; then
    tb="\$(ls "\$SRCDIR"/bc-*.tar.* 2>/dev/null | head -n 1 | sed 's#.*/##')"
    [ -n "\$tb" ] || die "bc tarball missing"
    src="\$(extract_clean "\$tb")"
    b="\${BUILDDIR}/build-bc"; rm -rf "\$b"; mkdir -p "\$b"
    run_logged "bc-configure" sh -c "cd '\$b' && '\$src/configure' --prefix=/usr --with-readline"
    run_logged "bc-make" sh -c "cd '\$b' && make \${MAKEFLAGS}"
    run_logged "bc-install" sh -c "cd '\$b' && make install"
  fi
  if ! command -v bison >/dev/null 2>&1; then
    tb="\$(ls "\$SRCDIR"/bison-*.tar.* 2>/dev/null | head -n 1 | sed 's#.*/##')"
    [ -n "\$tb" ] || die "bison tarball missing"
    src="\$(extract_clean "\$tb")"
    b="\${BUILDDIR}/build-bison"; rm -rf "\$b"; mkdir -p "\$b"
    run_logged "bison-configure" sh -c "cd '\$b' && '\$src/configure' --prefix=/usr --docdir=/usr/share/doc/bison"
    run_logged "bison-make" sh -c "cd '\$b' && make \${MAKEFLAGS}"
    run_logged "bison-install" sh -c "cd '\$b' && make install"
  fi
  if ! command -v flex >/dev/null 2>&1; then
    tb="\$(ls "\$SRCDIR"/flex-*.tar.* 2>/dev/null | head -n 1 | sed 's#.*/##')"
    [ -n "\$tb" ] || die "flex tarball missing"
    src="\$(extract_clean "\$tb")"
    b="\${BUILDDIR}/build-flex"; rm -rf "\$b"; mkdir -p "\$b"
    run_logged "flex-configure" sh -c "cd '\$b' && '\$src/configure' --prefix=/usr --disable-static"
    run_logged "flex-make" sh -c "cd '\$b' && make \${MAKEFLAGS}"
    run_logged "flex-install" sh -c "cd '\$b' && make install"
    run_logged "flex-link" sh -c "ln -sf flex /usr/bin/lex"
  fi
}

build_kernel(){
  tb="\$(ls "\$SRCDIR"/linux-*.tar.* 2>/dev/null | head -n 1 | sed 's#.*/##')"
  [ -n "\$tb" ] || die "linux tarball missing"
  src="\$(extract_clean "\$tb")"

  # Determine kernel version from extracted dir name
  kver="\$(basename "\$src" | sed 's/^linux-//')"
  say "Kernel version: \$kver"

  run_logged "linux-clean" sh -c "cd '\$src' && make mrproper"

  # default config
  run_logged "linux-defconfig" sh -c "cd '\$src' && make \${KERNEL_DEFCONFIG}"

  # Apply essential config toggles
  if [ "\${KERNEL_ENABLE_DEVTMPFS}" = "1" ]; then
    run_logged "linux-set-devtmpfs" sh -c "cd '\$src' && scripts/config --enable DEVTMPFS --enable DEVTMPFS_MOUNT || true"
  fi
  if [ "\${KERNEL_ENABLE_INITRD}" = "1" ]; then
    run_logged "linux-set-initrd" sh -c "cd '\$src' && scripts/config --enable BLK_DEV_INITRD || true"
  fi
  # localversion
  run_logged "linux-localversion" sh -c "cd '\$src' && printf '%s\n' '\${KERNEL_LOCALVERSION}' > localversion.1"

  # Build kernel + modules
  run_logged "linux-build" sh -c "cd '\$src' && make \${MAKEFLAGS}"
  run_logged "linux-modules-install" sh -c "cd '\$src' && make modules_install"

  # Install into /boot
  mkdir -p "\$BOOTDIR"
  run_logged "linux-install" sh -c "cd '\$src' && cp -v arch/x86/boot/bzImage '\$BOOTDIR/vmlinuz-\$kver\${KERNEL_LOCALVERSION}' && cp -v System.map '\$BOOTDIR/System.map-\$kver\${KERNEL_LOCALVERSION}' && cp -v .config '\$BOOTDIR/config-\$kver\${KERNEL_LOCALVERSION}'"

  # Symlinks
  run_logged "linux-symlinks" sh -c "ln -sfn 'vmlinuz-\$kver\${KERNEL_LOCALVERSION}' '\$BOOTDIR/vmlinuz' && ln -sfn 'System.map-\$kver\${KERNEL_LOCALVERSION}' '\$BOOTDIR/System.map' && ln -sfn 'config-\$kver\${KERNEL_LOCALVERSION}' '\$BOOTDIR/config'"

  printf '%s\n' "\$kver" > "\${WORKDIR}/kernel-version"
}

copy_binary_and_libs(){
  # Copies binary and its shared libs into initramfs tree.
  # Usage: copy_binary_and_libs /path/to/bin DESTDIR
  bin="\$1"; dest="\$2"
  [ -x "\$bin" ] || die "missing binary: \$bin"
  mkdir -p "\$dest\$(dirname "\$bin")"
  cp -a "\$bin" "\$dest\$(dirname "\$bin")/"

  if command -v ldd >/dev/null 2>&1; then
    ldd "\$bin" 2>/dev/null | awk '{print \$3}' | grep '^/' | while IFS= read -r lib; do
      [ -f "\$lib" ] || continue
      mkdir -p "\$dest\$(dirname "\$lib")"
      cp -a "\$lib" "\$dest\$(dirname "\$lib")/"
    done
  fi
  # dynamic loader (ld-linux) path varies; capture from ldd header line
  if command -v ldd >/dev/null 2>&1; then
    ldso="\$(ldd "\$bin" 2>/dev/null | awk '/ld-linux|ld-musl/{print \$1}' | head -n 1)"
    if [ -n "\$ldso" ] && [ -f "\$ldso" ]; then
      mkdir -p "\$dest\$(dirname "\$ldso")"
      cp -a "\$ldso" "\$dest\$(dirname "\$ldso")/" || true
    fi
  fi
}

build_initramfs(){
  kver="\$(cat "\${WORKDIR}/kernel-version")"
  out="\$BOOTDIR/\${INITRAMFS_NAME%.*}-\$kver\${KERNEL_LOCALVERSION}.img"
  tmp="\${BUILDDIR}/initramfs"
  rm -rf "\$tmp"
  mkdir -p "\$tmp"/{bin,sbin,etc,proc,sys,dev,run,mnt/root}

  # Minimal /init (POSIX sh via bash)
  cat > "\$tmp/init" <<'EOINIT'
#!/bin/sh
set -eu
mount -t proc proc /proc 2>/dev/null || true
mount -t sysfs sysfs /sys 2>/dev/null || true
mount -t devtmpfs devtmpfs /dev 2>/dev/null || true
mount -t tmpfs tmpfs /run 2>/dev/null || true

ROOT_DEVICE="@ROOT_DEVICE@"
ROOT_UUID="@ROOT_UUID@"

if [ -n "$ROOT_UUID" ]; then
  rootdev="/dev/disk/by-uuid/$ROOT_UUID"
else
  rootdev="$ROOT_DEVICE"
fi

[ -n "$rootdev" ] || { echo "initramfs: ROOT not set"; exec sh; }

mkdir -p /mnt/root
mount "$rootdev" /mnt/root || { echo "initramfs: mount failed: $rootdev"; exec sh; }

# Ensure essential mounts are available after switch_root
mkdir -p /mnt/root/proc /mnt/root/sys /mnt/root/dev /mnt/root/run
mount --move /proc /mnt/root/proc 2>/dev/null || true
mount --move /sys /mnt/root/sys 2>/dev/null || true
mount --move /dev /mnt/root/dev 2>/dev/null || true
mount --move /run /mnt/root/run 2>/dev/null || true

exec switch_root /mnt/root /sbin/init
EOINIT
  # inject variables safely
  sed -i "s|@ROOT_DEVICE@|${ROOT_DEVICE}|g; s|@ROOT_UUID@|${ROOT_UUID}|g" "\$tmp/init"
  chmod 0755 "\$tmp/init"

  # Required binaries for init
  copy_binary_and_libs /bin/bash "\$tmp"
  # provide /bin/sh
  ln -s bash "\$tmp/bin/sh"

  # mount + switch_root + basic tools
  if command -v mount >/dev/null 2>&1; then copy_binary_and_libs "\$(command -v mount)" "\$tmp"; fi
  if command -v switch_root >/dev/null 2>&1; then copy_binary_and_libs "\$(command -v switch_root)" "\$tmp"; fi
  if command -v sed >/dev/null 2>&1; then copy_binary_and_libs "\$(command -v sed)" "\$tmp"; fi
  if command -v mkdir >/dev/null 2>&1; then copy_binary_and_libs "\$(command -v mkdir)" "\$tmp"; fi
  if command -v ln >/dev/null 2>&1; then copy_binary_and_libs "\$(command -v ln)" "\$tmp"; fi
  if command -v cat >/dev/null 2>&1; then copy_binary_and_libs "\$(command -v cat)" "\$tmp"; fi
  if command -v echo >/dev/null 2>&1; then copy_binary_and_libs "\$(command -v echo)" "\$tmp" || true; fi

  # Create cpio archive
  run_logged "initramfs-pack" sh -c "cd '\$tmp' && find . -print0 | cpio --null -ov --format=newc | gzip -9 > '\$out'"
  ln -sfn "\$(basename "\$out")" "\$BOOTDIR/\${INITRAMFS_NAME}"
}

build_grub(){
  tb="\$(ls "\$SRCDIR"/grub-*.tar.* 2>/dev/null | head -n 1 | sed 's#.*/##')"
  [ -n "\$tb" ] || die "grub tarball missing"
  src="\$(extract_clean "\$tb")"
  b="\${BUILDDIR}/build-grub"; rm -rf "\$b"; mkdir -p "\$b"

  # BIOS target build (UEFI is handled in BLFS separately). citeturn1search17
  run_logged "grub-configure" sh -c "cd '\$b' && '\$src/configure' --prefix=/usr --sbindir=/sbin --sysconfdir=/etc --disable-efiemu --disable-werror"
  run_logged "grub-make" sh -c "cd '\$b' && make \${MAKEFLAGS}"
  run_logged "grub-install-files" sh -c "cd '\$b' && make install"
  run_logged "grub-validate" sh -c "/sbin/grub-install --version >/dev/null 2>&1 || /usr/sbin/grub-install --version >/dev/null 2>&1"
}

write_grub_cfg(){
  kver="\$(cat "\${WORKDIR}/kernel-version")"
  kimg="\$BOOTDIR/vmlinuz-\$kver\${KERNEL_LOCALVERSION}"
  iimg="\$BOOTDIR/\${INITRAMFS_NAME%.*}-\$kver\${KERNEL_LOCALVERSION}.img"
  [ -f "\$kimg" ] || die "kernel image missing: \$kimg"
  [ -f "\$iimg" ] || die "initramfs missing: \$iimg"

  mkdir -p "\$BOOTDIR/grub"
  rootarg=""
  if [ -n "\$ROOT_UUID" ]; then
    rootarg="root=UUID=\$ROOT_UUID"
  elif [ -n "\$ROOT_DEVICE" ]; then
    rootarg="root=\$ROOT_DEVICE"
  else
    die "ROOT_DEVICE or ROOT_UUID must be set for grub.cfg"
  fi

  cat > "\$BOOTDIR/grub/grub.cfg" <<EOFGRUB
set default=0
set timeout=3

menuentry "Linux (LFS custom) \$kver\${KERNEL_LOCALVERSION}" {
    linux   /vmlinuz-\$kver\${KERNEL_LOCALVERSION} \$rootarg ro
    initrd  /\${INITRAMFS_NAME%.*}-\$kver\${KERNEL_LOCALVERSION}.img
}
EOFGRUB
}

install_grub_to_disk(){
  # Requires running in the target system (chroot) and GRUB_DISK exists.
  [ -n "\$GRUB_DISK" ] || die "GRUB_DISK not set"
  if [ ! -b "\$GRUB_DISK" ]; then
    die "GRUB_DISK is not a block device inside chroot: \$GRUB_DISK"
  fi
  # grub-install path may be /sbin or /usr/sbin
  if [ -x /sbin/grub-install ]; then
    run_logged "grub-install" sh -c "/sbin/grub-install '\$GRUB_DISK'"
  else
    run_logged "grub-install" sh -c "/usr/sbin/grub-install '\$GRUB_DISK'"
  fi
}

final_sanity(){
  kver="\$(cat "\${WORKDIR}/kernel-version")"
  test -f "\$BOOTDIR/vmlinuz-\$kver\${KERNEL_LOCALVERSION}"
  test -f "\$BOOTDIR/\${INITRAMFS_NAME%.*}-\$kver\${KERNEL_LOCALVERSION}.img"
  test -f "\$BOOTDIR/grub/grub.cfg"
  say "==> Stage6 done. Kernel: \$kver\${KERNEL_LOCALVERSION}"
}

say "==> Stage6 starting (kernel+initramfs+grub)"

ensure_bc_bison_flex
build_kernel
build_initramfs
build_grub
write_grub_cfg
install_grub_to_disk
final_sanity
EOF
  chmod 0755 "${ROOT}/.stage6-build/stage6-chroot.sh"
}

run_stage6() {
  write_chroot_script
  chroot "$ROOT" /usr/bin/env -i \
    HOME=/root TERM="${TERM:-xterm}" PS1='(stage6) \u:\w\$ ' \
    PATH=/usr/bin:/usr/sbin:/bin:/sbin:/tools/bin \
    /bin/sh -c "/.stage6-build/stage6-chroot.sh"
}

###############################################################################
# Main
###############################################################################
need sh; need awk; need sed; need tar; need mount; need umount; need chroot

as_root

[ -n "$ROOT_UUID" ] || [ -n "$ROOT_DEVICE" ] || die "set ROOT_UUID or ROOT_DEVICE for initramfs/grub"

mkdirp "$WORKDIR" "$SRCDIR" "$LOGDIR"

# Ensure /tools visibility inside ROOT, and /bin/sh exists for chroot
[ -e "$ROOT/tools" ] || ln -sfn "$TOOLS" "$ROOT/tools" 2>/dev/null || true
if [ ! -x "$ROOT/bin/sh" ]; then
  mkdirp "$ROOT/bin"
  ln -sf /tools/bin/bash "$ROOT/bin/sh"
fi

# Download required tarballs before entering chroot.
for p in linux- grub- bc- bison- flex-; do
  tb="$(resolve_tarball "$p")"
  download_pkg "$tb"
done

trap umount_vfs EXIT INT TERM HUP
mount_vfs
run_stage6

say "==> SUCCESS: Stage6 finished."
say "Chroot logs: ${ROOT}/.stage6-build/logs-chroot"
