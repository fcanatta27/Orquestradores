#!/bin/sh
# orchestrate-build.sh
#
# Single-command orchestrator for the complete automated build:
#   toolchain -> stage1 -> stage2 -> stage3 -> stage4 -> stage5 -> stage6 -> stage7 -> stage8 -> stage9
#
# Features:
#   - Resume/checkpointing (per-stage .done markers)
#   - Structured logs (per-stage stdout/stderr, timings)
#   - Parallelism for builds via MAKEFLAGS (-jN) and reasonable defaults
#   - Safety rails: root checks, path sanity, disk space checks, traps
#
# POSIX sh only. License: MIT.

###############################################################################
# User-configurable variables (all knobs are here)
###############################################################################
# Root of target filesystem
ROOT="/mnt/rootfs"

# Directory where all stage scripts live (default: current directory)
SCRIPT_DIR="."

# Logging and state
STATE_DIR="${ROOT}/.orchestrator"
LOG_DIR="${ROOT}/.orchestrator/logs"

# Build parallelism
JOBS=""              # empty => auto-detect
LOAD_AVG_MULT="2"    # used only when auto-detecting; small systems may set "1"

# Performance-safe build env (do not override package-specific flags inside stages)
DEFAULT_CFLAGS="-O2 -pipe"
DEFAULT_CXXFLAGS="-O2 -pipe"
DEFAULT_LDFLAGS=""

# Behavior
FORCE_REBUILD="0"    # 1 => run stages even if marked done
STOP_ON_WARN="0"     # 1 => treat warnings as fatal (wrapper-level only)
RUN_STAGE8="1"       # run healthcheck at end
RUN_STAGE9_PLAN="1"  # generate remediation plan at end
RUN_STAGE9_APPLY="0" # 1 => apply remediation automatically (recommended: keep 0)

# Stages (filenames expected under SCRIPT_DIR)
TOOLCHAIN="toolchain-temp-x86_64-glibc-v2.sh"
STAGE1="stage1-temp-tools-v2.sh"
STAGE2="stage2-base-system-v3.sh"
STAGE3="stage3-complete-base.sh"
STAGE4="stage4-config-sysv.sh"
STAGE5="stage5-extras.sh"
STAGE6="stage6-kernel-initramfs-grub.sh"
STAGE7="stage7-postboot-cli.sh"
STAGE8="stage8-qa-healthcheck.sh"
STAGE9="stage9-auto-remediation.sh"

# Minimal free space checks (GiB)
MIN_GIB_ROOT="12"
MIN_GIB_SOURCES="8"

# Source tree (optional). If your stage scripts download sources themselves, you can ignore.
SOURCES_DIR="${ROOT}/sources"

###############################################################################
set -eu
umask 022
IFS="$(printf ' \t\n')"
export LC_ALL=C

say(){ printf '%s\n' "$*"; }
die(){ printf 'ERROR: %s\n' "$*" >&2; exit 1; }
have(){ command -v "$1" >/dev/null 2>&1; }

need_root() {
  [ "$(id -u)" -eq 0 ] || die "must run as root (mount/chroot/build install phases require root)"
}

mkdirp(){ [ -d "$1" ] || mkdir -p "$1"; }

abs_path() {
  # best-effort absolute path resolution
  p="$1"
  case "$p" in
    /*) printf '%s\n' "$p" ;;
    *) printf '%s\n' "$(pwd)/$p" ;;
  esac
}

detect_jobs() {
  if [ -n "$JOBS" ]; then
    printf '%s\n' "$JOBS"
    return 0
  fi
  if have nproc; then
    n="$(nproc 2>/dev/null || echo 1)"
  else
    n="1"
  fi
  # conservative: 2x cores by default but cap at 32 to avoid runaway on large servers
  m="$LOAD_AVG_MULT"
  case "$m" in ""|*[!0-9]*) m="2";; esac
  j=$((n*m))
  [ "$j" -lt 1 ] && j=1
  [ "$j" -gt 32 ] && j=32
  printf '%s\n' "$j"
}

df_gib_free() {
  # prints free GiB (integer) for a path; best-effort
  p="$1"
  if have df; then
    df -Pk "$p" 2>/dev/null | awk 'NR==2{printf "%d\n", int($4/1024/1024)}'
  else
    printf '0\n'
  fi
}

check_space() {
  [ -d "$ROOT" ] || die "ROOT not found: $ROOT"
  fr="$(df_gib_free "$ROOT")"
  if [ "$fr" -lt "$MIN_GIB_ROOT" ]; then
    die "insufficient free space at ROOT ($fr GiB < $MIN_GIB_ROOT GiB)"
  fi
  mkdirp "$SOURCES_DIR"
  fs="$(df_gib_free "$SOURCES_DIR")"
  if [ "$fs" -lt "$MIN_GIB_SOURCES" ]; then
    die "insufficient free space at SOURCES_DIR ($fs GiB < $MIN_GIB_SOURCES GiB)"
  fi
}

export_build_env() {
  j="$(detect_jobs)"
  export MAKEFLAGS="-j$j"
  export CFLAGS="${CFLAGS:-$DEFAULT_CFLAGS}"
  export CXXFLAGS="${CXXFLAGS:-$DEFAULT_CXXFLAGS}"
  export LDFLAGS="${LDFLAGS:-$DEFAULT_LDFLAGS}"
  export TZ=UTC
  say "MAKEFLAGS=$MAKEFLAGS"
  say "CFLAGS=$CFLAGS"
}

stage_done_marker() {
  printf '%s\n' "$STATE_DIR/$1.done"
}

is_done() {
  [ -f "$(stage_done_marker "$1")" ]
}

mark_done() {
  t="$(date +%Y-%m-%dT%H:%M:%SZ 2>/dev/null || echo done)"
  printf '%s\n' "$t" >"$(stage_done_marker "$1")"
}

run_stage() {
  name="$1"
  script="$2"
  shift 2 || true

  mkdirp "$STATE_DIR" "$LOG_DIR"
  s="$SCRIPT_DIR/$script"
  [ -f "$s" ] || die "missing stage script: $s"
  chmod +x "$s" 2>/dev/null || true

  if [ "$FORCE_REBUILD" != "1" ] && is_done "$name"; then
    say "==> SKIP $name (already done)"
    return 0
  fi

  start="$(date +%s 2>/dev/null || echo 0)"
  out="$LOG_DIR/$name.out"
  err="$LOG_DIR/$name.err"
  meta="$LOG_DIR/$name.meta"

  say "==> RUN  $name : $s"
  {
    echo "stage=$name"
    echo "script=$s"
    echo "start_utc=$(date -u 2>/dev/null || date)"
    echo "makeflags=${MAKEFLAGS:-}"
    echo "cflags=${CFLAGS:-}"
  } >"$meta"

  # Execute with a clean-ish environment but preserve PATH and essentials.
  # Stages already manage chroot/mounting internally.
  (
    export LC_ALL=C
    "$s" "$@"
  ) 1>"$out" 2>"$err" || {
    code="$?"
    echo "exit_code=$code" >>"$meta"
    echo "end_utc=$(date -u 2>/dev/null || date)" >>"$meta"
    die "$name failed (exit $code). See logs: $out $err"
  }

  end="$(date +%s 2>/dev/null || echo 0)"
  dur=$((end-start))
  echo "exit_code=0" >>"$meta"
  echo "end_utc=$(date -u 2>/dev/null || date)" >>"$meta"
  echo "duration_sec=$dur" >>"$meta"

  mark_done "$name"
  say "==> DONE $name (duration ${dur}s)"
}

usage() {
  cat <<EOF
Usage:
  $0 all
  $0 from <stage>
  $0 stage <stage>
  $0 status

Stages:
  toolchain stage1 stage2 stage3 stage4 stage5 stage6 stage7 stage8 stage9

Notes:
  - Logs and state live under: $STATE_DIR and $LOG_DIR (inside ROOT)
  - Use FORCE_REBUILD=1 to rerun completed stages.
  - Parallelism controlled by JOBS or auto-detect.
EOF
}

status() {
  say "ROOT=$ROOT"
  say "STATE_DIR=$STATE_DIR"
  say "LOG_DIR=$LOG_DIR"
  for st in toolchain stage1 stage2 stage3 stage4 stage5 stage6 stage7 stage8 stage9; do
    if is_done "$st"; then
      say "DONE  $st  ($(cat "$(stage_done_marker "$st")" 2>/dev/null || true))"
    else
      say "PEND  $st"
    fi
  done
}

run_all() {
  run_stage toolchain "$TOOLCHAIN"
  run_stage stage1    "$STAGE1"
  run_stage stage2    "$STAGE2"
  run_stage stage3    "$STAGE3"
  run_stage stage4    "$STAGE4"
  run_stage stage5    "$STAGE5"
  run_stage stage6    "$STAGE6"
  run_stage stage7    "$STAGE7"

  if [ "$RUN_STAGE8" = "1" ]; then
    run_stage stage8 "$STAGE8"
  fi

  if [ "$RUN_STAGE9_PLAN" = "1" ]; then
    # Stage9 in plan mode always safe; stage9 picks latest report.
    run_stage stage9 "$STAGE9" $( [ "$RUN_STAGE9_APPLY" = "1" ] && printf '%s' "--apply" )
  fi
}

run_from() {
  st="$1"
  case "$st" in
    toolchain) run_all ;;
    stage1) run_stage stage1 "$STAGE1"; run_stage stage2 "$STAGE2"; run_stage stage3 "$STAGE3"; run_stage stage4 "$STAGE4"; run_stage stage5 "$STAGE5"; run_stage stage6 "$STAGE6"; run_stage stage7 "$STAGE7"; [ "$RUN_STAGE8" = "1" ] && run_stage stage8 "$STAGE8"; [ "$RUN_STAGE9_PLAN" = "1" ] && run_stage stage9 "$STAGE9" $( [ "$RUN_STAGE9_APPLY" = "1" ] && printf '%s' "--apply" ) ;;
    stage2) run_stage stage2 "$STAGE2"; run_stage stage3 "$STAGE3"; run_stage stage4 "$STAGE4"; run_stage stage5 "$STAGE5"; run_stage stage6 "$STAGE6"; run_stage stage7 "$STAGE7"; [ "$RUN_STAGE8" = "1" ] && run_stage stage8 "$STAGE8"; [ "$RUN_STAGE9_PLAN" = "1" ] && run_stage stage9 "$STAGE9" $( [ "$RUN_STAGE9_APPLY" = "1" ] && printf '%s' "--apply" ) ;;
    stage3) run_stage stage3 "$STAGE3"; run_stage stage4 "$STAGE4"; run_stage stage5 "$STAGE5"; run_stage stage6 "$STAGE6"; run_stage stage7 "$STAGE7"; [ "$RUN_STAGE8" = "1" ] && run_stage stage8 "$STAGE8"; [ "$RUN_STAGE9_PLAN" = "1" ] && run_stage stage9 "$STAGE9" $( [ "$RUN_STAGE9_APPLY" = "1" ] && printf '%s' "--apply" ) ;;
    stage4) run_stage stage4 "$STAGE4"; run_stage stage5 "$STAGE5"; run_stage stage6 "$STAGE6"; run_stage stage7 "$STAGE7"; [ "$RUN_STAGE8" = "1" ] && run_stage stage8 "$STAGE8"; [ "$RUN_STAGE9_PLAN" = "1" ] && run_stage stage9 "$STAGE9" $( [ "$RUN_STAGE9_APPLY" = "1" ] && printf '%s' "--apply" ) ;;
    stage5) run_stage stage5 "$STAGE5"; run_stage stage6 "$STAGE6"; run_stage stage7 "$STAGE7"; [ "$RUN_STAGE8" = "1" ] && run_stage stage8 "$STAGE8"; [ "$RUN_STAGE9_PLAN" = "1" ] && run_stage stage9 "$STAGE9" $( [ "$RUN_STAGE9_APPLY" = "1" ] && printf '%s' "--apply" ) ;;
    stage6) run_stage stage6 "$STAGE6"; run_stage stage7 "$STAGE7"; [ "$RUN_STAGE8" = "1" ] && run_stage stage8 "$STAGE8"; [ "$RUN_STAGE9_PLAN" = "1" ] && run_stage stage9 "$STAGE9" $( [ "$RUN_STAGE9_APPLY" = "1" ] && printf '%s' "--apply" ) ;;
    stage7) run_stage stage7 "$STAGE7"; [ "$RUN_STAGE8" = "1" ] && run_stage stage8 "$STAGE8"; [ "$RUN_STAGE9_PLAN" = "1" ] && run_stage stage9 "$STAGE9" $( [ "$RUN_STAGE9_APPLY" = "1" ] && printf '%s' "--apply" ) ;;
    stage8) run_stage stage8 "$STAGE8"; [ "$RUN_STAGE9_PLAN" = "1" ] && run_stage stage9 "$STAGE9" $( [ "$RUN_STAGE9_APPLY" = "1" ] && printf '%s' "--apply" ) ;;
    stage9) run_stage stage9 "$STAGE9" $( [ "$RUN_STAGE9_APPLY" = "1" ] && printf '%s' "--apply" ) ;;
    *) die "unknown stage: $st" ;;
  esac
}

main() {
  need_root
  check_space
  export_build_env

  cmd="${1:-}"
  case "$cmd" in
    all) run_all ;;
    from) run_from "${2:-}" ;;
    stage) run_from "${2:-}" ;; # alias
    status) status ;;
    ""|-h|--help) usage ;;
    *) die "unknown command: $cmd" ;;
  esac

  say "==> Orchestration complete."
  say "Logs:  $LOG_DIR"
  say "State: $STATE_DIR"
}

main "$@"
