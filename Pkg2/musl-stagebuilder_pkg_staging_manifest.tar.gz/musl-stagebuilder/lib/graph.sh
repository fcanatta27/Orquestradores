#!/usr/bin/env bash
set -euo pipefail
# shellcheck source=lib/common.sh
source "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/lib/common.sh"

# Topological sort simples a partir de deps declaradas em receitas.
# Cada receita deve definir: pkg_deps="<space separated>"
toposort() {
  local stage="$1"; shift
  local pkgs=("$@")
  local sorted=()
  local temp=() perm=()

  _in_list() { local x="$1"; shift; for i in "$@"; do [[ "$i" == "$x" ]] && return 0; done; return 1; }

  _visit() {
    local n="$1"
    _in_list "$n" "${perm[@]}" && return 0
    _in_list "$n" "${temp[@]}" && die "Ciclo de dependência detectado em $n"
    temp+=("$n")

    # carregar deps da receita
    local recipe="${TOPDIR}/recipes/${stage}/${n}.recipe"
    [[ -f "$recipe" ]] || die "Receita não encontrada: $recipe"
    # shellcheck disable=SC1090
    source "$recipe"
    local deps=(${pkg_deps:-})
    for d in "${deps[@]}"; do
      _visit "$d"
    done

    # remove de temp
    local newtemp=()
    for i in "${temp[@]}"; do [[ "$i" != "$n" ]] && newtemp+=("$i"); done
    temp=("${newtemp[@]}")
    perm+=("$n")
    sorted+=("$n")
  }

  for p in "${pkgs[@]}"; do
    _visit "$p"
  done

  printf '%s
' "${sorted[@]}"
}
