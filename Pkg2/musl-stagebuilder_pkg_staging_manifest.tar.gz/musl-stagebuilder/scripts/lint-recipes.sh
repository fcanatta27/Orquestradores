#!/usr/bin/env bash
set -euo pipefail

TOPDIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
# shellcheck source=lib/common.sh
source "${TOPDIR}/lib/common.sh"
# shellcheck source=lib/build.sh
source "${TOPDIR}/lib/build.sh"
load_config "${TOPDIR}/config/config.env"

usage() {
  cat <<'USAGE'
Uso: ./scripts/lint-recipes.sh [stage]

Valida recipes sem compilar nada, para detectar regressões antes de builds longos.

Stages válidos:
  cross | stage1 | stage2 | stage3
(se omitido: valida todos os stages existentes em recipes/)

Falhas:
  - campos obrigatórios: pkg_name, pkg_version, pkg_url, pkg_sha256
  - build_pkg() e install_pkg() presentes
  - pkg_name coincide com o nome do arquivo .recipe
  - deps pkg_deps referenciam recipes existentes no mesmo stage
  - DESTDIR guard (estático): install_pkg() não pode instalar fora de ${DESTDIR}/${DESTROOT} quando DESTDIR estiver setado
    e, para receitas rootfs-style, não pode ter "make install" sem DESTDIR/root

Avisos:
  - uso de variáveis legadas/prováveis typos: TARGET, SYSROOT
  - uso de DESTROOT dentro da recipe (preferir DESTDIR)

Ambiente:
  ENFORCE_DESTDIR_GUARD=1  (default)
  NO_COLOR=1 / UI_COLOR=0  (desabilita cores)
USAGE
}

have_recipe() {
  local stage="$1" pkg="$2"
  [[ -f "${TOPDIR}/recipes/${stage}/${pkg}.recipe" ]]
}

stage_filter="${1:-}"
case "${stage_filter}" in
  "" ) : ;;
  -h|--help) usage; exit 0 ;;
esac

mapfile -t stages < <(cd "${TOPDIR}/recipes" && ls -1d */ 2>/dev/null | sed 's#/$##' | sort)
if [[ -n "${stage_filter}" ]]; then
  stages=("${stage_filter}")
fi

fail=0
warn=0
total=0

DESTDIR_LINT="${TOPDIR}/.lint-destdir"
ensure_dir "${DESTDIR_LINT}"

ui_hr
ui_title "Lint de recipes"
ui_note "Stages: ${stages[*]}"
ui_note "DESTDIR (lint): ${DESTDIR_LINT}"
ui_hr

for st in "${stages[@]}"; do
  [[ -d "${TOPDIR}/recipes/${st}" ]] || { ui_warn "Stage inexistente: ${st}"; warn=$((warn+1)); continue; }

  mapfile -t recipes < <(find "${TOPDIR}/recipes/${st}" -maxdepth 1 -type f -name '*.recipe' | sort)
  ui_title "Stage: ${st} (${#recipes[@]} recipes)"

  for recipe in "${recipes[@]}"; do
    total=$((total+1))
    pkg="$(basename "$recipe" .recipe)"

    # 0) Extrai campos principais em UMA única carga da recipe
    IFS=$'\n' read -r declared_name declared_ver declared_url declared_sha declared_deps < <(
      (
        set -euo pipefail
        pkg_name=""; pkg_version=""; pkg_url=""; pkg_sha256=""; pkg_deps=""
        # shellcheck disable=SC1090
        source "$recipe"
        echo "${pkg_name:-}"
        echo "${pkg_version:-}"
        echo "${pkg_url:-}"
        echo "${pkg_sha256:-}"
        echo "${pkg_deps:-}"
      )
    )

    if [[ -z "${declared_name}" ]]; then ui_err "${st}/${pkg}: pkg_name vazio"; fail=1; fi
    if [[ -z "${declared_ver}" ]]; then ui_err "${st}/${pkg}: pkg_version vazio"; fail=1; fi
    if [[ -z "${declared_url}" ]]; then ui_err "${st}/${pkg}: pkg_url vazio"; fail=1; fi
    if [[ -z "${declared_sha}" ]]; then ui_err "${st}/${pkg}: pkg_sha256 vazio"; fail=1; fi

    if [[ -n "${declared_name}" && "${declared_name}" != "${pkg}" ]]; then
      ui_err "${st}/${pkg}: pkg_name='${declared_name}' não coincide com arquivo"
      fail=1
    fi

    # 1) Funções presentes
    grep -qE '^[[:space:]]*build_pkg\(\)' "$recipe" || { ui_err "${st}/${pkg}: build_pkg() ausente"; fail=1; }
    grep -qE '^[[:space:]]*install_pkg\(\)' "$recipe" || { ui_err "${st}/${pkg}: install_pkg() ausente"; fail=1; }

    # 2) Deps: devem existir no mesmo stage
    if [[ -n "${declared_deps}" ]]; then
      for d in ${declared_deps}; do
        if ! have_recipe "$st" "$d"; then
          ui_err "${st}/${pkg}: dep inexistente no mesmo stage: ${d}"
          fail=1
        fi
      done
    fi

    # 3) Heurísticas de typos / variáveis legadas
    if grep -qE '\$\{?(TARGET|SYSROOT)\}?\b' "$recipe"; then
      ui_warn "${st}/${pkg}: possível variável legada/typo (TARGET/SYSROOT). Use TARGET_TRIPLE/COMPILE_SYSROOT."
      warn=$((warn+1))
    fi
    if grep -qE '\bDESTROOT\b' "$recipe"; then
      ui_warn "${st}/${pkg}: usa DESTROOT (preferir DESTDIR nas recipes)"
      warn=$((warn+1))
    fi
    if grep -qE 'DESTDIR=.*DESTDIR=' "$recipe"; then
      ui_err "${st}/${pkg}: provável duplicação de DESTDIR= no install_pkg()"
      fail=1
    fi

    # 4) Checagem DESTDIR (estática) - força DESTDIR != '/'
    (
      set -euo pipefail
      export DESTDIR="$DESTDIR_LINT"
      export DESTROOT="$DESTDIR_LINT"
      check_recipe_destdir_guard "$recipe"
    ) || { ui_err "${st}/${pkg}: violação de DESTDIR/DESTROOT"; fail=1; }

  done
done

ui_hr
if [[ "$fail" = "0" ]]; then
  ui_ok "LINT OK: ${total} recipes validadas (warn=${warn})"
else
  die "LINT FALHOU: ${total} recipes validadas (warn=${warn})"
fi
