#!/usr/bin/env bash
set -euo pipefail

# Atualiza receitas consultando fontes oficiais e preenche SHA256 automaticamente.
#
# Modos (pensados para não quebrar reprodutibilidade por padrão):
#   - padrão / --core-only : atualiza apenas o "core" (linux-headers, musl, binutils, gcc) e recalcula sha256.
#   - --extras            : atualiza apenas extras (python/openssl/cmake/meson/ninja/zlib) e recalcula sha256.
#   - --all               : atualiza core + extras + preenche sha256 (sem mudar versão/URL) para qualquer receita com pkg_sha256="SKIP".
#
# Observações:
#   - Parsing de listagens HTTP/HTML é inerentemente frágil; este script é best-effort.
#   - Para builds reprodutíveis, faça pin de versões e valide os hashes.
#
# Requisitos:
#   - curl (recomendado) ou wget
#   - sha256sum ou shasum -a 256
#   - awk/grep/sed/sort

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
TOPDIR="$(cd -- "${SCRIPT_DIR}/.." && pwd)"
CACHE_DIR="${TOPDIR}/.cache/update-recipes"
TMP_DIR="${CACHE_DIR}/tmp"

MODE="core"  # core | extras | all
RESPECT_PINS=1
PIN_CURRENT=0

PINS_FILE="${TOPDIR}/config/pins.env"
declare -A PINS

usage() {
  cat <<EOF
Uso: $(basename "$0") [--core-only|--extras|--all]

  --core-only  Atualiza apenas core (linux/musl/binutils/gcc). (padrão)
  --extras     Atualiza apenas extras (python/openssl/cmake/meson/ninja/zlib).
  --all        Atualiza core + extras e preenche qualquer sha256 "SKIP" sem mudar versões/URLs.
  --extras        Atualiza extras estendidos (python/openssl/cmake/meson/ninja/zlib + pkgconf/xz/bzip2/gzip/perl/git/expat, etc.).
  --pin-current    Gera/atualiza config/pins.env com as versões atuais (freeze).
  --ignore-pins    Ignora pins mesmo que config/pins.env exista.

EOF
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --core-only)   MODE="core"; shift ;;
    --extras)      MODE="extras"; shift ;;
    --all)         MODE="all"; shift ;;
    --pin-current) PIN_CURRENT=1; shift ;;
    --ignore-pins) RESPECT_PINS=0; shift ;;
    -h|--help)     usage; exit 0 ;;
    *) echo "Argumento desconhecido: $1" >&2; usage; exit 2 ;;
  esac
done

need_cmd() {
  command -v "$1" >/dev/null 2>&1 || { echo "Erro: comando necessário não encontrado: $1" >&2; exit 1; }
}
ensure_dir() { mkdir -p "$1"; }
load_pins() {
  [[ "$RESPECT_PINS" -eq 1 ]] || return 0
  [[ -f "$PINS_FILE" ]] || return 0
  while IFS= read -r line; do
    # aceita: PIN_<name>=<version>
    [[ "$line" =~ ^[[:space:]]*PIN_([A-Za-z0-9_]+)=\"?([^\"]+)\"?[[:space:]]*$ ]] || continue
    local k="${BASH_REMATCH[1]}"
    local v="${BASH_REMATCH[2]}"
    PINS["$k"]="$v"
  done <"$PINS_FILE"
}

pin_for() {
  local key="$1"
  echo "${PINS[$key]:-}"
}

write_pins_current() {
  ensure_dir "$(dirname "$PINS_FILE")"
  local out="${PINS_FILE}.tmp"
  : >"$out"
  {
    echo '# Pins de versões para builds reprodutíveis'
    echo '# Formato: PIN_<pkg_name>="X.Y.Z"'
    echo '# Gere com: ./scripts/update-recipes.sh --pin-current'
    echo
  } >>"$out"

  local r v
  for r in "${TOPDIR}/recipes/cross/"*.recipe "${TOPDIR}/recipes/stage2/"*.recipe; do
    [[ -f "$r" ]] || continue
    local name
    name="$(grep -E '^[[:space:]]*pkg_name="' "$r" | head -n1 | sed -E 's/^[[:space:]]*pkg_name="([^"]+)".*$/\1/')"
    [[ -n "$name" ]] || continue
    v="$(grep -E '^[[:space:]]*pkg_version="' "$r" | head -n1 | sed -E 's/^[[:space:]]*pkg_version="([^"]+)".*$/\1/')"
    [[ -n "$v" ]] || continue
    printf 'PIN_%s="%s"\n' "$name" "$v"
  done | sort -u >>"$out"

  mv -f "$out" "$PINS_FILE"
  echo "Pins gerados em: $PINS_FILE"
}


need_cmd awk
need_cmd grep
need_cmd sed
need_cmd sort
need_cmd tail
need_cmd python3

fetch_text() {
  local url="$1" out="$2"
  ensure_dir "$(dirname "$out")"
  if command -v curl >/dev/null 2>&1; then
    curl -L --fail --retry 3 --retry-delay 1 -o "$out" "$url"
  else
    need_cmd wget
    wget -O "$out" "$url"
  fi
}

download() {
  local url="$1" out="$2"
  ensure_dir "$(dirname "$out")"
  if command -v curl >/dev/null 2>&1; then
    curl -L --fail --retry 3 --retry-delay 1 -o "$out" "$url"
  else
    need_cmd wget
    wget -O "$out" "$url"
  fi
}

sha256_file() {
  local f="$1"
  if command -v sha256sum >/dev/null 2>&1; then
    sha256sum "$f" | awk '{print $1}'
  else
    need_cmd shasum
    shasum -a 256 "$f" | awk '{print $1}'
  fi
}

sha256_of_url() {
  local url="$1"
  ensure_dir "$TMP_DIR"
  local base
  base="$(basename "$url")"
  local f="${TMP_DIR}/${base}"
  download "$url" "$f"
  sha256_file "$f"
}

# Atualiza campo em receita com tolerância a indentação.
update_recipe_field() {
  local recipe="$1" field="$2" value="$3"
  # substitui a primeira ocorrência de: <spaces>field="..."
  # escape para sed (/, \, &)
  local esc="$value"
  esc="${esc//\\/\\\\}"
  esc="${esc//&/\\&}"
  esc="${esc//\//\\/}"
  sed -i -E "0,/^[[:space:]]*${field}=\"[^\"]*\"/s//${field}=\"${esc}\"/" "$recipe"
}

# Obtém valor do campo em receita (primeira ocorrência).
get_recipe_field() {
  local recipe="$1" field="$2"
  awk -F\" -v f="$field" '
    $0 ~ "^[[:space:]]*"f"=\"" {print $2; exit}
  ' "$recipe"
}

# --- Heurísticas por upstream ---

latest_python() {
  # Fonte: https://www.python.org/ftp/python/
  local idx="${TMP_DIR}/python-index.html"
  fetch_text "https://www.python.org/ftp/python/" "$idx"

  # Diretórios do tipo 3.13.1/
  local v
  v="$(grep -Eo 'href="[0-9]+\.[0-9]+\.[0-9]+/' "$idx" \
      | sed -E 's/^href="([^/]+)\/$/\1/' \
      | sort -V | tail -n1)"
  [[ -n "$v" ]] || { echo "Falha ao detectar versão do Python" >&2; return 1; }

  local url="https://www.python.org/ftp/python/${v}/Python-${v}.tar.xz"
  echo "${v}|${url}"
}

latest_openssl() {
  # Fonte: https://www.openssl.org/source/
  local idx="${TMP_DIR}/openssl-index.html"
  fetch_text "https://www.openssl.org/source/" "$idx"

  # openssl-3.2.1.tar.gz etc. Exclui alpha/beta/rc e fips.
  local t
  t="$(grep -Eo 'openssl-[0-9]+\.[0-9]+\.[0-9]+[a-z]?\.(tar\.gz|tar\.xz)' "$idx" \
      | grep -Ev '(alpha|beta|rc)' \
      | grep -Ev 'fips' \
      | sort -V | tail -n1)"
  [[ -n "$t" ]] || { echo "Falha ao detectar tarball do OpenSSL" >&2; return 1; }

  local v
  v="$(echo "$t" | sed -E 's/^openssl-//; s/\.(tar\.gz|tar\.xz)$//')"
  local url="https://www.openssl.org/source/${t}"
  echo "${v}|${url}"
}

latest_zlib() {
  # Fonte: https://zlib.net/
  local idx="${TMP_DIR}/zlib-index.html"
  fetch_text "https://zlib.net/" "$idx"

  local t
  t="$(grep -Eo 'zlib-[0-9]+\.[0-9]+\.[0-9]+\.tar\.gz' "$idx" \
      | sort -V | tail -n1)"
  [[ -n "$t" ]] || { echo "Falha ao detectar tarball do zlib" >&2; return 1; }

  local v
  v="$(echo "$t" | sed -E 's/^zlib-//; s/\.tar\.gz$//')"
  local url="https://zlib.net/${t}"
  echo "${v}|${url}"
}


url_python()   { local v="$1"; echo "https://www.python.org/ftp/python/${v}/Python-${v}.tar.xz"; }
url_openssl()  { local v="$1"; echo "https://www.openssl.org/source/openssl-${v}.tar.gz"; }
url_cmake()    { local v="$1"; local mm; mm="$(echo "$v" | awk -F. '{print $1 "." $2}')" ; echo "https://cmake.org/files/v${mm}/cmake-${v}.tar.gz"; }
url_ninja()    { local v="$1"; echo "https://github.com/ninja-build/ninja/archive/refs/tags/v${v}.tar.gz"; }
url_zlib()     { local v="$1"; echo "https://zlib.net/zlib-${v}.tar.xz"; }
url_gzip()     { local v="$1"; echo "https://ftp.gnu.org/gnu/gzip/gzip-${v}.tar.xz"; }
url_bzip2()    { local v="$1"; echo "https://sourceware.org/pub/bzip2/bzip2-${v}.tar.gz"; }
url_xz()       { local v="$1"; echo "https://tukaani.org/xz/xz-${v}.tar.xz"; }
url_pkgconf()  { local v="$1"; echo "https://github.com/pkgconf/pkgconf/archive/refs/tags/pkgconf-${v}.tar.gz"; }
url_perl()     { local v="$1"; echo "https://www.cpan.org/src/5.0/perl-${v}.tar.xz"; }
url_git()      { local v="$1"; echo "https://mirrors.edge.kernel.org/pub/software/scm/git/git-${v}.tar.xz"; }
url_expat()    { local v="$1"; local tag="R_$(echo "$v" | tr . _)"; echo "https://github.com/libexpat/libexpat/releases/download/${tag}/expat-${v}.tar.xz"; }

pypi_latest() {
  local name="$1"
  local j="${TMP_DIR}/pypi-${name}.json"
  fetch_text "https://pypi.org/pypi/${name}/json" "$j"
  python3 - <<'PY' "$j"
import json,sys
j=json.load(open(sys.argv[1],'r',encoding='utf-8'))
print(j["info"]["version"])
PY
}

pypi_sdist_url() {
  local name="$1" v="$2"
  local j="${TMP_DIR}/pypi-${name}.json"
  [[ -f "$j" ]] || fetch_text "https://pypi.org/pypi/${name}/json" "$j"
  python3 - <<'PY' "$j" "$v"
import json,sys
j=json.load(open(sys.argv[1],'r',encoding='utf-8'))
v=sys.argv[2]
for f in j["releases"].get(v,[]):
    if f.get("packagetype")=="sdist" and f.get("url"):
        print(f["url"]); sys.exit(0)
sys.exit(1)
PY
}

latest_pkgconf() {
  # GitHub releases
  local idx="${TMP_DIR}/pkgconf-releases.html"
  fetch_text "https://github.com/pkgconf/pkgconf/releases" "$idx"
  local tag
  tag="$(grep -Eo 'pkgconf-[0-9]+\.[0-9]+\.[0-9]+' "$idx" | head -n1)"
  [[ -n "$tag" ]] || { echo "Falha ao detectar versão do pkgconf" >&2; return 1; }
  local v="${tag#pkgconf-}"
  echo "${v}|$(url_pkgconf "$v")"
}

latest_xz() {
  local idx="${TMP_DIR}/xz-index.html"
  fetch_text "https://tukaani.org/xz/" "$idx"
  local t
  t="$(grep -Eo 'xz-[0-9]+\.[0-9]+\.[0-9]+\.tar\.xz' "$idx" | sort -Vu | tail -n1)"
  [[ -n "$t" ]] || { echo "Falha ao detectar versão do xz" >&2; return 1; }
  local v
  v="$(echo "$t" | sed -E 's/^xz-//; s/\.tar\.xz$//')"
  echo "${v}|$(url_xz "$v")"
}

latest_bzip2() {
  local idx="${TMP_DIR}/bzip2-index.html"
  fetch_text "https://sourceware.org/pub/bzip2/" "$idx"
  local t
  t="$(grep -Eo 'bzip2-[0-9]+\.[0-9]+\.[0-9]+\.tar\.gz' "$idx" | sort -Vu | tail -n1)"
  [[ -n "$t" ]] || { echo "Falha ao detectar versão do bzip2" >&2; return 1; }
  local v
  v="$(echo "$t" | sed -E 's/^bzip2-//; s/\.tar\.gz$//')"
  echo "${v}|$(url_bzip2 "$v")"
}

latest_gzip() {
  local idx="${TMP_DIR}/gzip-index.html"
  fetch_text "https://ftp.gnu.org/gnu/gzip/" "$idx"
  local t
  t="$(grep -Eo 'gzip-[0-9]+\.[0-9]+(\.[0-9]+)?\.tar\.(xz|gz)' "$idx" | sort -Vu | tail -n1)"
  [[ -n "$t" ]] || { echo "Falha ao detectar versão do gzip" >&2; return 1; }
  local v
  v="$(echo "$t" | sed -E 's/^gzip-//; s/\.tar\.(xz|gz)$//')"
  echo "${v}|$(url_gzip "$v")"
}

latest_perl() {
  local idx="${TMP_DIR}/perl-index.html"
  fetch_text "https://www.cpan.org/src/5.0/" "$idx"
  local t
  t="$(grep -Eo 'perl-[0-9]+\.[0-9]+\.[0-9]+\.tar\.(xz|gz)' "$idx" | sort -Vu | tail -n1)"
  [[ -n "$t" ]] || { echo "Falha ao detectar versão do perl" >&2; return 1; }
  local v
  v="$(echo "$t" | sed -E 's/^perl-//; s/\.tar\.(xz|gz)$//')"
  echo "${v}|https://www.cpan.org/src/5.0/${t}"
}

latest_git() {
  local idx="${TMP_DIR}/git-index.html"
  fetch_text "https://mirrors.edge.kernel.org/pub/software/scm/git/" "$idx"
  local t
  t="$(grep -Eo 'git-[0-9]+\.[0-9]+\.[0-9]+\.tar\.xz' "$idx" | sort -Vu | tail -n1)"
  [[ -n "$t" ]] || { echo "Falha ao detectar versão do git" >&2; return 1; }
  local v
  v="$(echo "$t" | sed -E 's/^git-//; s/\.tar\.xz$//')"
  echo "${v}|$(url_git "$v")"
}

latest_expat() {
  local idx="${TMP_DIR}/expat-latest.html"
  fetch_text "https://github.com/libexpat/libexpat/releases/latest" "$idx"
  local t
  t="$(grep -Eo 'expat-[0-9]+\.[0-9]+\.[0-9]+\.tar\.(xz|gz)' "$idx" | head -n1)"
  [[ -n "$t" ]] || { echo "Falha ao detectar tarball do expat" >&2; return 1; }
  local v
  v="$(echo "$t" | sed -E 's/^expat-//; s/\.tar\.(xz|gz)$//')"
  local url="https://github.com/libexpat/libexpat/releases/download/R_$(echo "$v" | tr . _)/${t}"
  echo "${v}|${url}"
}

latest_pypi_pkg() {
  local name="$1"
  local v url
  v="$(pypi_latest "$name")"
  url="$(pypi_sdist_url "$name" "$v")"
  echo "${v}|${url}"
}

latest_cmake() {
  # Fonte: https://cmake.org/files/
  local idx="${TMP_DIR}/cmake-index.html"
  fetch_text "https://cmake.org/files/" "$idx"

  # Subdirs do tipo v3.30/
  local sub
  sub="$(grep -Eo 'href="v[0-9]+\.[0-9]+/' "$idx" \
      | sed -E 's/^href="(v[^/]+)\/$/\1/' \
      | sort -V | tail -n1)"
  [[ -n "$sub" ]] || { echo "Falha ao detectar diretório do CMake" >&2; return 1; }

  local idx2="${TMP_DIR}/cmake-${sub}.html"
  fetch_text "https://cmake.org/files/${sub}/" "$idx2"

  local t
  t="$(grep -Eo 'cmake-[0-9]+\.[0-9]+\.[0-9]+\.tar\.gz' "$idx2" \
      | sort -V | tail -n1)"
  [[ -n "$t" ]] || { echo "Falha ao detectar tarball do CMake em ${sub}" >&2; return 1; }

  local v
  v="$(echo "$t" | sed -E 's/^cmake-//; s/\.tar\.gz$//')"
  local url="https://cmake.org/files/${sub}/${t}"
  echo "${v}|${url}"
}

latest_pypi_json_version() {
  # Ex.: https://pypi.org/pypi/meson/json
  local name="$1"
  local out="${TMP_DIR}/pypi-${name}.json"
  fetch_text "https://pypi.org/pypi/${name}/json" "$out"
  awk -F\" '/"version":/ {print $4; exit}' "$out"
}

latest_meson() {
  local v
  v="$(latest_pypi_json_version meson)"
  [[ -n "$v" ]] || { echo "Falha ao detectar versão do Meson" >&2; return 1; }
  local url="https://github.com/mesonbuild/meson/archive/refs/tags/${v}.tar.gz"
  echo "${v}|${url}"
}

latest_ninja() {
  # Preferência: GitHub API (tag_name). Fallback: parse da página releases.
  local out="${TMP_DIR}/ninja-latest.json"
  if command -v curl >/dev/null 2>&1; then
    curl -L --fail --retry 3 --retry-delay 1 -H "Accept: application/vnd.github+json" \
      -o "$out" "https://api.github.com/repos/ninja-build/ninja/releases/latest" || true
  fi

  local tag=""
  if [[ -s "$out" ]]; then
    tag="$(awk -F\" '/"tag_name":/ {print $4; exit}' "$out")"
  fi

  if [[ -z "$tag" ]]; then
    local html="${TMP_DIR}/ninja-releases.html"
    fetch_text "https://github.com/ninja-build/ninja/releases" "$html"
    tag="$(grep -Eo 'href="/ninja-build/ninja/releases/tag/v[0-9]+\.[0-9]+\.[0-9]+"' "$html" \
      | head -n1 | sed -E 's/.*tag\/(v[0-9]+\.[0-9]+\.[0-9]+)".*/\1/')"
  fi

  [[ -n "$tag" ]] || { echo "Falha ao detectar versão do Ninja" >&2; return 1; }
  local v="${tag#v}"
  local url="https://github.com/ninja-build/ninja/archive/refs/tags/${tag}.tar.gz"
  echo "${v}|${url}"
}

# --- Atualizadores por receita ---

update_pkg() {
  local key="$1" recipe="$2" latest_fn="$3" url_fn="${4:-}"
  local pin v url
  pin="$(pin_for "$key")"
  if [[ -n "$pin" ]]; then
    v="$pin"
    if [[ -n "$url_fn" ]]; then
      url="$("$url_fn" "$v")"
    else
      IFS="|" read -r _ url < <("$latest_fn")
    fi
  else
    IFS="|" read -r v url < <("$latest_fn")
  fi
  update_one_recipe "$recipe" "$v" "$url"
}

update_one_recipe() {
  local recipe="$1" version="$2" url="$3"
  echo "Atualizando $(basename "$recipe") -> ${version}"
  update_recipe_field "$recipe" pkg_version "$version"
  update_recipe_field "$recipe" pkg_url "$url"
  local sha
  sha="$(sha256_of_url "$url")"
  update_recipe_field "$recipe" pkg_sha256 "$sha"
}

update_core() {
  # Reusa os detectores de versões core já existentes em receitas (mantém comportamento).
  # Implementação simples: atualiza a partir dos valores já definidos em do_core_updates (abaixo).
  do_core_updates
}


update_extras() {
  local r

  # python
  r="${TOPDIR}/recipes/stage2/python.recipe"
  [[ -f "$r" ]] && update_pkg python "$r" latest_python url_python

  # openssl
  r="${TOPDIR}/recipes/stage2/openssl.recipe"
  [[ -f "$r" ]] && update_pkg openssl "$r" latest_openssl url_openssl

  # cmake
  r="${TOPDIR}/recipes/stage2/cmake.recipe"
  [[ -f "$r" ]] && update_pkg cmake "$r" latest_cmake url_cmake

  # meson (PyPI JSON -> tarball)
  r="${TOPDIR}/recipes/stage2/meson.recipe"
  if [[ -f "$r" ]]; then
    local pin; pin="$(pin_for meson)"
    if [[ -n "$pin" ]]; then
      local url; url="$(pypi_sdist_url meson "$pin")"
      update_one_recipe "$r" "$pin" "$url"
    else
      IFS="|" read -r v url < <(latest_meson)
      update_one_recipe "$r" "$v" "$url"
    fi
  fi

  # ninja
  r="${TOPDIR}/recipes/stage2/ninja.recipe"
  [[ -f "$r" ]] && update_pkg ninja "$r" latest_ninja url_ninja

  # zlib
  r="${TOPDIR}/recipes/stage2/zlib.recipe"
  [[ -f "$r" ]] && update_pkg zlib "$r" latest_zlib url_zlib

  # extras estendidos (GNU/GitHub)
  r="${TOPDIR}/recipes/stage2/pkgconf.recipe"
  [[ -f "$r" ]] && update_pkg pkgconf "$r" latest_pkgconf url_pkgconf

  r="${TOPDIR}/recipes/stage2/xz.recipe"
  [[ -f "$r" ]] && update_pkg xz "$r" latest_xz url_xz

  r="${TOPDIR}/recipes/stage2/bzip2.recipe"
  [[ -f "$r" ]] && update_pkg bzip2 "$r" latest_bzip2 url_bzip2

  r="${TOPDIR}/recipes/stage2/gzip.recipe"
  [[ -f "$r" ]] && update_pkg gzip "$r" latest_gzip url_gzip

  r="${TOPDIR}/recipes/stage2/perl.recipe"
  if [[ -f "$r" ]]; then
    local pin; pin="$(pin_for perl)"
    if [[ -n "$pin" ]]; then
      local url="https://www.cpan.org/src/5.0/perl-${pin}.tar.xz"
      update_one_recipe "$r" "$pin" "$url"
    else
      IFS="|" read -r v url < <(latest_perl)
      update_one_recipe "$r" "$v" "$url"
    fi
  fi

  r="${TOPDIR}/recipes/stage2/expat.recipe"
  [[ -f "$r" ]] && update_pkg expat "$r" latest_expat url_expat

  r="${TOPDIR}/recipes/stage2/git.recipe"
  [[ -f "$r" ]] && update_pkg git "$r" latest_git url_git

  # Python extras via PyPI (sdist)
  r="${TOPDIR}/recipes/stage2/setuptools.recipe"
  if [[ -f "$r" ]]; then
    local pin; pin="$(pin_for setuptools)"
    local v url
    if [[ -n "$pin" ]]; then
      v="$pin"; url="$(pypi_sdist_url setuptools "$v")"
    else
      IFS="|" read -r v url < <(latest_pypi_pkg setuptools)
    fi
    update_one_recipe "$r" "$v" "$url"
  fi

  r="${TOPDIR}/recipes/stage2/wheel.recipe"
  if [[ -f "$r" ]]; then
    local pin; pin="$(pin_for wheel)"
    local v url
    if [[ -n "$pin" ]]; then
      v="$pin"; url="$(pypi_sdist_url wheel "$v")"
    else
      IFS="|" read -r v url < <(latest_pypi_pkg wheel)
    fi
    update_one_recipe "$r" "$v" "$url"
  fi
}


fill_missing_sha256() {
  echo "Preenchendo sha256 para receitas com pkg_sha256=\"SKIP\" (sem alterar versão/URL)..."
  while IFS= read -r -d '' r; do
    local sha url
    url="$(get_recipe_field "$r" pkg_url || true)"
    [[ -n "$url" ]] || continue
    sha="$(get_recipe_field "$r" pkg_sha256 || true)"
    [[ "$sha" == "SKIP" ]] || continue
    echo "  - $(basename "$r")"
    sha="$(sha256_of_url "$url")"
    update_recipe_field "$r" pkg_sha256 "$sha"
  done < <(find "${TOPDIR}/recipes" -type f -name "*.recipe" -print0)
}

# ---- Core (linux/musl/binutils/gcc) ----
# Mantém as heurísticas já implementadas na versão anterior do projeto, mas sem "..." e com parsing consistente.

latest_linux_headers() {
  # kernel.org (tarballs): https://cdn.kernel.org/pub/linux/kernel/
  # Heurística: escolher a última versão estável (v6.x.y) a partir do índice principal.
  local idx="${TMP_DIR}/kernel-index.html"
  fetch_text "https://cdn.kernel.org/pub/linux/kernel/" "$idx"

  # pega o último subdir v6.x/ (ou v5.x/ se necessário)
  local sub
  sub="$(grep -Eo 'href="v[0-9]+\.[0-9]+/' "$idx" \
        | sed -E 's/^href="(v[^/]+)\/$/\1/' \
        | sort -V | tail -n1)"
  [[ -n "$sub" ]] || { echo "Falha ao detectar subdir do kernel" >&2; return 1; }

  local idx2="${TMP_DIR}/kernel-${sub}.html"
  fetch_text "https://cdn.kernel.org/pub/linux/kernel/${sub}/" "$idx2"

  # linux-6.10.2.tar.xz, excluir rc.
  local t
  t="$(grep -Eo 'linux-[0-9]+\.[0-9]+(\.[0-9]+)?\.tar\.xz' "$idx2" \
      | grep -Ev 'rc' \
      | sort -V | tail -n1)"
  [[ -n "$t" ]] || { echo "Falha ao detectar tarball do kernel em ${sub}" >&2; return 1; }

  local v
  v="$(echo "$t" | sed -E 's/^linux-//; s/\.tar\.xz$//')"
  local url="https://cdn.kernel.org/pub/linux/kernel/${sub}/${t}"
  echo "${v}|${url}"
}

latest_musl() {
  local idx="${TMP_DIR}/musl-index.html"
  fetch_text "https://musl.libc.org/releases/" "$idx"

  local t
  t="$(grep -Eo 'musl-[0-9]+\.[0-9]+\.[0-9]+\.tar\.gz' "$idx" \
      | sort -V | tail -n1)"
  [[ -n "$t" ]] || { echo "Falha ao detectar tarball do musl" >&2; return 1; }

  local v
  v="$(echo "$t" | sed -E 's/^musl-//; s/\.tar\.gz$//')"
  local url="https://musl.libc.org/releases/${t}"
  echo "${v}|${url}"
}

latest_binutils() {
  local idx="${TMP_DIR}/binutils-index.html"
  fetch_text "https://ftp.gnu.org/gnu/binutils/" "$idx"

  local t
  t="$(grep -Eo 'binutils-[0-9]+\.[0-9]+(\.[0-9]+)?\.tar\.(xz|gz)' "$idx" \
      | sort -V | tail -n1)"
  [[ -n "$t" ]] || { echo "Falha ao detectar tarball do binutils" >&2; return 1; }

  local v
  v="$(echo "$t" | sed -E 's/^binutils-//; s/\.tar\.(xz|gz)$//')"
  local url="https://ftp.gnu.org/gnu/binutils/${t}"
  echo "${v}|${url}"
}

latest_gcc() {
  local idx="${TMP_DIR}/gcc-index.html"
  fetch_text "https://ftp.gnu.org/gnu/gcc/" "$idx"

  local d
  d="$(grep -Eo 'href="gcc-[0-9]+\.[0-9]+\.[0-9]+/' "$idx" \
      | sed -E 's/^href="(gcc-[^/]+)\/$/\1/' \
      | sort -V | tail -n1)"
  [[ -n "$d" ]] || { echo "Falha ao detectar diretório do GCC" >&2; return 1; }

  local v="${d#gcc-}"
  local t="gcc-${v}.tar.xz"
  local url="https://ftp.gnu.org/gnu/gcc/${d}/${t}"
  echo "${v}|${url}"
}

do_core_updates() {
  ensure_dir "$CACHE_DIR"
  ensure_dir "$TMP_DIR"

  local v url

  # linux-headers
  IFS="|" read -r v url < <(latest_linux_headers)
  local r="${TOPDIR}/recipes/cross/linux-headers.recipe"
  [[ -f "$r" ]] && update_one_recipe "$r" "$v" "$url"

  # musl (cross + stage2)
  IFS="|" read -r v url < <(latest_musl)
  for r in "${TOPDIR}/recipes/cross/musl.recipe" "${TOPDIR}/recipes/stage2/musl.recipe"; do
    [[ -f "$r" ]] && update_one_recipe "$r" "$v" "$url"
  done

  # binutils (cross + stage2)
  IFS="|" read -r v url < <(latest_binutils)
  for r in "${TOPDIR}/recipes/cross/binutils.recipe" "${TOPDIR}/recipes/stage2/binutils.recipe"; do
    [[ -f "$r" ]] && update_one_recipe "$r" "$v" "$url"
  done

  # gcc (cross bootstrap/final + stage2)
  IFS="|" read -r v url < <(latest_gcc)
  for r in "${TOPDIR}/recipes/cross/gcc-bootstrap.recipe" "${TOPDIR}/recipes/cross/gcc-final.recipe" "${TOPDIR}/recipes/stage2/gcc.recipe"; do
    [[ -f "$r" ]] && update_one_recipe "$r" "$v" "$url"
  done
}

main() {
  ensure_dir "$CACHE_DIR"
  ensure_dir "$TMP_DIR"

  load_pins

  if [[ "$PIN_CURRENT" -eq 1 ]]; then
    write_pins_current
    exit 0
  fi

  case "$MODE" in
    core)   update_core ;;
    extras) update_extras ;;
    all)    update_core; update_extras; fill_missing_sha256 ;;
  esac

  echo "Concluído. Revise os diffs antes de construir."
}

main
