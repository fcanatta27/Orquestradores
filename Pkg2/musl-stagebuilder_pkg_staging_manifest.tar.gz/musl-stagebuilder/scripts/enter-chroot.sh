#!/usr/bin/env bash
set -euo pipefail

TOPDIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
# shellcheck source=lib/build.sh
source "${TOPDIR}/lib/build.sh"
load_config "${TOPDIR}/config/config.env"

need_root() { [[ "$(id -u)" -eq 0 ]] || die "Execute como root (sudo) para montar e entrar no chroot."; }

need_root

# Verificações pré-chroot: garantir que ferramentas críticas existem no stage1
req_bins=(/usr/bin/bash /usr/bin/make /usr/bin/patch /usr/bin/tar /usr/bin/xz /usr/bin/gzip)
for b in "${req_bins[@]}"; do
  [[ -x "${STAGE1_ROOT}${b}" ]] || die "Stage1 incompleto: falta ${b} em ${STAGE1_ROOT}${b}"
done

# Preparar dir do chroot
mkdir -p "${CHROOT_DIR}"

# Bind-mount do stage1 root em CHROOT_DIR
mountpoint -q "${CHROOT_DIR}" || mount --bind "${STAGE1_ROOT}" "${CHROOT_DIR}"

# Montagens padrão mínimas
mountpoint -q "${CHROOT_DIR}/proc"   || mount -t proc proc "${CHROOT_DIR}/proc"
mountpoint -q "${CHROOT_DIR}/sys"    || mount -t sysfs sys "${CHROOT_DIR}/sys"
mountpoint -q "${CHROOT_DIR}/dev"    || mount --bind /dev "${CHROOT_DIR}/dev"
mountpoint -q "${CHROOT_DIR}/dev/pts"|| mount -t devpts devpts "${CHROOT_DIR}/dev/pts"
mountpoint -q "${CHROOT_DIR}/run"    || mount --bind /run "${CHROOT_DIR}/run"

# DNS (opcional)
if [[ "${CHROOT_COPY_RESOLV}" == "1" && -f /etc/resolv.conf ]]; then
  mkdir -p "${CHROOT_DIR}/etc"
  cp -L /etc/resolv.conf "${CHROOT_DIR}/etc/resolv.conf"
fi

# Hostname (opcional)
mkdir -p "${CHROOT_DIR}/etc"
echo "${CHROOT_HOSTNAME}" > "${CHROOT_DIR}/etc/hostname" || true

# Entrar com ambiente limpo (evita vazamento de variáveis do host)
echo "Entrando no chroot em ${CHROOT_DIR}"
exec chroot "${CHROOT_DIR}" /usr/bin/env -i \
  HOME=/root TERM="${TERM:-linux}" \
  PATH=/usr/bin:/usr/sbin:/bin:/sbin \
  /usr/bin/bash --login
