#!/usr/bin/env bash
set -euo pipefail

TOPDIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
# shellcheck source=lib/build.sh
source "${TOPDIR}/lib/build.sh"
# shellcheck source=lib/graph.sh
source "${TOPDIR}/lib/graph.sh"
load_config "${TOPDIR}/config/config.env"

usage() {
  cat <<EOF
Uso: $0 <alvo>
Alvos:
  cross   - constrói cross-toolchain temporário (headers + binutils + gcc + musl + gcc-final)
  stage1  - constrói stage1 mínimo fora do chroot (raiz em ${STAGE1_ROOT})
  stage2  - constrói stage2 dentro do chroot (assume /stagebuilder montado)
  stage3  - stub para stage3 (você decide o conjunto final)

Exemplos:
  $0 cross
  $0 stage1
EOF
}

target="${1:-}"
[[ -n "$target" ]] || { usage; exit 1; }

case "$target" in
  cross)
    prefix="${TOOLS_DIR}"
    sysroot="${SYSROOT_DIR}"
    ensure_dir "$prefix" "$sysroot"
    # Lista de pacotes do cross (mínimo funcional)
    pkgs=(linux-headers binutils gcc-bootstrap musl gcc-final)
    mapfile -t order < <(toposort cross "${pkgs[@]}")
    ui_queue_header "cross" "${#order[@]}"
    for i in "${!order[@]}"; do ui_queue_item "$((i+1))" "${#order[@]}" "cross/${order[$i]}"; done
    ui_hr
    for i in "${!order[@]}"; do
      ui_step "PROGRESS" "$((i+1))/${#order[@]}  cross/${order[$i]}"
      build_one cross "${order[$i]}" "$prefix" "$sysroot" "$sysroot"
    done
    ;;

  stage1)
    prefix="${STAGE1_ROOT}/usr"
    sysroot="${STAGE1_ROOT}"
    ensure_dir "$prefix" "$sysroot"
    pkgs=(busybox bash coreutils findutils gawk grep sed diffutils make patch tar xz gzip bzip2 pkgconf)
    mapfile -t order < <(toposort stage1 "${pkgs[@]}")
    ui_queue_header "stage1" "${#order[@]}"
    for i in "${!order[@]}"; do ui_queue_item "$((i+1))" "${#order[@]}" "stage1/${order[$i]}"; done
    ui_hr
    for i in "${!order[@]}"; do
      ui_step "PROGRESS" "$((i+1))/${#order[@]}  stage1/${order[$i]}"
      build_one stage1 "${order[$i]}" "$prefix" "${SYSROOT_DIR}" "${STAGE1_ROOT}"
    done
    # Ajustes mínimos de filesystem
    "${TOPDIR}/scripts/stage1-finalize.sh"
    ;;

  stage2)
    # Dentro do chroot, prefix normal é /usr
    prefix="/usr"
    sysroot="/"
    pkgs=(
      busybox bash coreutils findutils gawk grep sed diffutils make patch
      tar xz gzip bzip2 zlib zstd file pkgconf m4 autoconf
      automake libtool gettext bison flex texinfo gperf perl openssl ca-certificates
      curl libffi ncurses readline python setuptools wheel ninja meson gmp
      mpfr mpc isl expat git binutils musl gcc cmake
    )
    mapfile -t order < <(toposort stage2 "${pkgs[@]}")
    ui_queue_header "stage2" "${#order[@]}"
    for i in "${!order[@]}"; do ui_queue_item "$((i+1))" "${#order[@]}" "stage2/${order[$i]}"; done
    ui_hr
    for i in "${!order[@]}"; do
      ui_step "PROGRESS" "$((i+1))/${#order[@]}  stage2/${order[$i]}"
      build_one stage2 "${order[$i]}" "$prefix" "/" ""
    done
    ;;

stage3)
  prefix="/"
  ensure_dir "${STAGE3_ROOT}"
  # Core para toolchain definitiva (adicione seus pacotes finais em recipes/stage3/)
  pkgs=(binutils gmp mpfr mpc isl musl gcc)
  mapfile -t order < <(toposort stage3 "${pkgs[@]}")
  ui_queue_header "stage3" "${#order[@]}"
  for i in "${!order[@]}"; do ui_queue_item "$((i+1))" "${#order[@]}" "stage3/${order[$i]}"; done
  ui_hr
  for i in "${!order[@]}"; do
    ui_step "PROGRESS" "$((i+1))/${#order[@]}  stage3/${order[$i]}"
    build_one stage3 "${order[$i]}" "$prefix" "/" "${STAGE3_ROOT}"
  done
  ui_ok "Stage3 core concluído em: ${STAGE3_ROOT}"
  ;;

  *)
    usage; exit 1;;
esac
