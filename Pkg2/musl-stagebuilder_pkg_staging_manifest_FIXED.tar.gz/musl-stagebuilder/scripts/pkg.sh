#!/usr/bin/env bash
set -euo pipefail

TOPDIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

# shellcheck source=lib/build.sh
source "${TOPDIR}/lib/build.sh"
# shellcheck source=lib/pkgmgr.sh
source "${TOPDIR}/lib/pkgmgr.sh"

usage() {
  cat <<'EOF'
Uso:
  pkg install <pkg> [--stage stage3] [--commit rsync|tar]
  pkg upgrade <pkg> [--stage stage3] [--commit rsync|tar]
  pkg remove  <pkg> [--purge-etc]
  pkg list-installed
  pkg info <pkg>

Variáveis úteis:
  UI_QUIET=1         Suprime comandos (mostra apenas etapas)
  PKG_STAGE_ROOT=... Raiz do staging (default /var/tmp/pkg-stage)
  PKG_DB_ROOT=...    DB do pkg (default /var/lib/pkg/db)
EOF
}

cmd="${1:-}"; shift || true
case "$cmd" in
  -h|--help|help|"") usage; exit 0;;
esac

stage="stage3"
commit_mode="rsync"
purge_etc="0"

while [[ $# -gt 0 ]]; do
  case "$1" in
    --stage)
      [[ $# -ge 2 ]] || die "Falta argumento para --stage"
      stage="$2"; shift 2;;
    --commit)
      [[ $# -ge 2 ]] || die "Falta argumento para --commit"
      commit_mode="$2"; shift 2;;
    --purge-etc) purge_etc="1"; shift;;
    *) break;;
  esac
done

load_config "${TOPDIR}/config/config.env"

pkgname="${1:-}"

case "$cmd" in
  install|upgrade)
    [[ -n "$pkgname" ]] || die "Informe o pacote."
    recipe="${TOPDIR}/recipes/${stage}/${pkgname}.recipe"
    [[ -f "$recipe" ]] || die "Receita não encontrada: $recipe"

    # Obter versão da recipe sem executar build.
    pkg_version="$(bash -c "set -euo pipefail; source '$recipe'; echo \"\${pkg_version:-}\"" 2>/dev/null || true)"
    [[ -n "$pkg_version" ]] || pkg_version="unknown"

    stagedir="${PKG_STAGE_ROOT}/${pkgname}-${pkg_version}"
    rm -rf "$stagedir"
    ensure_dir "$stagedir"

    ui_hr
    ui_title "pkg ${cmd}: ${pkgname} (${stage})"
    ui_hr
    ui_step "STAGE" "Instalando em staging: ${stagedir}"

    # Apenas etapas, sem spam de comandos.
    export UI_QUIET="${UI_QUIET:-1}"

    # Build+install para DESTDIR=staging. prefix sempre /usr no sistema final.
    build_one "$stage" "$pkgname" "/usr" "" "$stagedir"

    pkg_validate_stage "$stagedir" "$recipe"

    ui_step "RECORD" "Gerando manifesto em ${PKG_DB_ROOT}"
    tmp_manifest="$(mktemp)"; tmp_dirs="$(mktemp)"
    pkg_manifest_from_stage "$stagedir" "$tmp_manifest"
    pkg_dirs_from_stage "$stagedir" "$tmp_dirs"

    old_manifest=""
    if [[ "$cmd" = "upgrade" && -f "$(pkg_db_dir "$pkgname")/files" ]]; then
      old_manifest="$(mktemp)"
      cp -f "$(pkg_db_dir "$pkgname")/files" "$old_manifest"
    fi

    pkg_db_write "$pkgname" "version" "$pkg_version"
    pkg_db_write_file "$pkgname" "files" "$tmp_manifest"
    pkg_db_write_file "$pkgname" "dirs" "$tmp_dirs"

    ui_step "COMMIT" "Aplicando staging no sistema (sem tocar /usr durante install)"
    pkg_commit_stage "$stagedir" "$commit_mode"

    if [[ -n "$old_manifest" ]]; then
      ui_step "CLEANUP" "Removendo órfãos da versão anterior"
      pkg_upgrade_cleanup_orphans "$old_manifest" "$tmp_manifest"
    fi

    rm -f "$tmp_manifest" "$tmp_dirs" ${old_manifest:+"$old_manifest"} || true
    ui_ok "${cmd} concluído: ${pkgname} ${pkg_version}"
    ;;

  remove)
    [[ -n "$pkgname" ]] || die "Informe o pacote."
    pkg_remove_files "$pkgname" "$purge_etc"
    ;;

  list-installed)
    ensure_dir "$PKG_DB_ROOT"
    ls -1 "$PKG_DB_ROOT" 2>/dev/null || true
    ;;

  info)
    [[ -n "$pkgname" ]] || die "Informe o pacote."
    if pkg_is_installed "$pkgname"; then
      echo "pkg: $pkgname"
      echo "version: $(pkg_db_read "$pkgname" version)"
      echo "files: $(wc -l < "$(pkg_db_dir "$pkgname")/files" 2>/dev/null || echo 0)"
    else
      die "Pacote não instalado: $pkgname"
    fi
    ;;

  *)
    usage
    die "Comando desconhecido: $cmd"
    ;;
esac
