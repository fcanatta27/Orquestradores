#!/usr/bin/env bash
set -euo pipefail

TOPDIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
# shellcheck source=lib/build.sh
source "${TOPDIR}/lib/build.sh"
load_config "${TOPDIR}/config/config.env"

root="${STAGE1_ROOT}"

# Diretórios básicos
mkdir -p "$root"/{dev,proc,sys,run,tmp,root,home,var,etc,usr/bin,usr/sbin,bin,sbin}
chmod 1777 "$root/tmp"

# Arquivos básicos de /etc (mínimo funcional)
cat > "$root/etc/passwd" <<'EOF'
root:x:0:0:root:/root:/bin/bash
EOF

cat > "$root/etc/group" <<'EOF'
root:x:0:
EOF

cat > "$root/etc/hosts" <<'EOF'
127.0.0.1 localhost
::1       localhost
EOF

cat > "$root/etc/profile" <<'EOF'
export PATH=/usr/bin:/usr/sbin:/bin:/sbin
export HOME=/root
export LC_ALL=C
EOF

# Symlinks de conveniência
if [[ -x "$root/usr/bin/bash" && ! -e "$root/bin/bash" ]]; then
  ln -sf ../usr/bin/bash "$root/bin/bash"
fi
if [[ -x "$root/usr/bin/busybox" && ! -e "$root/bin/sh" ]]; then
  ln -sf busybox "$root/bin/sh" || true
fi

# Copiar stagebuilder para dentro do root (para uso no chroot)
mkdir -p "$root/stagebuilder"
if command -v rsync >/dev/null 2>&1; then
  rsync -a --delete --exclude 'work/' "${TOPDIR}/" "$root/stagebuilder/"
else
  # Fallback simples
  rm -rf "$root/stagebuilder"
  mkdir -p "$root/stagebuilder"
  cp -a "${TOPDIR}/." "$root/stagebuilder/"
  rm -rf "$root/stagebuilder/work" || true
fi

echo "Stage1 finalizado em: $root"
