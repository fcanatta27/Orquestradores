#!/usr/bin/env bash
set -euo pipefail
# shellcheck source=lib/common.sh
source "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/lib/common.sh"

fetch_url() {
  local url="$1" out="$2"
  ensure_dir "$(dirname "$out")"
  if [[ -s "$out" ]]; then
    echo "Fonte já existe: $out"
    return 0
  fi
  echo "Baixando: $url"
  # Preferir curl; fallback wget
  if command -v curl >/dev/null 2>&1; then
    ${FETCH_CMD} "$out" "$url"
  elif command -v wget >/dev/null 2>&1; then
    ${WGET_CMD} "$out" "$url"
  else
    die "curl ou wget são necessários para download"
  fi
}

verify_sha256() {
  local file="$1" expected="$2" allow_missing="$3"
  if [[ -z "$expected" || "$expected" == "SKIP" ]]; then
    [[ "$allow_missing" == "1" ]] && { warn "Sem sha256 para $file (ALLOW_MISSING_SHA256=1)"; return 0; }
    die "Receita sem sha256 para $file. Defina ALLOW_MISSING_SHA256=1 para ignorar (não recomendado)."
  fi
  local got
  got="$(sha256_file "$file")"
  [[ "$got" == "$expected" ]] || die "SHA256 inválido para $file. Esperado=$expected Obtido=$got"
}

extract_tarball() {
  local tarball="$1" dest="$2"
  ensure_dir "$dest"
  case "$tarball" in
    *.tar.gz|*.tgz) run tar -xzf "$tarball" -C "$dest" ;;
    *.tar.xz)       run tar -xJf "$tarball" -C "$dest" ;;
    *.tar.bz2)      run tar -xjf "$tarball" -C "$dest" ;;
    *.tar.zst)      need_cmd zstd; run tar --use-compress-program=unzstd -xf "$tarball" -C "$dest" ;;
    *.tar)          run tar -xf "$tarball" -C "$dest" ;;
    *) die "Formato de tarball não suportado: $tarball" ;;
  esac
}
