#!/usr/bin/env bash
set -euo pipefail

# Implementa operações de "pkg" (install/remove/upgrade) com staging, manifesto e commit.

# shellcheck source=lib/common.sh
source "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/lib/common.sh"

PKG_DB_ROOT="${PKG_DB_ROOT:-/var/lib/pkg/db}"
PKG_STAGE_ROOT="${PKG_STAGE_ROOT:-/var/tmp/pkg-stage}"

pkg_db_dir() { echo "${PKG_DB_ROOT}/$1"; }
pkg_is_installed() { [[ -d "$(pkg_db_dir "$1")" ]]; }

pkg_db_read() {
  local pkg="$1" key="$2"
  local f="$(pkg_db_dir "$pkg")/${key}"
  [[ -f "$f" ]] && cat "$f" || true
}

pkg_db_write() {
  local pkg="$1" key="$2" value="$3"
  local d; d="$(pkg_db_dir "$pkg")"
  ensure_dir "$d"
  printf '%s\n' "$value" > "${d}/${key}"
}

pkg_db_write_file() {
  local pkg="$1" key="$2" src="$3"
  local d; d="$(pkg_db_dir "$pkg")"
  ensure_dir "$d"
  cp -f "$src" "${d}/${key}"
}

pkg_manifest_from_stage() {
  local stagedir="$1" out="$2"
  (cd "$stagedir" && find . -type f -o -type l) \
    | sed -e 's|^\./|/|' \
    | LC_ALL=C sort > "$out"
}

pkg_dirs_from_stage() {
  local stagedir="$1" out="$2"
  (cd "$stagedir" && find . -type d) \
    | sed -e 's|^\./|/|' \
    | LC_ALL=C sort > "$out"
}

pkg_validate_stage() {
  local stagedir="$1" recipe="$2"

  ui_step "VALIDATE" "Checando staging: ${stagedir}"

  [[ -d "$stagedir" ]] || die "Staging não existe: $stagedir"
  [[ -d "${stagedir}/usr" ]] || die "Staging inválido: não contém /usr (${stagedir}/usr)"
  local nfiles
  nfiles=$(find "${stagedir}/usr" -mindepth 1 -maxdepth 3 -type f -o -type l 2>/dev/null | wc -l | tr -d ' ')
  [[ "${nfiles}" != "0" ]] || die "Staging vazio: nenhum arquivo em ${stagedir}/usr"

  # Reusa guard estático para garantir que a receita respeita DESTDIR.
  if [[ "${ENFORCE_DESTDIR_GUARD:-1}" = "1" ]]; then
    DESTDIR="$stagedir" check_recipe_destdir_guard "$recipe"
  fi

  # Checagem leve de loader musl (best-effort): se houver ELF em /usr/bin no staging,
  # garantir que exista ld-musl no staging ou no sistema.
  if command -v file >/dev/null 2>&1; then
    if find "${stagedir}/usr/bin" -type f -maxdepth 1 -print0 2>/dev/null | xargs -0 -r file -b 2>/dev/null | grep -qE '^ELF '; then
      if ! ls "${stagedir}"/lib/ld-musl-*.so.1 >/dev/null 2>&1 && ! ls /lib/ld-musl-*.so.1 >/dev/null 2>&1; then
        die "ELFs detectados no staging, mas ld-musl-*.so.1 não encontrado (nem no staging nem em /lib)."
      fi
    fi
  fi
}

pkg_commit_stage() {
  local stagedir="$1" commit_mode="${2:-rsync}"

  # Caminhos críticos devem ser atualizados no final com rename atômico (best-effort)
  # para reduzir risco de deixar o sistema em estado intermediário.
  local critical_globs
  critical_globs="${PKG_CRITICAL_GLOBS:-/lib/ld-musl-*.so.1 /usr/lib/libc.so* /usr/bin/sh /usr/bin/bash /usr/bin/cc /usr/bin/gcc /usr/bin/g++ /usr/bin/ld /usr/bin/as /usr/bin/ar /usr/bin/strip}"
  local critical_list=()
  local g
  for g in $critical_globs; do
    # Expand em staging; converte para caminho relativo absoluto do sistema (sem prefixo stagedir)
    while IFS= read -r -d '' p; do
      critical_list+=("/${p#${stagedir}/}")
    done < <(find "$stagedir" -path "${stagedir}${g}" -print0 2>/dev/null || true)
  done

  ui_step "COMMIT" "Aplicando no sistema (modo: ${commit_mode})"

  # 1) /etc: regra segura
  #    - se arquivo já existe, escreve .new
  #    - se não existe, instala normal
  if [[ -d "${stagedir}/etc" ]]; then
    while IFS= read -r -d '' src; do
      local rel dst
      rel="${src#"${stagedir}"}"
      dst="$rel"
      ensure_dir "$(dirname "$dst")"
      if [[ -e "$dst" ]]; then
        cp -a "$src" "${dst}.new"
      else
        cp -a "$src" "$dst"
      fi
    done < <(find "${stagedir}/etc" \( -type f -o -type l \) -print0)
  fi

  # 2) Restante: copiar tudo exceto /etc e exceto caminhos críticos
  if [[ "$commit_mode" = "rsync" && $(command -v rsync >/dev/null 2>&1; echo $?) -eq 0 ]]; then
    # Observação: não usamos --delete (poderia remover arquivos de outros pacotes)
    local rsync_excludes=(--exclude='/etc/**')
    local c
    for c in "${critical_list[@]}"; do
      rsync_excludes+=("--exclude=${c}")
    done
    rsync -aHAX --numeric-ids --inplace "${rsync_excludes[@]}" "${stagedir}/" "/"
  else
    # tar|tar fallback sem --delete; não tem excludes granulares fáceis, então aplicamos depois para críticos.
    (cd "$stagedir" && tar -cpf - --exclude='./etc' .) | (cd / && tar -xpf -)
  fi

  # 3) Atualiza caminhos críticos por último (rename atômico)
  if [[ "${#critical_list[@]}" -gt 0 ]]; then
    local rel src dst tmp
    for rel in "${critical_list[@]}"; do
      src="${stagedir}${rel}"
      dst="$rel"
      [[ -e "$src" || -L "$src" ]] || continue
      ensure_dir "$(dirname "$dst")"
      tmp="${dst}.new"
      rm -f "$tmp" 2>/dev/null || true
      cp -a "$src" "$tmp"
      mv -f "$tmp" "$dst"
    done
  fi
}

pkg_remove_files() {
  local pkg="$1" purge_etc="${2:-0}"
  local dbd; dbd="$(pkg_db_dir "$pkg")"
  [[ -d "$dbd" ]] || die "Pacote não instalado: $pkg"

  ui_step "REMOVE" "Removendo arquivos de ${pkg}"

  local files="${dbd}/files"
  [[ -f "$files" ]] || die "Manifesto não encontrado: $files"

  # Remove arquivos (não remove /etc por padrão)
  while IFS= read -r f; do
    [[ -n "$f" ]] || continue
    if [[ "$purge_etc" != "1" && "$f" == /etc/* ]]; then
      continue
    fi
    rm -f -- "$f" 2>/dev/null || true
  done < "$files"

  # Remove diretórios vazios (do mais profundo ao mais raso)
  local dirs="${dbd}/dirs"
  if [[ -f "$dirs" ]]; then
    tac "$dirs" | while IFS= read -r d; do
      [[ -n "$d" ]] || continue
      [[ "$d" == / ]] && continue
      rmdir --ignore-fail-on-non-empty "$d" 2>/dev/null || true
    done
  fi

  rm -rf "$dbd"
  ui_ok "Remoção concluída: ${pkg}"
}

pkg_upgrade_cleanup_orphans() {
  local old_manifest="$1" new_manifest="$2"
  # Remove arquivos que existiam antes e não existem mais (exceto /etc)
  comm -23 "$old_manifest" "$new_manifest" | while IFS= read -r f; do
    [[ -n "$f" ]] || continue
    [[ "$f" == /etc/* ]] && continue
    rm -f -- "$f" 2>/dev/null || true
  done
}
