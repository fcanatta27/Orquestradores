#!/usr/bin/env bash
set -euo pipefail
# shellcheck source=lib/common.sh
source "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/lib/common.sh"
# shellcheck source=lib/fetch.sh
source "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/lib/fetch.sh"

load_config() {
  local cfg="${1:-}"
  [[ -n "$cfg" ]] || cfg="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/config/config.env"
  # shellcheck disable=SC1090
  source "$cfg"
  export TOPDIR WORKDIR BUILD_TRIPLE TARGET_TRIPLE TOOLS_DIR SYSROOT_DIR STAGE1_ROOT STAGE2_ROOT STAGE3_ROOT
  export SOURCES_DIR BUILD_DIR LOG_DIR STATE_DIR JOBS UMASK ALLOW_MISSING_SHA256
  export FETCH_CMD WGET_CMD CHROOT_DIR CHROOT_MOUNTS CHROOT_HOSTNAME CHROOT_COPY_RESOLV
  # Flags opcionais (receitas podem usar)
  export STATIC_BUSYBOX
  umask "$UMASK"
  ensure_dir "$WORKDIR" "$SOURCES_DIR" "$BUILD_DIR" "$LOG_DIR" "$STATE_DIR"
}

state_done() { [[ -f "${STATE_DIR}/$1.done" ]]; }
mark_done() { echo "$(timestamp)" > "${STATE_DIR}/$1.done"; }

clean_builddir() { rm -rf "$1" && mkdir -p "$1"; }

build_one() {
  # Args:
  #   stage pkg prefix compile_sysroot destroot
  local stage="$1" pkg="$2" prefix="$3" compile_sysroot="$4" destroot="$5"
  local key="${stage}.${pkg}"
  state_done "$key" && { ui_ok "Já concluído: $key"; return 0; }

  local recipe="${TOPDIR}/recipes/${stage}/${pkg}.recipe"
  [[ -f "$recipe" ]] || die "Receita não encontrada: $recipe"

  local logfile="${LOG_DIR}/${stage}/${pkg}.log"
  ui_step "BUILD" "${stage}/${pkg} (log: ${logfile})"

  # Executa o build em subshell para não "vazar" redirecionamentos (tee) para o processo chamador.
  (
    set -euo pipefail
    log_init "$logfile"
    ui_title "==> Iniciando ${stage}/${pkg}"

  # Reset vars de receita
  pkg_name="" pkg_version="" pkg_url="" pkg_sha256="" pkg_deps=""
  pkg_srcdir="" pkg_builddir="" pkg_tarball=""
  pkg_configure_args="" pkg_make_args="" pkg_env=""

  # shellcheck disable=SC1090
  source "$recipe"

  [[ -n "${pkg_name:-}" ]] || die "pkg_name não definido em $recipe"
  [[ -n "${pkg_url:-}" ]] || die "pkg_url não definido em $recipe"

  pkg_tarball="${SOURCES_DIR}/$(basename "${pkg_url}")"
  fetch_url "$pkg_url" "$pkg_tarball"
  verify_sha256 "$pkg_tarball" "${pkg_sha256:-}" "$ALLOW_MISSING_SHA256"

  local workpkg="${BUILD_DIR}/${stage}/${pkg}"
  clean_builddir "$workpkg"
# Extrair se for tarball; caso contrário, tratar como "fonte" simples (arquivo único).
case "$pkg_tarball" in
  *.tar.gz|*.tgz|*.tar.xz|*.tar.bz2|*.tar.zst|*.tar)
    extract_tarball "$pkg_tarball" "$workpkg"
    ;;
  *)
    ensure_dir "$workpkg"
    cp -f "$pkg_tarball" "$workpkg/"
    ;;
esac

  # Descobrir diretório de fonte (primeiro subdir)
  pkg_srcdir="$(find "$workpkg" -mindepth 1 -maxdepth 1 -type d | head -n1)"
  [[ -n "$pkg_srcdir" ]] || pkg_srcdir="$workpkg"
  [[ -d "$pkg_srcdir" ]] || die "Falha ao localizar srcdir para $pkg em $workpkg"
  apply_patches "$pkg" "$pkg_srcdir" "$TOPDIR"

  pkg_builddir="${workpkg}/build"
  mkdir -p "$pkg_builddir"

  # PATH e toolchain
  export PATH="${TOOLS_DIR}/bin:${PATH}"

  # Defaults para cross-compilação (stage1/cross) e build nativo (stage2)
  export PREFIX="${prefix}"
  export COMPILE_SYSROOT="${compile_sysroot}"
  export DESTROOT="${destroot}"
  export DESTDIR="${destroot}"  # compat com make install DESTDIR

  if [[ -n "${TARGET_TRIPLE:-}" && -x "${TOOLS_DIR}/bin/${TARGET_TRIPLE}-gcc" ]]; then
    export CC="${TOOLS_DIR}/bin/${TARGET_TRIPLE}-gcc --sysroot=${COMPILE_SYSROOT}"
    export CXX="${TOOLS_DIR}/bin/${TARGET_TRIPLE}-g++ --sysroot=${COMPILE_SYSROOT}"
    export AR="${TOOLS_DIR}/bin/${TARGET_TRIPLE}-ar"
    export AS="${TOOLS_DIR}/bin/${TARGET_TRIPLE}-as"
    export LD="${TOOLS_DIR}/bin/${TARGET_TRIPLE}-ld"
    export RANLIB="${TOOLS_DIR}/bin/${TARGET_TRIPLE}-ranlib"
    export STRIP="${TOOLS_DIR}/bin/${TARGET_TRIPLE}-strip"
  else
    # nativo (dentro do chroot)
    export CC="${CC:-cc}"
    export CXX="${CXX:-c++}"
  fi

  # Receita pode sobrescrever/ajustar env
  if [[ -n "${pkg_env:-}" ]]; then
    # shellcheck disable=SC2086
    eval "export ${pkg_env}"
  fi


# Proteção contra regressões: quando DESTDIR estiver setado (e não for "/"),
# falhar se install_pkg() contiver caminhos absolutos sem ${DESTDIR}/${DESTROOT}.
if [[ "${ENFORCE_DESTDIR_GUARD:-1}" = "1" && -n "${DESTDIR:-}" && "${DESTDIR}" != "/" ]]; then
  check_recipe_destdir_guard "$recipe"
fi


  declare -F build_pkg >/dev/null || die "Receita $recipe não define build_pkg()"
  declare -F install_pkg >/dev/null || die "Receita $recipe não define install_pkg()"

  build_pkg
  install_pkg

    mark_done "$key"
    ui_title "==> Concluído ${stage}/${pkg}"
  )
}

