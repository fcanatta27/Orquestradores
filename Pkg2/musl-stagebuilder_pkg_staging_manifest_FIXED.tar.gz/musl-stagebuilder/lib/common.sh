#!/usr/bin/env bash
set -euo pipefail

# ---------- UX/UI (ANSI) ----------
# Desative com NO_COLOR=1 ou UI_COLOR=0.
UI_COLOR="${UI_COLOR:-1}"
if [[ -n "${NO_COLOR:-}" || "${UI_COLOR}" = "0" || ! -t 1 ]]; then
  UI_BOLD=""; UI_DIM=""; UI_RESET=""
  UI_RED=""; UI_GREEN=""; UI_YELLOW=""; UI_BLUE=""; UI_MAGENTA=""; UI_CYAN=""
else
  UI_BOLD=$'\033[1m'
  UI_DIM=$'\033[2m'
  UI_RESET=$'\033[0m'
  UI_RED=$'\033[31m'
  UI_GREEN=$'\033[32m'
  UI_YELLOW=$'\033[33m'
  UI_BLUE=$'\033[34m'
  UI_MAGENTA=$'\033[35m'
  UI_CYAN=$'\033[36m'
fi

ui_hr() { printf '%*s\n' "${1:-72}" '' | tr ' ' '─'; }
ui_title() { echo "${UI_BOLD}${UI_CYAN}$*${UI_RESET}"; }
ui_step() {
  local phase="${1:-}" msg="${2:-}";
  if [[ -n "$phase" ]]; then
    echo "${UI_BOLD}${UI_BLUE}==>${UI_RESET} ${UI_BOLD}${phase}${UI_RESET}  ${msg}";
  else
    echo "${UI_BOLD}${UI_BLUE}==>${UI_RESET} ${msg}";
  fi
}
ui_cmd() {
  # UI_QUIET=1 suprime comandos (mantém apenas etapas/headers), útil para operações de pkg.
  [[ "${UI_QUIET:-0}" = "1" ]] && return 0
  echo "${UI_DIM}[$(timestamp)]${UI_RESET} ${UI_BOLD}${UI_MAGENTA}RUN${UI_RESET} $*"
}
ui_ok() { echo "${UI_BOLD}${UI_GREEN}OK${UI_RESET}  $*"; }
ui_warn() { echo "${UI_BOLD}${UI_YELLOW}WARN${UI_RESET} $*"; }
ui_err() { echo "${UI_BOLD}${UI_RED}ERROR${UI_RESET} $*"; }
ui_note() { echo "${UI_DIM}[$(timestamp)]${UI_RESET} $*"; }

ui_queue_header() {
  local target="$1" total="$2"
  ui_hr
  ui_title "Fila de build: ${target}  (${total} pacotes)"
  ui_hr
}

ui_queue_item() {
  local idx="$1" total="$2" item="$3"
  printf "%s%2d/%-2d%s %s\n" "${UI_BOLD}${UI_CYAN}" "$idx" "$total" "${UI_RESET}" "$item"
}

die() { ui_err "$*" >&2; exit 1; }
warn(){ ui_warn "$*" >&2; }

need_cmd() { command -v "$1" >/dev/null 2>&1 || die "Comando necessário não encontrado: $1"; }

abspath() {
  local p="$1"
  if [[ "$p" = /* ]]; then echo "$p"; else echo "$(pwd)/$p"; fi
}

sha256_file() {
  local f="$1"
  if command -v sha256sum >/dev/null 2>&1; then sha256sum "$f" | awk '{print $1}'
  elif command -v shasum >/dev/null 2>&1; then shasum -a 256 "$f" | awk '{print $1}'
  else die "sha256sum/shasum não encontrado"
  fi
}

ensure_dir() { mkdir -p "$1"; }

log_init() {
  local logfile="$1"
  ensure_dir "$(dirname "$logfile")"
  if [[ "${UI_QUIET:-0}" = "1" ]]; then
    exec >>"$logfile" 2>&1
  else
    exec > >(tee -a "$logfile") 2>&1
  fi
}

timestamp() { date -u +"%Y-%m-%dT%H:%M:%SZ"; }

run() {
  ui_cmd "$@"
  "$@"
}


# Falha o build se a receita tentar instalar fora de DESTDIR/DESTROOT quando DESTDIR estiver setado.
# A checagem é estática: inspeciona o corpo de install_pkg() e procura caminhos absolutos (ex.: /usr/bin)
# que não estejam prefixados por ${DESTDIR} ou ${DESTROOT}.
check_recipe_destdir_guard() {
  local recipe="$1"
  [[ -f "$recipe" ]] || die "Receita não encontrada para checagem DESTDIR: $recipe"

  # Heurística: se a receita usa /usr como prefix (rootfs-style), então install_pkg() deve respeitar DESTDIR.
  local rootfs_style="0"
  if grep -qE -- '--prefix=/usr(\s|$)|-Dprefix=/usr(\s|$)' "$recipe"; then
    rootfs_style="1"
  fi
  if grep -qE -- '\bPREFIX=/usr\b' "$recipe"; then
    rootfs_style="1"
  fi

  # Extrai o bloco install_pkg() com numeração da linha original
  local block
  block="$(
    awk '
      /^install_pkg\(\)[[:space:]]*\{/ { inside=1 }
      inside { printf "%d:%s\n", NR, $0 }
      inside && /^[[:space:]]*\}[[:space:]]*$/ { exit }
    ' "$recipe" || true
  )"
  [[ -n "$block" ]] || die "Falha ao extrair install_pkg() para checagem DESTDIR em: $recipe"

  # 1) Caminhos absolutos suspeitos em install_pkg() sem ${DESTDIR}/${DESTROOT}.
  #    Heurística conservadora: marca paths comuns de rootfs (/usr, /etc, /bin, /lib, /opt, /var, /run).
  local abs_bad
  abs_bad="$(
    printf '%s\n' "$block" | awk -F: '
      {
        line=$0;
        sub(/^[0-9]+:/,"",line);
        # ignora comentários
        if (line ~ /^[[:space:]]*#/) next;
        # permite quando usa DESTDIR/DESTROOT
        if (line ~ /\$\{?(DESTDIR|DESTROOT)\}?/) next;
        # ignora /dev,/proc,/sys (não são instalados por recipes)
        if (line ~ /(^|[[:space:]])\/(dev|proc|sys)\b/) next;
        if (line ~ /(^|[[:space:]])\/(usr|etc|bin|sbin|lib|lib64|opt|var|run)\b/) print $0;
      }
    ' || true
  )"

  # 2) Instalação via make/pip sem DESTDIR/root quando for rootfs-style
  local install_bad=""
  if [[ "$rootfs_style" = "1" ]]; then
    install_bad="$(
      printf '%s\n' "$block" | awk -F: '
        {
          line=$0; sub(/^[0-9]+:/,"",line);
          if (line ~ /^[[:space:]]*#/) next;
          if (line ~ /\b(make|gmake)\b/ && line ~ /\binstall\b/ ) {
            if (line !~ /\bDESTDIR\b/ && line !~ /\bDESTROOT\b/ ) print $0;
          }
        }
      ' || true
    )"

    # pip install com --prefix=/usr deve usar --root quando DESTDIR estiver setado
    local pip_bad
    pip_bad="$(
      printf '%s\n' "$block" | awk -F: '
        {
          line=$0; sub(/^[0-9]+:/,"",line);
          if (line ~ /^[[:space:]]*#/) next;
          if (line ~ /\bpip\b/ && line ~ /\binstall\b/ && line ~ /--prefix=\/usr/ ) {
            if (line !~ /--root([=[:space:]]|$)/ && line !~ /root_args\[@\]/ ) print $0;
          }
        }
      ' || true
    )"
    if [[ -n "$pip_bad" ]]; then
      install_bad="${install_bad}"$'\n'"${pip_bad}"
    fi
  fi

  if [[ -n "$abs_bad" || -n "$install_bad" ]]; then
    echo "ERROR: Checagem DESTDIR falhou: a receita tenta instalar fora de DESTDIR/DESTROOT." >&2
    echo "Receita: $recipe" >&2
    echo "DESTDIR atual: ${DESTDIR}" >&2
    if [[ -n "$abs_bad" ]]; then
      echo "Ocorrências: caminhos absolutos em install_pkg() sem DESTDIR/DESTROOT:" >&2
      echo "$abs_bad" >&2
    fi
    if [[ -n "$install_bad" ]]; then
      echo "Ocorrências: comandos de instalação sem DESTDIR/root (rootfs-style):" >&2
      echo "$install_bad" >&2
    fi
    die "Ajuste install_pkg() para instalar em "\${DESTDIR}/..." (ou "\${DESTROOT}/...") quando DESTDIR estiver setado."
  fi
}



# Atualiza um campo simples em uma receita: key="value"
update_recipe_field() {
  local recipe="$1" key="$2" value="$3"
  [[ -f "$recipe" ]] || die "Receita não encontrada: $recipe"
  # Usar perl para substituir de forma segura; preserva indentação.
  if command -v perl >/dev/null 2>&1; then
    perl -0777 -pe 's|(^\s*'"$key"'\s*=\s*").*?("\s*$)|$1'"$value"'$2|m' -i "$recipe"
  else
    # Fallback: sed POSIX (menos robusto)
    sed -i "s|^\([[:space:]]*${key}[[:space:]]*=[[:space:]]*\)\".*\"$|\1\"${value}\"|" "$recipe"
  fi
}


# ---------- Strip helpers ----------
# strip_debug_tree <DESTDIR> "<paths...>"
# Remove apenas símbolos de debug (conservador) para não comprometer a toolchain.
strip_debug_tree() {
  local destdir="$1"; shift
  local paths="$*"
  [[ -n "${destdir:-}" ]] || return 0
  [[ -n "${paths:-}" ]] || return 0

  local strip_bin="${STRIP:-strip}"
  command -v "${strip_bin%% *}" >/dev/null 2>&1 || return 0

  local p f
  for p in $paths; do
    [[ -d "${destdir}${p}" ]] || continue
    while IFS= read -r -d '' f; do
      # strip apenas ELF; ignore arquivos não binários
      if command -v file >/dev/null 2>&1; then
        file -b "$f" | grep -qE 'ELF ' || continue
      else
        # fallback: procura por magic ELF
        head -c 4 "$f" 2>/dev/null | grep -q $'\x7fELF' || continue
      fi
      "${strip_bin%% *}" --strip-debug "$f" 2>/dev/null || true
    done < <(find "${destdir}${p}" -type f -print0)
  done
}


# Aplica patches em patches/<pkg>/*.patch
apply_patches() {
  local pkg="$1" srcdir="$2" topdir="$3"
  local pdir="${topdir}/patches/${pkg}"
  [[ -d "$pdir" ]] || return 0
  local patches
  patches=$(ls -1 "$pdir"/*.patch 2>/dev/null || true)
  [[ -n "$patches" ]] || return 0
  echo "Aplicando patches para ${pkg}:"
  for p in $patches; do
    echo "  - $(basename "$p")"
    (cd "$srcdir" && patch -p1 < "$p")
  done
}
