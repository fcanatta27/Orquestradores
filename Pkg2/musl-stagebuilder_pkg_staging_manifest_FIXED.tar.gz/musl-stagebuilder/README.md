# musl-stagebuilder (x86_64-linux-musl)

Este repositório fornece um orquestrador em Bash + um conjunto de *recipes* para construir uma base Linux em **musl** em estágios:

1. **cross**: toolchain temporária (fora do chroot)
2. **stage1**: rootfs mínimo para entrar no chroot
3. **stage2**: ambiente nativo (dentro do chroot) com stack suficiente para compilar o restante sem depender do host
4. **stage3**: **sistema final** (rootfs definitivo) — aqui você reconstrói a toolchain e instala apenas o que quer manter

## Requisitos

No host (para `cross`/`stage1`):
- bash, coreutils, tar, xz/gzip, patch
- compilador C/C++ (gcc/clang), make
- curl ou wget para fetch

No chroot (para `stage2`/`stage3`):
- o stage1 montado e com `/stagebuilder` disponível (veja scripts)

## Como usar

### 1) Cross + Stage1 (fora do chroot)

```sh
./scripts/orchestrate.sh cross
./scripts/orchestrate.sh stage1
./scripts/stage1-finalize.sh
```

### 2) Stage2 (dentro do chroot)

Dentro do chroot (com o repo montado em `/stagebuilder`):

```sh
cd /stagebuilder
./scripts/orchestrate.sh stage2
```

### 3) Stage3 (sistema final)

O Stage3 constrói um **rootfs final** em `STAGE3_ROOT` e, por padrão, reconstrói a toolchain definitiva:

- `binutils`
- `musl`
- `gcc`
- libs necessárias para o GCC (`gmp`, `mpfr`, `mpc`, `isl`)

Execute dentro do chroot do stage2:

```sh
cd /stagebuilder
./scripts/orchestrate.sh stage3
```

O resultado vai para:

- `${WORKDIR}/stage3-root` (por padrão; ajuste em `config/config.env`)

## Tunagem (Stage3) e strip seguro

As recipes do stage3 suportam tunables por ambiente (definidos em `config/config.env`):

- `CFLAGS_TUNE` (default `-O2 -pipe`)
- `CXXFLAGS_TUNE` (default `-O2 -pipe`)
- `LDFLAGS_TUNE` (default vazio)
- `GCC_BOOTSTRAP` (default `0`)  
  - `1` ativa bootstrap completo do GCC (mais lento; útil se você quiser máxima validação)
- `STRIP_DEBUG` (default `1`)  
  - faz **strip conservador** (`--strip-debug`) após o install  
  - evita `--strip-unneeded` para não comprometer a toolchain

## Lint de recipes (antes de compilar)

Para detectar regressões antes de builds longos:

```sh
./scripts/lint-recipes.sh
# ou por stage:
./scripts/lint-recipes.sh stage2
```

O lint falha quando:
- faltam campos/funções obrigatórios
- `pkg_name` não coincide com o arquivo
- dependências não existem no mesmo stage
- `install_pkg()` tenta instalar fora de `DESTDIR` quando `DESTDIR` está setado
- em recipes “rootfs-style”, existe `make install` sem `DESTDIR`

## Variáveis importantes (contrato do build)

As recipes devem usar as variáveis exportadas pelo framework:

- `pkg_srcdir`, `pkg_builddir`, `pkg_tarball`
- `JOBS`
- `DESTDIR` (staging / rootfs de destino)
- `TARGET_TRIPLE`, `BUILD_TRIPLE`
- `COMPILE_SYSROOT` (cross)

Regra prática: **toda escrita no filesystem durante `install_pkg()` deve ser sob `${DESTDIR}`**.

## Layout

- `recipes/<stage>/*.recipe` — receitas
- `lib/` — funções comuns, fetch, build, guard de DESTDIR
- `scripts/` — orquestração, lint, finalize do stage1
- `patches/` — patches por pacote

## Notas

- `pkg_sha256="SKIP"` é aceitável durante desenvolvimento. Para builds reprodutíveis, preencha hashes e fixe versões.
- O Stage3 é o lugar certo para “limpar” o sistema: você pode manter no stage2 ferramentas pesadas (python/meson/etc.) e instalar apenas o necessário no Stage3.

## pkg (instalar/remover/atualizar com staging + manifesto)

Além do orquestrador por stage, o repositório inclui um comando **`./pkg`** (wrapper para `scripts/pkg.sh`) voltado a uso **no sistema já rodando**.

O fluxo é sempre o mesmo (por padrão, sem log verboso no terminal):

1. **STAGE**: instala em staging
   - `DESTDIR=/var/tmp/pkg-stage/<pkg>-<ver>`
   - nada toca em `/usr` durante a fase de install
2. **VALIDATE**: checagens rápidas
   - staging contém `/usr` e não está vazio
   - guard de DESTDIR (falha se a recipe escreve fora do staging)
   - checagem leve do loader musl (best-effort)
3. **RECORD**: grava manifesto mínimo
   - `/var/lib/pkg/db/<pkg>/version`
   - `/var/lib/pkg/db/<pkg>/files` (lista de arquivos)
   - `/var/lib/pkg/db/<pkg>/dirs` (diretórios)
4. **COMMIT**: aplica no sistema real
   - modo preferido: **rsync** (fallback automático para `tar|tar`)
   - regra segura para `/etc`: se o arquivo já existe, instala como `*.new`
   - arquivos críticos (loader/libc/shell/toolchain) são atualizados no final via rename (best-effort)

### Exemplos

Instalar um pacote do stage3:

```sh
./pkg install binutils --stage stage3
```

Atualizar (reinstala e remove órfãos do manifesto anterior):

```sh
./pkg upgrade musl --stage stage3
```

Remover:

```sh
./pkg remove vim
```

Remover incluindo `/etc` (não recomendado; use com cuidado):

```sh
./pkg remove vim --purge-etc
```

Listar instalados:

```sh
./pkg list-installed
```

Ver info:

```sh
./pkg info gcc
```

### Logs

Por padrão, `pkg` mostra apenas as etapas (UX/UI). O output detalhado do build/install vai para `LOG_DIR` (definido em `config/config.env`).

Para ver comandos no terminal, rode com `UI_QUIET=0`.
